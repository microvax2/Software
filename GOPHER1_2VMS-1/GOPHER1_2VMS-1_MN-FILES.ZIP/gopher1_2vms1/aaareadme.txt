This README file accompanies the VMSGopherServer distribution.

Current version: 1.2VMS-1

To install this software, you should be a VMS system manager, or have 
access to SYSTEM privileges.

To compile and link the VMSGopherServer, make the directory in which 
this file resides your current default.  Then enter @MAKE at the 
command line.

For complete installation instructions, see the file [.DOC]SERVER.DOC.
This file may be searched via Gopher at psulias.psu.edu, 
trln.lib.unc.edu, and niord.shsu.edu.

This software is archived and available via FTP at niord.shsu.edu.
It is archived and available via Gopher at psulias.psu.edu, 
niord.shsu.edu, and trln.lib.unc.edu.

This software is supported via the VMSGopher-L mailing list / 
vmsnet.infosystems.gopher newsgroup.  See the file 
VMSGOPHER-L.INFO for information about this list/group.
