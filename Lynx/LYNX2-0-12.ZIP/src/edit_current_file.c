#include "defs.h"

/*
 *  in edit mode invoke either emacs or vi or the default editor
 *  to display and edit the current file
 *  Both vi and emacs will open the file to the same line that the
 *  screen cursor is on when editing is invoked
 *  returns FALSE if file uneditable
 */

PUBLIC int edit_current_file ARGS5(char *,startdir, char *,newfile, 
					char *,origdir, int,cur, int,lineno)
{

	char command[90];
	char *colon, *localhost_ptr;
	FILE *fp;
	int url_type = is_url(newfile);

	/* if its a remote file then we can't edit it */
	if(!(url_type == 0 || url_type == FILE_URL_TYPE)) {
	    statusline("Lynx cannot currently edit remote WWW files");
	    sleep(1);
	    return FALSE;
	}

        if(url_type == FILE_URL_TYPE) {
	     /* try and open it as a completely referenced file */
	    colon = strchr(newfile,':');
	    if((fp = fopen(colon+1,"r")) == NULL) {

		localhost_ptr = strstr(newfile,"localhost");
		if(localhost_ptr==NULL || 
				(fp = fopen(localhost_ptr+9,"r"))==NULL) {
		    
	            statusline("Lynx cannot currently edit remote WWW files");
	            sleep(1);
	            return FALSE;
		} else {
		   newfile = localhost_ptr+9;
		}
	    } else {
	        newfile = colon+1;
	    }
	    fclose(fp);
	}
		

#ifndef VMS
	if(strstr(editor,"emacs") || strstr(editor,"vi")) {
	   if(*newfile != '/')
	   /* do command emacs or vi +# file */
	     sprintf(command,"%s +%d \"%s/%s\"", editor, 
				lineno+links[cur].ly, startdir, newfile);
	   else
	     sprintf(command,"%s +%d \"%s\"",editor, lineno+links[cur].ly, 
								newfile);
	} else {
	    if(*newfile != '/')
	       sprintf(command,"%s \"%s/%s\"",editor, startdir, newfile);
	    else
	       sprintf(command,"%s \"%s\"",editor, newfile);
	}
#else /* VMS */
	   /* if no device or directory is in the path, prefix startdir */
	   if (strchr(newfile,':') == 0 && strchr(newfile,']' == 0) &&
							strcmp(startdir,"."))
	       sprintf(command,"%s %s%s",editor, startdir, newfile);
	   else {
	       if (strncmp(newfile,"./",2) == 0)
	           sprintf(command,"%s %s",editor, newfile+2);
	       else
	           sprintf(command,"%s %s",editor, newfile);
	   }
#endif /* VMS */

	stop_curses();
	chdir(origdir);
	signal(SIGINT, SIG_IGN);
	system(command);
	signal(SIGINT, cleanup_sig);
	chdir(startdir);
	start_curses();
	return TRUE;
}
