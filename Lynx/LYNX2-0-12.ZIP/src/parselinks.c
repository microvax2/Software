#include "defs.h"
/**
*** This procedure attempts to parse the structure between two link delmiters
*** delimiters are user definable and are contained in the delimiter. data
*** structure.
*** if a '@' is in the filename part, it is assumed to be a remote file
*** if the filename part starts with a ! then it is assumed to be a command
*** This procedure is pretty ugly right now, remind myself to neaten it!!!
**/

char *get_token PARAMS((char *string));

PUBLIC char *parselinks ARGS8(char *,line, char *,base1, int,col,
		int,lineno, char *,cur_file, BOOLEAN *,show_next_char,
		struct attribtype *,attrib, char *,gopher_info)
{
	BOOLEAN istarget = FALSE;  /* the default is no target for a link */
	BOOLEAN show_link = FALSE;
	BOOLEAN remote_link = FALSE;
	char link[LINESIZE];
	char buffer[LINESIZE];
	int itmp;
	char *ctmp;
	char *at_sign, *end_link, *first_token, *second_token=NULL;
	char *fname, *size_spec, *target;
	char *next_text;
	char lnumber[10];  /* char string for link number if enabled */

	/* check for the end of the link to make sure that this
	 * can be a link
	 */
	ctmp = line;
	while(end_link = strchr(ctmp, delimiter.end_link) )
	    if(*(end_link-1) != '\\')
		break;
	    else
	        ctmp = end_link+1;

	if(end_link == NULL) {  /* can't be a link */
	   if(TRACE)
		fprintf(stderr,"parselinks: invalid link- no end_link line=%s\n	",line);
	   return(line);
	}

	/* set the link location */
	links[nlinks].lx = col;
	links[nlinks].ly = lineno;

	/* find the next text after the link */
	next_text = end_link+1;
	while(isspace(*next_text)) next_text++;

	/* copy the whole link except the begin_link and end_link 
	 * into a temporary string 
	 */
	mystrncpy(link, line+1, (end_link-line)-1);

	/* find the first token delimiter if it exists */
	ctmp=link;
	while(first_token = strchr(ctmp, delimiter.token) ) {
	    if(*(first_token-1) != '\\')
		break;
	    else
	        ctmp = first_token+1;
	}

	if(first_token) {
	    /* find second token delimiter if it exits */
	    ctmp = first_token+1;
	    while(second_token = strchr(ctmp, delimiter.token)) 
		if(*(second_token-1) != '\\')
		    break;
		else
		    ctmp = second_token+1;
	}

	/* seperate the tokens */
	if(first_token) {
	    *(first_token) = '\0';
	
	    if(second_token) 
		*second_token = '\0';
	}

	
	fname = get_token(link);
	size_spec = get_token(first_token ? first_token+1 : NULL);
	target = get_token(second_token ? second_token+1 : NULL);
	
	if(fname) {
	    /* if there is a @ in the linkname then it is a remote link */
	    ctmp = fname;
	    while((at_sign = strchr(ctmp,'@')) != NULL )
		if(*(at_sign)!='\\') 
		    break;
		else
	            ctmp=at_sign+1;

	    if(at_sign!=NULL)
	        remote_link=TRUE;

	    /* if the link type is <* then it is a comment link
	     * see if there is a '*' as the first character, and
	     * if there is, skip the link and don't display it
	     */
	     if(*fname=='*') {
		    *show_next_char = FALSE;
		    if(TRACE)
			fprintf(stderr,"parselinks: found comment link\n");
		    return(next_text);  /* return next text pointer */
	     }

	    if(*fname == '!' || remote_link==TRUE || is_url(fname) ) {
   	    /*it is a command or a gopher link, or a url, so don't 
	     * add base1 or anything else
	     */
   		/* copy the first field into lname */
	    	 StrAllocCopy(links[nlinks].lname, fname);

	    } else if(*fname != '/') {
		/* it is a file so add base1 if the name doesn't
		 * start with a slash '/' or '\' or ']' 
		 */
		if(*gopher_info != '\0') {
		    /* structure:  0-0/[base1][linkname]@[gopher_info] */
		    sprintf(buffer,"0-0/%s%s%s",
				base1, fname, gopher_info);
		} else {
		    /* structrue: [base1][linkname] */
		    sprintf(buffer,"%s%s",base1,fname);
		}

	        StrAllocCopy(links[nlinks].lname,buffer);

	    } else {
		/* else, it is a file, but just add gopher info */
		/* structure:  0-0[linkname]@[gopher_info]       */
		/* the 1 means its a file			*/
		if(*gopher_info != '\0')
		    sprintf(buffer,"0-0/%s%s", fname, gopher_info);
		else
		    sprintf(buffer,"%s",fname);

	        StrAllocCopy(links[nlinks].lname,buffer);
 	    }
	   

	} else { /* no file name given. Use current file */
	    StrAllocCopy(links[nlinks].lname, cur_file); 
	}

	if(target)  /* if a target field exists */
	    StrAllocCopy(links[nlinks].target, target);
	else 
	    StrAllocCopy(links[nlinks].target, empty_string);

	/* find out if there is something to highlight
	 * ismoretext checks for printable chars besides
	 * spaces after its pointer.
	 * if there isn't then highlight the linkname
	 * and show the link				 
	 */
	if(!ismoretext(next_text)) {
	    StrAllocCopy(links[nlinks].hightext, line);
	    show_link=TRUE;
	} else { /* either highlight the number of charactors
		    specified after the first colon, or just
		    highlight till the end of the line */

	    *show_next_char = FALSE; /* dont show next char */

	    if(size_spec) {
	        /* check for a number too large or too small */	
		if((itmp = atoi(size_spec)) > MAXHIGHLIGHT || itmp < 1) {
			/*if itmp out of range, highlight till end of line */
		      StrAllocCopy(links[nlinks].hightext, next_text); 

		} else{	 /* end of if links[nlinks] */
		    /* otherwise use the number between the colons */
			 /*copy text to be highlighted */
		      StrnAllocCopy(links[nlinks].hightext, next_text, itmp);
		}
	    } else {
		/* highlight the whole line */
	        StrAllocCopy(links[nlinks].hightext, next_text); 
	    }

	   /* refinehightext removes any strange control
	    * codes that creep in from the pc world  
	    */
            refinehightext(links[nlinks].hightext); 
	} /* end of if ismoretext */


	/* if the link should be hidden, adjust the underlining
	 * and bolding attributes so that they line up on the
	 * users screen, and move the character pointer to the
	 * character before the next character that you will show
	 */
	if(show_link==NULL) {	
	    int diff=(next_text-line);
	    attrib->underline_end_col -=  (diff);
	    attrib->underline_start_col -=  (diff);
	    attrib->bold_end_col -= (diff);
	    attrib->bold_start_col -= (diff);
		  /* make them line up */
	    line = next_text-1;
	}

	attrib->bold_end_col = col+strlen(links[nlinks].hightext);	

	start_bold();

	/* tell the system this is not a form link */
	links[nlinks].type = LYNX_LINK_TYPE;

	if(TRACE) {
	   fprintf(stderr,"parselinks: nlinks=%d\n",nlinks);
	   fprintf(stderr,"parselinks: fname=%s\n",fname);
	   fprintf(stderr,"parselinks: lname=%s\n",links[nlinks].lname);
	   fprintf(stderr,"parselinks: highlight=%s\n",links[nlinks].hightext);
	   fprintf(stderr,"parselinks: lx=%d\n",links[nlinks].lx);
	   fprintf(stderr,"parselinks: ly=%d\n",links[nlinks].ly);
	   if(first_token) {
	       fprintf(stderr,"parselinks: first_token=%s\n",first_token+1);
	       if(second_token) 
	           fprintf(stderr,"parselinks: second_token=%s\n",second_token+1);
	    }
	}
	
	nlinks++;

	return(line); /* return new location of "line" on the line */
} /* big end */

char *get_token ARGS1(char *,string)
/* kill all white space on ends and
 * return NULL if empty
 */
{
    char *end; 

    if(string==NULL)
	return(NULL);

    end = &string[strlen(string)-1];

     while(isspace(*end)) end--;
     *(end+1)='\0'; /*terminate */
     end++;  /* advance to terminator */

     while(isspace(*string)) string++;

    if(string==end)
	return(NULL);

     return(string);
}
