#include "defs.h"

/*
 * findtarget searches a file for a substring and returns the line
 * that it is first found on if it is found
 */
PUBLIC int findtarget ARGS3(FILE *,fp, char *,target, 
			    BOOLEAN *,target_present)
{
	char buffer[LINESIZE];
	int line = 0;
	int found = FALSE;
	char *ptr;

	for(line = 0; !feof(fp); line++) { 
	  fgets(buffer, LINESIZE, fp);

		if((ptr = linkless_search(buffer, target)) != NULL)  
		   if((*(ptr-1)) != delimiter.token) {
		      found = TRUE; 
		      break;
		   } else {  /* look for it again on the same line */
		      if((ptr = linkless_search(ptr, target)) != NULL)
		         if((*(ptr-1)) != delimiter.token) {
		      	    found = TRUE; 
		      	    break;
			/* if its not found now, just give up */
		      }
		   }
	}

	rewind(fp);

 	if(found==FALSE) {
	   *target_present = FALSE;
	   return(1);
	}

	*target_present = TRUE;
 	return(line-3); 

}
