#ifndef HTAnchor
#include "HTAnchor.h"
#endif

#include "HTForms.h" 

struct link {
    char *lname;
    char *target;
    char *hightext;
    int lx;
    int ly;
    int type;      /* type of link, Forms, WWW, etc */
    FormInfo *form;  /* pointer to form info */
}; 

extern struct link links[MAXLINKS];

extern int nlinks;

struct hist {
    char *hfname;
    char *real_name;
    char *hightext;
    char *gopher_info;
    int hlinkno;
    int hpageno;
};

struct delimitertype {
    char target[3];
    char end_target[3];
    char token;
    char link;
    char end_link;
};

extern struct delimitertype delimiter;

struct attribtype {
    int underline_start_col;
    int underline_end_col;
    int bold_start_col;
    int bold_end_col;
};
 
extern struct hist history[MAXHIST];

extern int nhist;

struct chunck_struct {
    char * data;
    struct chunck_struct * next;
};
