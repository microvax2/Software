/* 
 * written by Garrett Arch Blythe
 *
 */



#include<stdio.h>
#include<dir.h>
#include<dos.h>
#include<string.h>
#include<ctype.h>
#include"pccurses.h"

int COLS = 80;
int LINES = 26;

int set_attribs(int mod);

int PC_RESET		=	0;
int PC_BACKGROUND	=	BLACK;
int PC_FOREGROUND	=	LIGHTGRAY;
int PC_REVERSE		=	BLACK;
int PC_BREVERSE		=	LIGHTGRAY;
int PC_STANDOUT		=	WHITE;
int PC_BSTANDOUT	=	BLACK;
int PC_DIM		=	DARKGRAY;
int PC_BDIM		=	BLACK;
int PC_BOLD		=	WHITE;
int PC_BBOLD		=	BLACK;
int PC_UNDERLINE	=	WHITE;
int PC_BUNDERLINE	=	DARKGRAY;
int PC_TEXTMODE		=	BW80;
int LINES;

int addch(chtype ch)
{
	putch(ch);
	return(OK);
}

int addstr(char *str)
{
	cputs(str);
	return(OK);
}

int attroff(int attrs)
{
	set_attribs(A_NORMAL);
	return(OK);
}

int attron(int attrs)
{
	set_attribs(attrs);
	return(OK);
}

int clear(void)
{
	clrscr();
	return(OK);
}

int clrtoeol(void)
{
	clreol();
	return(OK);
}

int endwin(void)
{
	textmode(LASTMODE);
	normvideo();
	clear();
	return(OK);
}

WINDOW *initscr(void)
{
	char drive[MAXDRIVE];
	char dir[MAXDIR];
	char file[MAXFILE];
	char ext[MAXEXT];
	char *command_line = _argv[0];
	char cfgfile[MAXDRIVE+MAXDIR+MAXFILE+MAXEXT+1];
	int count;
	FILE *config;
	char buffer[128];
	struct text_info r;

	fnsplit(command_line, drive, dir, file, ext);
	fnmerge(cfgfile, drive, dir, file, ".cfg");
	for(count = 0; cfgfile[count] != '\0'; count++)
		cfgfile[count] = toupper(cfgfile[count]);
	
	if(NULL == (config = fopen(cfgfile, "r")))
	{
		printf("Creating configuration file %s.\n\r", cfgfile);
		printf("Press any key...\n\r");
		getch();
		if(NULL == (config = fopen(cfgfile, "w")))
		{
			printf("Unable to create configuration file %s.\n\r", cfgfile);
			printf("Using default values.  Press any key...\n\r");
			getch();
		}
		else
		{
			fprintf(config, "%s%s configuration file.\n", file, ext);
			fprintf(config, "%d\tPC_BACKGROUND\n", PC_BACKGROUND);
			fprintf(config, "%d\tPC_BOLD\n", PC_BOLD);
			fprintf(config, "%d\tPC_BBOLD\n", PC_BBOLD);
			fprintf(config, "%d\tPC_DIM\n", PC_DIM);
			fprintf(config, "%d\tPC_BDIM\n", PC_BDIM);
			fprintf(config, "%d\tPC_FOREGROUND\n", PC_FOREGROUND);
			fprintf(config, "%d\tPC_REVERSE\n", PC_REVERSE);
			fprintf(config, "%d\tPC_BREVERSE\n", PC_BREVERSE);
			fprintf(config, "%d\tPC_STANDOUT\n", PC_STANDOUT);
			fprintf(config, "%d\tPC_BSTANDOUT\n", PC_BSTANDOUT);
			fprintf(config, "%d\tPC_TEXTMODE\n", PC_TEXTMODE);
			fprintf(config, "%d\tPC_UNDERLINE\n", PC_UNDERLINE);
			fprintf(config, "%d\tPC_BUNDERLINE\n", PC_BUNDERLINE);
			fclose(config);
			config = NULL;
		}
	}
	else
	{
		fgets(buffer, 127, config);
		while(!feof(config))
		{
			fscanf(config, "%d", &count);
			fscanf(config, "%s", buffer);

			if(!strcmp(buffer, "PC_BACKGROUND"))
				PC_BACKGROUND = count;
			else if(!strcmp(buffer, "PC_FOREGROUND"))
				PC_FOREGROUND = count;
			else if(!strcmp(buffer, "PC_REVERSE"))
				PC_REVERSE = count;
			else if(!strcmp(buffer, "PC_BREVERSE"))
				PC_BREVERSE = count;
			else if(!strcmp(buffer, "PC_STANDOUT"))
				PC_STANDOUT = count;
			else if(!strcmp(buffer, "PC_BSTANDOUT"))
				PC_BSTANDOUT = count;
			else if(!strcmp(buffer, "PC_DIM"))
				PC_DIM = count;
			else if(!strcmp(buffer, "PC_BDIM"))
				PC_BDIM = count;
			else if(!strcmp(buffer, "PC_BOLD"))
				PC_BOLD = count;
			else if(!strcmp(buffer, "PC_BBOLD"))
				PC_BBOLD = count;
			else if(!strcmp(buffer, "PC_UNDERLINE"))
				PC_UNDERLINE = count;
			else if(!strcmp(buffer, "PC_BUNDERLINE"))
				PC_BUNDERLINE = count;
			else if(!strcmp(buffer, "PC_TEXTMODE"))
				PC_TEXTMODE = count;
			else
			{
				printf("Unrecognized symbol %s in %s.CFG.\n\rPress any key...\n\r", buffer, file);
				getch();
			}
		}
		fclose(config);
	}

	textmode(PC_TEXTMODE);
	gettextinfo(&r);
	PC_TEXTMODE = r.currmode;
	LINES = r.screenheight;
	standend();
	clear();
	return((void *)0);
}

void move(int y, int x)
{
	gotoxy(x+1, y+1);
}

int refresh(void)
{
	return(OK);
}

int standend(void)
{
	set_attribs(A_NORMAL);
	return(OK);
}

int standout(void)
{
	return(attron(A_STANDOUT));
}

int set_attribs(int attributes)
{
	textattr(PC_RESET);
	if(attributes >= A_BLINK)
		textattr(BLINK);
	if(attributes >= A_UNDERLINE)
	{
		textcolor(PC_UNDERLINE);
		textbackground(PC_BUNDERLINE);
	}
	else if(attributes >= A_BOLD)
	{
		textcolor(PC_BOLD);
		textbackground(PC_BBOLD);
	}
	else if(attributes >= A_REVERSE)
	{
		textcolor(PC_REVERSE);
		textbackground(PC_BREVERSE);
	}
	else if(attributes >= A_STANDOUT)
	{
		textcolor(PC_STANDOUT);
		textbackground(PC_BSTANDOUT);
	}
	else if(attributes >= A_DIM)
	{
		textcolor(PC_DIM);
		textbackground(PC_BDIM);
	}
	else
	{
		textbackground(PC_BACKGROUND);
		textcolor(PC_FOREGROUND);
	}

	return(attributes);
}

void noecho(void)
{
}

void echo(void)
{
}
