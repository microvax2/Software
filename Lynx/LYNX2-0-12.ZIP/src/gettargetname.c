#include "defs.h"

/*
 * extract the targetname portion of a link <filename:#:target>linkname
 */

PUBLIC void gettargetname ARGS2(char *,buf, int,cur)
{
    char *cp;

    *buf = '\0';  /* just in case */

    if (nlinks > 0 && links[cur].target) {
	for (cp=links[cur].target; *cp != '>' && *cp != '\0'; cp++) {
	    *buf = *cp;
	    buf++;
	}
	*buf = '\0';
    }
}

