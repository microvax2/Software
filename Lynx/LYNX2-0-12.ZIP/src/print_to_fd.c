#include "defs.h"

/*
 *  print_to_fd prints out the current file minus the links and targets 
 *  to a file discriptor
 */
PUBLIC int print_to_fd ARGS2(FILE *,fp, FILE *,outfile_fd)
{
    char *chptr, *tmpchptr;
    FILE *outfile_fp;
    BOOLEAN flag;
    char buffer[LINESIZE];
    char line_buffer[LINESIZE];
    char filename[80];
    char temp[80];
    int count=0;

    rewind(fp);   /* rewind input file back to beginning */

    while(fgets(buffer,LINESIZE,fp) && defineswitch(buffer))
	; /* null body */

    strcat(buffer,"\n");  /* add the \n that defineswitch stripped off */

    do {    /* do while fgets(buffer,LINESIZE,fp) */
      chptr = buffer;
      for(; *chptr != '\0'; chptr++) {
	flag = FALSE;  /* reset flag */
	if(*chptr == delimiter.link) {  /* kill links */
	    for(tmpchptr = chptr+1; *tmpchptr != delimiter.link &&
	        *tmpchptr != delimiter.end_link && *tmpchptr != '\0';
		tmpchptr++)
		    ; /*null body*/
	    if(*tmpchptr == delimiter.end_link) {
		chptr = tmpchptr;
		flag = TRUE;
	    }
	}
			/* kill targets */
	if(*chptr==delimiter.target[0] && *(chptr+1)==delimiter.target[1]) {
	    for(tmpchptr = chptr+2; *tmpchptr != delimiter.end_target[1] &&
	        *tmpchptr != '\0'; tmpchptr++)
		    ; /*null body*/
	    if(*tmpchptr == delimiter.end_target[1]) {
		chptr = tmpchptr;
		flag = TRUE;
	    }
	}

	/* kill _ that signify bold characters */
	if(*chptr=='_' && *(chptr+1)==8) 
	    chptr+=2;

	if(!flag) {
	  sprintf(&line_buffer[count],"%c",*chptr);
	  count++;
	}

      } /* end for */
      fprintf(outfile_fd, "%s", line_buffer);
      count=0;
    } while(fgets(buffer,LINESIZE,fp)); /* end of do loop */

    return(TRUE);

}	
