/*
 *	Cut-down termio --
 *		Do character-oriented stream input for Jeff.
 *		Code ripped off from Micro-Emacs 3.7 by Daniel Lawrence.
 *
 *		Ever-so-slightly modified by Kathryn Huxtable.  29-Jan-1991.
 *		Cut down for Lou.  8 Sep 1992.
 *		Cut down farther for Lou.  19 Apr 1993.
 *			We don't set PASSALL or PASTHRU since we don't
 *			want to block CTRL/C, CTRL/Y, CTRL/S or CTRL/Q.
 *			Simply setting NOECHO and doing timed reads
 *			is sufficient.
 *              Further mods by Fote.  29-June-1993
 *			ttopen() and ttclose() are now terminal initialization
 *			 and restoration procedures, called once at startup
 *			 and at exit, respectively, of the LYNX image.
 *			ttclose() should be called before an exit from LYNX
 *			 no matter how the exit is invoked.
 *			setup(terminal) does the ttopen().
 *			cleanup() calls cleanup_files() and ttclose().
 *			ttgetc() now handles NOECHO and NOFLITR (instead of
 *			 setting the terminal itself to NOECHO in ttopen()).
 *			vsignal() added for handling both Ctrl-C *and* Ctrl-Y
 *			 interrupts, and disabling system response to Ctrl-T.
 *			
 */


#include <descrip.h>
#include <iodef.h>
#include <ssdef.h>
#include <signal.h>
#include <stdlib.h>
#include <msgdef.h>
#include <ttdef.h>
#include <tt2def.h>
#include <libclidef.h>


#define	TRUE	1			/* True value			*/
#define	FALSE	0			/* False value			*/

#define MAXIBUF 128			/* Input buffer size		*/
#define MAXOBUF 1024			/* MM says bug buffers win!	*/
#define EFN	0			/* Event flag			*/

static	char	ibuf[MAXIBUF];		/* Input buffer			*/
static	int	nibuf;			/* # of bytes in above		*/
static	int	ibufi;			/* Read index			*/
static	int	oldmode[3];		/* Old TTY mode bits		*/
static	int	newmode[3];		/* New TTY mode bits		*/
static	short	iochan;			/* TTY I/O channel		*/
static  $DESCRIPTOR(term_nam_dsc,"TT"); /* Descriptor for iochan	*/
static	int	mask = LIB$M_CLI_CTRLY|LIB$M_CLI_CTRLT; /* ^Y and ^T	*/
static	int 	old_msk;		/* Saved control mask		*/
static	short	trap_flag = FALSE;	/* TRUE if AST is set		*/

/*
 *	TTOPEN --
 *		This function is called once to set up the terminal
 *		device streams.	 It translates TT until it finds
 *		the terminal, then assigns a channel to it, sets it
 *		to EDIT, and sets up the Ctrl-C and Ctrl-Y interrupt
 *		handling.
 */

ttopen()
{
	extern	void cleanup_sig();
	int	iosb[2];
	int	status;

	status = SYS$ASSIGN( &term_nam_dsc, &iochan, 0, 0 );
	if( status != SS$_NORMAL )
		exit( status );

	status = SYS$QIOW( EFN, iochan, IO$_SENSEMODE, &iosb, 0, 0,
			  &oldmode, sizeof(oldmode), 0, 0, 0, 0 );
	if( status != SS$_NORMAL )
		exit( status );

	status = iosb[0] & 0xFFFF;
	if( status != SS$_NORMAL )
		exit( status );

	newmode[0] = oldmode[0];
	newmode[1] = oldmode[1];
	newmode[2] = oldmode[2] | TT2$M_EDIT;

	status = SYS$QIOW( EFN, iochan, IO$_SETMODE, &iosb, 0, 0,
			  &newmode, sizeof(newmode), 0, 0, 0, 0 );
	if( status != SS$_NORMAL )
		exit( status );

	status = iosb[0] & 0xFFFF;
	if( status != SS$_NORMAL )
		exit( status );

	/* set the AST */
	lib$disable_ctrl(&mask, &old_msk);
	trap_flag = TRUE;
	status = SYS$QIOW ( EFN, iochan,
			    IO$_SETMODE|IO$M_CTRLCAST|IO$M_CTRLYAST,
			    &iosb, 0, 0,
			    &cleanup_sig, SIGINT, 0, 0, 0, 0 );
	if ( status != SS$_NORMAL ) {
		lib$enable_ctrl(&old_msk);
		exit ( status );
	}

}	/*  ttopen  */

/*
 *	TTCLOSE --
 *		This function gets called just before we go back home
 *		to the command interpreter.  It puts the terminal back
 *		in a reasonable state.
 */

ttclose()
{
	int	status;
	int	iosb[1];

/*	ttflush(); */

	status = SYS$QIOW( EFN, iochan, IO$_SETMODE, &iosb, 0, 0,
			  &oldmode, sizeof(oldmode), 0, 0, 0, 0 );

	if( status != SS$_NORMAL || (iosb[0] & 0xFFFF) != SS$_NORMAL )
		exit( status );

	if (trap_flag) {
	    status = SYS$DASSGN (iochan);
	    status = lib$enable_ctrl(&old_msk);
	    trap_flag = FALSE;
	}

}	/*  ttclose  */

/*
 *	TTGETC --
 *		Read a character from the terminal, with NOECHO and NOFILTR.
 */

ttgetc()
{
	int	status;
	int	iosb[2];
	int	term[2];

	while( ibufi >= nibuf ) {
		ibufi = 0;
		term[0] = 0;
		term[1] = 0;

		status = SYS$QIOW( EFN, iochan,
			     IO$_READLBLK|IO$M_TIMED|IO$M_NOECHO|IO$M_NOFILTR,
			     &iosb, 0, 0,
			     &ibuf, MAXIBUF, 0, term, 0, 0 );
		if( status != SS$_NORMAL )
			exit( status );

		status = iosb[0] & 0xFFFF;
		if( status != SS$_NORMAL && status != SS$_TIMEOUT )
			exit( status );

		nibuf = (iosb[0]>>16) + (iosb[1]>>16);		/* Huh?	 KAH */

		if( nibuf == 0 ) {
			status = SYS$QIOW( EFN, iochan,
				     IO$_READLBLK|IO$M_NOECHO|IO$M_NOFILTR,
				     &iosb, 0, 0, 
				     &ibuf, 1, 0, term, 0, 0 );
			if( status != SS$_NORMAL ||
			    (status = (iosb[0]&0xFFFF)) != SS$_NORMAL )
				exit( status );

			nibuf = (iosb[0]>>16) + (iosb[1]>>16);
		}
	}

	return( ibuf[ibufi++] & 0xFF );	  /* Allow multinational  */
}	/*  ttgetc  */

/*
 *	TYPAHEAD --
 *		Check to see if any characters are already in the
 *		keyboard buffer.  (Not used. -- Fote)
 */

typahead()
{
	int	status;
	int	iosb[2];
	int	term[2];

	if( ibufi < nibuf )
		return( TRUE );

	ibufi = 0;
	term[0] = 0;
	term[1] = 0;

	status = SYS$QIOW( EFN, iochan,
			   IO$_READLBLK|IO$M_TIMED|IO$M_NOECHO|IO$M_NOFILTR,
			   &iosb, 0, 0,
			   &ibuf, MAXIBUF, 0, term, 0, 0 );
	if( status != SS$_NORMAL )
		exit( status );

	status = iosb[0] & 0xFFFF;
	if( status != SS$_NORMAL && status != SS$_TIMEOUT )
		exit( status );

	nibuf = (iosb[0]>>16) + (iosb[1]>>16);

	if( nibuf == 0 )
		return( FALSE );

	return( TRUE );			/* Allow multinational	*/
}	/*  typeahead  */


/*
 *	VSIGNAL -- Fote Macrides 29-Jun-1993
 *		Sets up AST for both Ctrl-C and Ctrl-Y, with system response
 *		 to Ctrl-T disabled.  If called with a sig other than SIGINT,
 *		 it will use the C library's system(sig, func).
 *              The equivalent of vsignal(SIGINT, cleanup_sig) is done on
 *               intialization by ttopen(), so don't do it again.
 *		vsignal(SIGINT, SIG_DFL) is treated as a call to ttclose().
 *              Call vsignal(SIGINT, SIG_IGN) before system() calls to
 *               enable Ctrl-C and Ctrl-Y in the subprocess, and then call
 *               vsignal(SIG_INT, cleanup_sig) on return from the subprocess.
 *		For func's which set flags and do not invoke an exit from
 *		 LYNX, the func should reassert itself.
 *              The VMS signal() calls do not fully emulate the Unix calls,
 *		 and vsignal() is just a "helper", also not a full emulation.
 */

void *vsignal (sig, func)
int sig;
void (*func)();
{
	int status;
	short iosb[4];
	static int SIG_IGN_flag;

	/* pass all signals other than SIGINT to signal() */
	if (sig != SIGINT) {
	    signal(sig, func);
	    return;
	}

	/* if func is SIG_DFL, treat it as ttclose() */
	if (func == SIG_DFL) {
	    ttclose();
	    return;
	}

	/* Clear any previous AST */
	if (trap_flag) {
	    status = SYS$DASSGN (iochan);
	    status = lib$enable_ctrl(&old_msk);
	    trap_flag = FALSE;
	}

	/* if func is SIG_IGN, leave the TT channel closed and the  */
	/* system response to interrupts enabled for system() calls */
	if (func == SIG_IGN)
	    return;

	/* if we get to here, we have a LYNX func, so set the AST */
	lib$disable_ctrl(&mask, &old_msk);
	trap_flag = TRUE;
	status = SYS$ASSIGN (&term_nam_dsc, &iochan, 0, 0 );
	status = SYS$QIOW ( EFN, iochan,
			    IO$_SETMODE|IO$M_CTRLCAST|IO$M_CTRLYAST,
			    &iosb, 0, 0,
			    func, SIGINT, 0, 0, 0, 0 );

}	/* vsignal */

