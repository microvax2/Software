
/********  string for the copyright notice  ********/

static char copyright[] = { 
		"@(#)          (C) Copyright 1992,1993 Lou Montulli, University of Kansas \n" };
