#include "defs.h"
/*
 *  Textsearch checks the prev_target variable to see if it is empty.
 *  If it is then it requests a new search string.  It then searches 
 *  the current file for the next instance of the search string and
 *  finds the line number that the string is on
 * 
 *  This is the primary USER search engine and is case sensitive
 *  or case insensitive depending on the 'case_sensitive' global
 *  variable
 *
 */
		
PUBLIC int textsearch ARGS6(FILE *,fp, int *,newline, int *,cur, char *,target, 
		   	    BOOLEAN *,target_present, char *,prev_target)
{
	int linec;
	int offset;
	char *ptr;
	char temp[30];
	BOOLEAN found=FALSE;
	char buffer[LINESIZE];	
        int oldcur = *cur;

	if(strlen(prev_target) == 0 ) {
	  statusline("Enter a search string: ");
	  Gophergetstr(prev_target);
	}

	if(strlen(prev_target) == 0) { /* return if empty string */
	  *target_present = FALSE;
	  return(DO_NOTHING);
	}

	if(check_for_target_in_links(cur, prev_target)) {
	   /* found in link, changed cur */
           highlight(OFF, oldcur);
	   return(IN_LINKS); /* no screen update needed */
	}
	

	/* start from the link you are on or the next page */
	if(nlinks == 0)
	    offset = LINES-1;
	else
	    offset = links[*cur].ly;


	/* let www handle the search if we are in www mode */
	if(IS_WWW_MODE) {
	    linec = www_user_search(*newline+offset, prev_target);
	    if(linec > 0) {  /* then we found it */
		*newline = linec;
	        strcpy(target, prev_target);
	        *target_present = TRUE;
	        return(IN_FILE);
	    } else {
	        *target_present = FALSE;
	        statusline("String not found"); 
	        sleep(1);
		return(NOT_FOUND);
	    }
	}
	    

	/* rewind file and then advance past current line that curser is on */
	rewind(fp);
	checkfordefines(fp);
   	for(linec = 1; linec <= *newline+offset
		 && fgets(buffer, LINESIZE, fp); linec++)   
		; /* null body */

	/* search from current point in file to the end */
	   for(linec = 0; !found && fgets(buffer, LINESIZE, fp); linec++) {  
		if(case_sensitive) {
		    if(strstr(buffer,prev_target)) {
			found = TRUE;
		    }
		} else {
		    if(mystrstr(buffer,prev_target)) {
			found = TRUE;
		    }
		}
	   }

	/* add the current line to the relative line that the target
	   was found on */
	linec += *newline+offset;

	rewind(fp);
	checkfordefines(fp);

	/* if found is false then the previous findtarget didn't
	   find the search string.  So rewind the file to the beginning
	   and search it again
     	*/
	if(found == FALSE) {  /* check from beginning of file */
	   for(linec = 0; !found && fgets(buffer, LINESIZE, fp); linec++) {  
		if(case_sensitive) {
		    if(strstr(buffer,prev_target)) {
			found = TRUE;
		    }
		} else {
		    if(mystrstr(buffer,prev_target)) {
			found = TRUE;
		    }
		}
	   }
	}

	/* if we return true then we are saying that the target was found */
	if(found == TRUE) {
	   *newline = linec;
	   strcpy(target, prev_target);
	   *target_present = TRUE;
	   return(IN_FILE);
	}
	/*else*/	   
	   statusline("String not found"); 
	   sleep(1);
	   *target_present = FALSE;
	   return(NOT_FOUND);
}

	
