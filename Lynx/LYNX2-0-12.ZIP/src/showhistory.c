#include "defs.h"
#ifdef MSDOS
#include "process.h"  /* for getpid() */
#endif

/*
 * This procedure outputs the history buffer into a temporary file
 *  
 */

PUBLIC void showhistory ARGS1(char *,newfile)
{
	int x=0, curr=0,tmp=0;
	int c;
	register int i;
	char number[8];
        char tmpfile[MAXFNAME];
        char tmpstring[MAXFNAME];
	FILE *fp0;

	sprintf(newfile,"%sLYNXhist%d",TEMP_SPACE,getpid());

	if((fp0 = fopen(newfile,"wb")) == NULL) {
		perror("Trying to open history file\n");
		exit(1);
	}

	fprintf(fp0,"end_link_delimiter=>\nlink_delimiter=<");
	fprintf(fp0,"\ntoken_delimiter=: \n");
	
	fprintf(fp0,"\n                  YOU HAVE REACHED THE HISTORY PAGE\n\n");
        for(x=nhist-1; x >= 0; x--) {	

		/* the number of the document in the hist stack
		 * and its name in a link
		 */
	   fprintf(fp0,"\n\n  %d.  -- You selected:  <%%%d>%s ", x, x,
	       (history[x].hightext!=NULL ? history[x].hightext : "no title"));
	}

	fclose(fp0);

}
