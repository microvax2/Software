#include "defs.h"

PUBLIC int get_homepage_name ARGS1(char *,name)
{
    char name_buffer[256];
    FILE *fp;

    if(*home_page == '\0') {
	statusline("Home page is not defined. Use 'O' to see options");
	sleep(1);
	return(FALSE);
    }

	/* see if we can open it raw */
	if((fp = fopen(home_page,"r")) != NULL) {
	   fclose(fp);
	   strcpy(name, home_page);
	   return(TRUE);  /* homepage exists */
	} 

#ifdef UNIX
	/* see if it is in the home path */
        sprintf(name_buffer,"%s/%s",getenv("HOME"), home_page);
	if((fp = fopen(name_buffer,"r")) != NULL) {
	   fclose(fp);
	   strcpy(name, name_buffer);
	   return(TRUE);  /* homepage exists */
	}
#endif UNIX

       statusline("Unable to open Home page");
       sleep(1);
       return(FALSE);

} /* big end */
