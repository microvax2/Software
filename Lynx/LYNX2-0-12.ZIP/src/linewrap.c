#include "defs.h"

/*
 *  linewrap checks to see if we need to linewrap now or later 
 *  if there are no spaces in the next word and that word will
 *  go off the page, the linewrap now
 *  links are a special case.  For now links do not cause linewrap
 */

PUBLIC BOOLEAN linewrap ARGS2(char *,cp, int,col)
{
    cp++; /* go past space */

    for(;*cp != '\0' && *cp != ' ' && 
	*cp != delimiter.link && col < COLS-1; col++, cp++)
	;  /* null body */

    if(col >= COLS-1) 
	return(TRUE);
 /* else */ 
        return(FALSE);
}
