#include "defs.h"

#ifdef getyx
#define GetYX(y,x)   getyx(stdscr,y,x)
#else
#define GetYX(y,x)   y = stdscr->_cury, x = stdscr->_curx
#endif

PRIVATE void assign_form_value PARAMS((FormInfo *form, char *inputline));

PUBLIC int form_getstr ARGS1(FormInfo *,form)
{
     int pointer = 0, tmp_pointer=0;
     int ch;
     int last_char, len;
     int max_length = (form->maxlength ? form->maxlength : 1024);
     char inputline[1024];
     int str_size = strlen(inputline);
     int startcol, startline;
     int cur_col, far_col;
     BOOLEAN extend=TRUE; /* TRUE to enable line extention */
     BOOLEAN line_extended=FALSE;  /* TRUE if the line was moved to accomadate
				    * more text entry
				    */

     /* get the initial position of the curser */
     GetYX(startline, startcol);

     if(startcol + form->size > COLS-1)
	far_col = COLS-1;
     else
	far_col = startcol + form->size;

	/* if there is enough room to fit the whole
	 * string then disable the moving text feature
	 */
     if(form->maxlength && (far_col-startcol) >= form->maxlength)
	extend=FALSE;

     if(form->type == F_PASSWORD_TYPE)
	strcpy(inputline, form->hidden_value);
     else
	strcpy(inputline, form->value);

     /* find that last char in the string that is non-space */
     last_char = strlen(inputline)-1;
     while(isspace(inputline[last_char])) last_char--; 
     inputline[last_char+1] = '\0';

top:
     /*** Check to see if there's something in the inputline already ***/
     len = strlen(inputline);
     if(extend && len+startcol+5 > far_col) {
	pointer = (len - (far_col - startcol)) + 10;
	line_extended = TRUE;
     } else {
	line_extended = FALSE;
     }
     if(pointer > len)
	pointer = 1;
     
     cur_col = startcol;
     while (inputline[pointer] != '\0') {
	  if(form->type == F_PASSWORD_TYPE)
	     addch('*');
	  else
	     addch(inputline[pointer]);
	  pointer++;
	  cur_col++;
     }
     refresh();

     for (;;) {
	  ch = mygetch();

	  switch (ch) {

#ifdef AIX
          case '\227':
#endif
	  case '\n':
	  case '\r':
	  case '\t':
	  case DNARROW:
	  case UPARROW:
	       inputline[pointer] = '\0';
	       assign_form_value(form, inputline);
		/* fill out the rest of the space with spaces */
	       for(;cur_col<far_col;cur_col++)
		  addch(' ');
	       return(ch);
	       break;

          /* Control-G aborts */
          case 7:
               return(-1);

	 	/* break */  /* implicit break */


	  /* erase all the junk on the line and start fresh */
	  case 21 :
		move(startline, startcol);
		clrtoeol();
		pointer = 0;  /* clear inputline */
		cur_col = startcol;
		line_extended = FALSE;
		refresh();
		break;

	  /**  Backspace and delete **/

	  case '\010':
	  case '\177':
	  case LTARROW:
	       if (pointer > 0) {
		    addch('\010');
		    addch(' ');
		    addch('\010');
	       
		    pointer--;
		    cur_col--;

		    if(line_extended && cur_col+15 < far_col) {
     			if(pointer + startcol+5 > far_col) {
			    tmp_pointer = (pointer - (far_col - startcol)) + 5;
			    if(tmp_pointer < 0) tmp_pointer=0;
			} else {
			    tmp_pointer = 0;
			    line_extended = FALSE;
			}

			move(startline, startcol);
			clrtoeol();
		
			cur_col = startcol;
     
     			while (tmp_pointer != pointer) {
	  			addch(inputline[tmp_pointer]);
	  			tmp_pointer ++;
	  			cur_col++;
     			}
			
		    }
		    refresh();

	       } else if(ch == LTARROW) {
		   inputline[0] = '\0';
	           assign_form_value(form, inputline);
		   return(ch);
	       }
	       break;
		    
	       
	  default:
	       if (printable(ch) && pointer < max_length) {
		    inputline[pointer++]= ch;
		    cur_col++;
		    if(form->type == F_PASSWORD_TYPE)
		 	addch('*');
		    else
		    	addch(ch);

		    if(extend && cur_col+2 > far_col) {
			tmp_pointer = (pointer - (far_col - startcol)) + 10;
			if(tmp_pointer > pointer)
			    tmp_pointer = 1;
			line_extended = TRUE;

			move(startline, startcol);
			clrtoeol();
     
			cur_col = startcol;

     			while (tmp_pointer != pointer) {
	  			addch(inputline[tmp_pointer]);
	  			tmp_pointer ++;
	  			cur_col++;
     			}
			
		    } else if(pointer >= max_length) {
			statusline("Maximum length reached!");
			inputline[pointer] = '\0';
			move(startline,startcol);
		  	pointer=0;
			/* go back to to top and print it out again */
			goto top;
		    }
		    refresh();
	       }
	       /* else
	          return(ch); */
		/* just ignore unprintable charactors */
	  }
     }

}

PRIVATE void assign_form_value ARGS2(FormInfo *,form, char *,inputline)
{
    int i;

    if(form->type == F_TEXT_TYPE) {
	StrAllocCopy(form->value, inputline);
	
    } else {
	StrAllocCopy(form->hidden_value, inputline);
	/* lazy  create the string with Stralloccopy and
	 * copy over it with "*"'s
	 */
	StrAllocCopy(form->value, inputline);
	for(i=0; inputline[i]!='\0'; i++)
	    form->value[i]= '*';
    }
}
	
	
