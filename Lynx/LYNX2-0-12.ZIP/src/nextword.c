#include "defs.h"

/*
 * Return pointer to the second word in a string
 */
PUBLIC char * nextword ARGS1(char *,cp)
{
    while (*cp != ' ' && *cp != '\0') cp++;	/* skip non-spaces */
    while (*cp == ' ') cp++;			/* skip spaces */
    return(cp);
}

