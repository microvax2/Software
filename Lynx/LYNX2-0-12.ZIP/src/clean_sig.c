#include "defs.h"

/*
 * Interrupt handler.  Stop curses and exit gracefully.
 */
PUBLIC void cleanup_sig ARGS1(int,sig)
{

    char command[80];

    /* ignore further interrupts */     /*  mhc: 11/2/91 */
    (void) signal (SIGHUP, SIG_IGN);

#ifndef VMS  /* use ttclose() from cleanup() for VMS */
    (void) signal (SIGINT, SIG_IGN);
#endif

    (void) signal (SIGTERM, SIG_IGN);

#ifndef MSDOS
    if (sig != SIGHUP) {
#else
    if (TRUE) {
#endif
	cleanup(); /* <==also calls cleanup_files() */
	printf("\nExiting via interrupt: exit(%d)\n",sig);
	fflush(stdout);
    }

#ifdef TRAVERSAL
    dump_traversal_history();
#endif

#ifdef VMS
    exit(0);
#else
    exit(sig);
#endif VMS
}


