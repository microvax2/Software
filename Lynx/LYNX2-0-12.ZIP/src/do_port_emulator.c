#include "defs.h"

/* this routine takes a commandline such as
 * !port@host
 * where port is a positive integer and host is a 
 * valid internet address
 *  It then parses the port and host and passes it
 *  on to emulator to connect to the port and emulate a vt100
 *  terminal
 */

PUBLIC void do_port_emulator ARGS2(char *,commandline, char *,newfile)
{
	char *tmptr;
	char host[80], cport[10];
	int iport;
	char *tmpfile;

#ifdef VMS
	char *ttytype="vt100";  /* not defined under VMS */
#endif VMS
	
	tmptr = strchr(commandline,'@');

	mystrncpy(cport,commandline+1, tmptr-commandline-1);

	iport = atoi(cport);

	strcpy(host, tmptr+1);

#ifdef EMULATOR
		tmpfile = emulator(host, iport, NULL, NULL, NULL, TRUE);
#else
	statusline("This link type is not available");
#endif EMULATOR

	/* reset SIGINT */
	signal(SIGINT, cleanup_sig);

	if(strlen(tmpfile) > 0)
	    strcpy(newfile,tmpfile);

	return;
}
