#include "defs.h"

PUBLIC void remove_homepage_link ARGS4(FILE *,in_file, char *,filename, 
				       int,cur, int,cur_offset)
{
    int i, line_to_delete;
    long source, target;
    char deadbuff[128];
    int byteread;

    line_to_delete = cur_offset + links[cur].ly + checkfordefines(in_file);

	/* Code below from Garrett Blythe */
	/*
	 * 	Open file in binary mode for exact seeks
	 */
	fclose(in_file);
	in_file = fopen(filename, "rb+");

	/*
	 * 	Find line to be deleted
	 */
	while(--line_to_delete)
		fgets(deadbuff, 128, in_file);

	/*
	 * 	Remember target position
	 *	Read in line to remove
	 *	Remember source position
	 */
	target = ftell(in_file);
	fgets(deadbuff, 128, in_file);
	source = ftell(in_file);

	while(!feof(in_file))
	{
		/*
		 * 	Find source
		 *	Read character
		 *	Remember source
		 */
		fseek(in_file, source, SEEK_SET);
		if(EOF == (byteread = fgetc(in_file)))
			break;
		source = ftell(in_file);


		/*
		 * 	Find target
		 *	Write character
		 *	Remember target
		 */
		fseek(in_file, target, SEEK_SET);
		fputc(byteread, in_file);
		target = ftell(in_file);
	}


	/*
	 *	Write over rest of file
	 *	Open file in standard read mode
	 */
	fseek(in_file, 0, SEEK_END);
	source = ftell(in_file);
	while(source >= target)
	{
		fputc(' ', in_file);
		source--;
		fseek(in_file, source, SEEK_SET);
	}
	fclose(in_file);
	in_file = fopen(filename, "r");
}
