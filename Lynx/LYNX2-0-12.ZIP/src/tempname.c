#include<stdio.h>
#include"defs.h"

/*
 *	To create standard temporary file names
 */
PUBLIC void tempname ARGS2(char *,namebuffer, int,action)
{
	static unsigned short counter = 0;


	if(action == REMOVE_FILES) { /* REMOVE ALL FILES */ 
	    for(; counter > 0; counter--) {
	        sprintf(namebuffer, "%sLYNX%d%u.", TEMP_SPACE, getpid(), 
								counter-1);
		remove(namebuffer);
	    }
	} else /* add a file */ {
	/*
	 * 	Create name
	 */
	    sprintf(namebuffer, "%sLYNX%d%u.", TEMP_SPACE, getpid(), counter++);
	}
}
