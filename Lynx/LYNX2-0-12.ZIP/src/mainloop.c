#include "defs.h"
#include "HTAccess.h"

#include "WWW/GridText.h"

/*
 * here's where we do all the work
 * mainloop is basically just a big switch dependent on the users input
 * I have tried to offload most of the work done here to procedures to
 * make it more modular, but this procedure still does alot of variable
 * manipulation.  This need some work to make it neater.
 */



void mainloop ()
{
    int  c, arrowup=FALSE, show_help=FALSE, statusline_busy=FALSE;
    int  oldcur = -1, cur = 0, savcur = 0, itmp;
    int  oldline = 0, newline = 1, savline = 1, realline = 1;
    int lines_in_file= -1;
    char oldfile[MAXFNAME], newfile[MAXFNAME], real_name[MAXFNAME];
    char target[MAXTARGET], gopher_info[80];
    char temp[80];
    char prev_target[MAXHIGHLIGHT], prev_link_name[MAXHIGHLIGHT];
    char *cp, *tmptr;
    FILE *fp = NULL, *oldfp;
    BOOLEAN target_present=FALSE;
    BOOLEAN first_file=TRUE;
    extern char orig_dir[];

/*
 *  oldfile contains the name of the file that is currently open
 *  newfile contains the name of the file that will soon be opened if it exits
 *  altfile contains the modified name of newfile to see if the file exits in
 *          lowercase format or in a directory named by the first three letters
 *          of the file name
 *  target contains a search string given by either the user or from a link
 *  target_present tells whether a target is present in the file after searching
 *  		   for it.  If it is set to FALSE then displaying is much faster
 *		   because it does not have to be searched for on a page
 *  gopher_info contains the host and port info needed for automatic address
 * 		translation to take place
 *  prev_target contains the last search string the user searched for
 *  prev_link_name contains the link name that the user last chose to get into
 *		   the current link (file)
 *  oldline, newline, and savline are used to keep track of the last known 
 * 		   current and saved line numbers
 */
      /* initalize some variables*/
    nhist = 0;
    *base1 = '\0';
    strcpy(newfile, startfile);
    strcpy(prev_link_name, "Entry into main menu");
    *target = '\0';
    *prev_target = '\0';
    gopher_info[0] = '\0';
    owner[0] = '\0';
    owner_address[0] = '\0';
    owner_info[0] = '\0';

    while (TRUE) {
	/* if newfile is different then oldfile then we need to go
	 * out and find and load newfile
	 */
	if (!STREQ(oldfile, newfile)) {

get_new_file:
		/* getfile may modify newfile, so save the real name
		 * in real_name so that we have it in case of error 
		 */
		if(strstr(newfile,"LYNX")==NULL)
		   strcpy(real_name, newfile);  

		if(fp)
    		    fclose(fp); /* close current file */

		switch(getfile(newfile,&fp,gopher_info,cur,target)) {


		case NOT_FOUND: 

        	           /* OK! can't find the file */
                           /* so it must not be around now.  Print an error */
                   statusline(LINK_NOT_FOUND);
		   sleep(2);  /* pause for awhile */

		   if(error_logging && !first_file) /* send an error message */
                      mailmsg(cur, owner_address, history[nhist-1].real_name, 
				history[nhist-1].hightext);

			/* do the NULL stuff also and reload the old file */

		case NULLFILE:  /* not supposed to return any file */

		   /* the first file wasn't found or has gone missing */
		   if(nhist==0) { 
			/* if nhist = 0 then it must be the first file */
			cleanup();
			printf("\nlynx: Can't access start file %s\n",startfile);
			exit(1);
		    }

			/* reload the old file, get the name from the
			 * history stack 
			 */
                    strcpy(newfile, pop(&savcur, &savline, prev_link_name,
                                 gopher_info, real_name));

		    oldline = 0;  /* redraw screen */

		    goto get_new_file;  /* go back and load old file */
                    break;

		case LOCAL: 
#ifdef TRAVERSAL
		   /* during traversal build up a list of all links
		    * traversed.  Traversal mode is a special 
		    * feature to traverse every link in the web
		    */	
		   add_to_traverse_list(newfile, prev_link_name);
#endif TRAVERSAL
                   oldline = 0; /* redraw the screen */

		   /* if this was not a WWW search then
		    * set newline to the saved line
		    * savline contains the line the 
		    * user was on if he has been in
		    * the file before or it is 1
 		    * if this is a new file
		    */
		   if(www_search_result == -1) {
                       	newline = savline;
		   } else {
			/* This was a WWW search, set the line
			 * to the result of the search
			 */
		       	newline = www_search_result;
			www_search_result = -1;  /* reset */
		   }
		   realline = savline;  /* save the current line */
		   savline = 1;   /* reset */
		   oldcur = -1;   /* reset */
	  	   break;	
		case GOPHER: 

     		       /* register the remote name
			* and the local file name
		        * so that it can be retrieved
			* from disk from now on instead of
			* going out on the network again
			*/
     		   if(registerremotename(real_name)) {
     		      /* register the local name */
     		       registerlocalname(newfile, gopher_info);
		   }

		   cur = 0;
		   oldcur = -1;  /* reset */
		   /* set oldline to 1 because the file is already
		    * displayed on the screen because it was done
		    * as the file was being transferred
		    */
		   oldline = 1;  /* don't redraw the screen */
		   savline = 1;  /* reset */
		   newline = 1;  /* reset */
		   realline = 1; /* reset */
		   break;
		}  /* end switch */

	   if(TRACE)
	      sleep(1); /* allow me to look at the results */

	   /* set the files the same */
	   strcpy(oldfile, newfile);

	   /* reset WWW present mode so that if we were getting
	    * the source, we get rendered HTML from now on
	    */
	   HTOutputFormat = WWW_PRESENT;

           /* set the lines_in_file to unknown */
           lines_in_file = -1;

	    /* if target is not empty and this isnt a WWW file then search
	     * for it
	     */
           if(!IS_WWW_MODE && *target != '\0') {
                        /* find out which line the target is on*/
                rewind(fp); /* just in case */
                checkfordefines(fp);  /* kill any defines at the top */
                newline = findtarget(fp, target, &target_present);
                if(newline<1)
                    newline=1;
		 oldline=0;  /* redraw the screen */

           } else 
		target_present = FALSE;

  	} /* end if(STREQ(newfile,oldfile) */

	/* if the resent_sizechange variable is set to true
	   then the window size changed recently. set oldline
	   to zero to redisplay output to screen.  
	*/
	if(recent_sizechange == TRUE) {
		stop_curses();
		start_curses();
		oldline = 0; /*to force a redraw */
		recent_sizechange=FALSE;
	}

	/* if the oldline is different than newline then there must
	 * have been a change since last update. Run showpage.
	 * showpage will put a fresh screen of text out.
	 * If this is a WWW document then use the 
	 * WWW routine HText_pageDisplay to put the page on
	 * the screen
         */
	if (oldline != newline) {

	    if(IS_WWW_MODE) {
		HText_pageDisplay(newline, prev_target);
		/* if more equals true then there is more
		 * info below this page 
		 */
		more = HText_canScrollDown();
		oldline = newline = HText_getTopOfScreen()+1;
                lines_in_file = HText_getNumOfLines();
                if(strlen(HText_getTitle()) > 0)
		    strcpy(prev_link_name, HText_getTitle());
	    } else {
		/* use the lynx parser to display the file */
	        if (0 > showpage(&fp, &newline, oldline, realline, 
			         target_present, target, newfile, base1, 
				 &savcur, gopher_info, owner) ) {
	            realline = newline = oldline; /* set them all the same */
                }
	   } /* end if WWW_MODE */

	   if (arrowup) { /* arrow up is set if we just came up from
			      a page below */
	        cur = nlinks - 1;
	        arrowup = FALSE;
	   } else {
	        cur = savcur;
	   }
	   savcur = 0; /* reset */
	   realline = oldline = newline; /* set */
	   statusline_busy = FALSE;  /* allow updates to the statusline after 
				        a showpage */
	}

	if(first_file == TRUE) { /* we can never again have the first file */
	   first_file = FALSE;  
	   show_help=TRUE;
	   if(is_www_index && more)
		statusline(WWW_INDEX_MORE_MESSAGE);
	   else if(is_www_index)
		statusline(WWW_INDEX_MESSAGE);
	   else if(more)  /* show some help for the first file */
               statusline(MOREHELP);
           else
               statusline(HELP);
	 }  
		
	/* if help is not on the screen and the statusline isn't
	 * currently busy then put a message on the screen
	 * to tell the user if there is more info below
	 * or if this is an index, or if none of the above
	 * just put some help on the screen
	 */
	if (!show_help && !statusline_busy) 
	    if(is_www_index && more)
		statusline(WWW_INDEX_MORE_MESSAGE);
	    else if(is_www_index)
		statusline(WWW_INDEX_MESSAGE);
	    else if (more)
		statusline(MORE);
	    else
	       statusline(HELP);

	    /* if we are in forms mode then explicitly
	     * tell the user what each kind of link is
	     */
	   if(lynx_mode==FORMS_LYNX_MODE && !statusline_busy) {
		oldcur = cur;
                if(links[cur].type == WWW_FORM_LINK_TYPE)
	            statusline(FORM_LINK_MESSAGE);
                else
	            statusline(NORMAL_LINK_MESSAGE);
	   }

	highlight(ON, cur);	/* highlight current link */

#ifdef TRAVERSAL
	/* this is a special feature to traverse every link in
	 * the database, and look for errors
	 */
	if( lookup(links[cur].lname,links[cur].target)) {
		if(more || (cur > -1 && cur < nlinks-1))
		   c=DNARROW;
		else {
		   if(STREQ(prev_link_name,"Entry into main menu"))
		       exit(0);
		   c=LTARROW;
		}
	} else {
		add_to_table(links[cur].lname,links[cur].target);
		c = RTARROW;
	}
#else
	/* if the winch signal recently came through don't
	   query for a response
	*/ 
	if(recent_sizechange == FALSE)
	  c=mygetch();   /* get user input */
	else
	  c=DO_NOTHING;

#endif TRAVERSAL

        if(vi_keys)   /* convert h,j,k,l to a arrows for vi key users */
	   switch(c) {  /* note: only lowercase keys are mapped :) */
	   case 'j':
		c=DNARROW;
		break;
	   case 'k':
		c=UPARROW;
		break;
	   case 'h':
		c=LTARROW;
		break;
	   case 'l':
		c=RTARROW;
	   }
		
       if(emacs_keys) /* convert ^P, ^N, ^B, ^F to arrows for emacs keys */
	  switch(c) {  /* note: only lowercase keys are mapped :) */
          case 14: /* really control-N, not ^N */
              c=DNARROW;
              break;
          case 16: /* really control-P not ^P */
              c=UPARROW;
              break;
          case 2: /* really control-B not ^B */
              c=LTARROW;
              break;
          case 6: /* really control-F not ^F */
              c=RTARROW;
        }


	/* convert 4, 6, 2, 8 to left, right, down, up, etc. */
	if(keypad_mode == NUMBERS_AS_ARROWS)
	    c = number2arrows(c);

	if(!statusline_busy)
	  if (show_help) {
	    if (more)
		statusline(MORE);
	    else
		statusline((char *) NULL);
	    show_help = FALSE;
	  }


	switch(c) {
	case DO_NOTHING:
	    /* pretty self explanitory */
	    break;
	case '1':
	case '2':
	case '3':
	case '4':
	case '5':
	case '6':
	case '7':
	case '8':
	case '9':
	    /* get a number from the user and follow that link number */
	    switch(follow_link_number(c, &cur)) {
	    case DO_FORMS_STUFF:
		/* change form link returns either 0,1 or -1 to
		 * more the link up down or neither.
		 */
		cur += change_form_link(&links[cur],FORM_UP);
                statusline_busy = TRUE;
		break;

	    case DO_LINK_STUFF:
                    /* follow a normal link */
                do_link(&fp, newfile, oldfile, prev_link_name, target,
                            gopher_info, real_name, newline, cur, 
		            &oldline, &savline, &savcur);
		break;

	    case PRINT_ERROR:
		statusline(BAD_LINK_NUM_ENTERED);
		sleep(1);
		break;
	    }
	
	
	    break;

	case '\\':  /* toggle view source mode */
	     if(IS_WWW_MODE) {
		 if(HTisDocumentSource()) 
	             HTOutputFormat = WWW_PRESENT;
		 else
	             HTOutputFormat = WWW_SOURCE;
	         HTuncache_current_document();
	         *oldfile = '\0';	
	     }
	     break;

	case 18:  /* control R to reload and refresh */
	     if(IS_WWW_MODE) {
	         HTuncache_current_document();
	         *oldfile = '\0';	
		 savline=newline;
	   	 savcur=cur;
#ifdef VMS
	         stop_curses();  /* this will definately clear the screen */
	         start_curses();
#endif VMS
	     }
	     break;

#ifdef NOT_DONE_YET
	case '|':  
	    /* ignore for now */
#endif NOT_DONE_YET

	case 'q':	/* quit */
	case 'Q':
	case 4:
	case EOF:
	    statusline("Are you sure you want to quit? [Y] ");
	    if(toupper(mygetch()) != 'N')
	        return;
	    else {
	        statusline("Excellent!");
		sleep(1);
	    }
	    break;
	
#ifdef VMS
	case 26:  /* CTRL-Z force immediate quit */
	    return;
	    break;
#endif VMS

	case ' ':	/* next page */
	case '+':
	case 44:   /* plus on mac keypad */
	case PGDOWN:  /* page down */
	case 6:	/* control F */
	    if(more)
	       if(IS_WWW_MODE)
	           newline += LINES-2;
	       else
	           newline += LINES-1;
	    break;

	case 'b':	/* prev page */
	case 'B':
	case '-':
	case PGUP:  /* page up */
	case 2:	/* control B */
	   if(newline > 1) {
	       if(IS_WWW_MODE)
	           newline -= LINES-2;
	       else
	           newline -= LINES-1;
	    }
	    break;

	case  16:  /* control p */
	    newline -= 2;
	    break;

	case  14: /* control n */
	    newline += 2;
	    break;

	/* control R DOES NOT wipe the screen any more */
	case 23:  /* control W to wipe the screen */
	   oldline=0;
	   savcur=cur;
#ifdef VMS
	   stop_curses();  /* this will definately clear the screen */
	   start_curses();
#endif VMS
	   break;

	case HOME:
	    newline = 1;
	    break;

	case END:
	    if(more) {
	       newline = MAXINT; /* go to end of file */
	       arrowup = TRUE;  /* position on last link */
	    }
	    break;

	case UPARROW:
	    if (cur>0) {		/* previous link */
		highlight(OFF, cur);   /* unhighlight the current link */
		cur--;

	    } else if(!more && cur==0 && newline==1) { /* at the top of list */ 
		/* if there is only one page of data and the user
		 * goes off the top, then just move the curser to
		 * last link on the page
		 */
		highlight(OFF,cur); /* unhighlight the current link */
		cur = nlinks-1;  /* the last link */

	    } else if (oldline > 1) {	/* previous page */
		/* go back to the previous page */
		if(IS_WWW_MODE)
		    newline -= (LINES-2);
		else
		    newline -= (LINES-1);
		arrowup = TRUE;
	    }
	    break;

	case DNARROW:
	case 9  : /* the TAB key */
	    if (cur<nlinks-1) {		/* next link */
		highlight(OFF, cur);
		cur++;
	    /* at the bottom of list and there is only one page 
	     * move to the top link on the page
	     */
	    } else if(!more && newline==1 && cur==nlinks-1) {
		highlight(OFF,cur); 
		cur = 0;
		if(newline > 1) {
		    newline = 1;
		    oldline = 0;
		}

	    } else if (more) {	/* next page */
	  	if(IS_WWW_MODE)
		    newline += (LINES-2);
		else	
		    newline += (LINES-1);
	    }
	    break;

	case 127: /* delete */  /* show the history page */
	case 8:   /* back space */
	  if(!strstr(oldfile,"LYNX") || !strstr(oldfile,"hist")) {	
		/* don't do if already viewing history page */	

	      	push(oldfile, cur, newline, prev_link_name,
		     gopher_info, real_name, &fp);

		*target = '\0';
	    	showhistory(newfile);
	    	strcpy(real_name,"History File");
	    	strcpy(prev_link_name,"History File");
	    	gopher_info[0] = '\0';
	        break; 
	  } /* end if strncmp */

	/* dont put break here so that if the backspace key is pressed in
	 * the history page, then it acts like a left arrow 
	 */

	case LTARROW:			/* back up a level */
	case 'u':
	case 'U':
	        if (nhist>0) {  /* if there is anything to go back to */

		    /* get the previous file off of the history stack */
		    strcpy(newfile, pop(&savcur, &savline, prev_link_name, 
				   gopher_info, real_name));

	            if(STREQ(newfile, oldfile))
			    *oldfile = '\0';
		    *target = '\0';  /* erase previous target */
		    oldline = 0;

	        } else if(child_lynx==TRUE) {
	   	   return; /* exit on left arrow in main screen */ 
		}
	     break;

	case RTARROW:			/* follow a link */
	case '\n':
	case '\r':
	    if (nlinks > 0) {
	        if(links[cur].type == WWW_FORM_LINK_TYPE) {
		        cur += change_form_link(&links[cur],FORM_UP);
		        statusline_busy = TRUE;

	        } else   /* Not a forms link */
		    /* follow a normal link */
		    do_link(&fp, newfile, oldfile, prev_link_name, target,
			    gopher_info, real_name, newline, cur, &oldline,
			    &savline, &savcur);
	    }
	    break;

	case 'g':   /* 'g' to goto a random file  */
	case 'G':
	 
	    if(anonymous) {
	    	statusline("Anonymous users may not Goto a random URL!");
		sleep(1);
		break;
	    }
	 
	    *newfile = '\0';
	    statusline("Filename or URL to open: "); 
	    Gophergetstr(newfile); /* ask the user */
	    if(*newfile != '\0') {
	    
		/* save the current file */
	        push(oldfile, cur, newline, prev_link_name, 
		     gopher_info, real_name, &fp);

		/* make a name for this new file */
	        strcpy(prev_link_name, "A file specified by the user");
		*gopher_info='\0'; /* reset */
	    } else {
	        strcpy(newfile, oldfile);
	    }
	    break;

	case '?':			/* show help file */
	case 'H':
	case 'h':
	case F1:   /* f1 key */
	    if(!STREQ(newfile, helpfile)) {
	        strcpy (newfile, helpfile);  /* set the filename */

		/* save the current file */
	        push(oldfile, cur, newline, prev_link_name, 
		     gopher_info, real_name, &fp);

		/* make a name for this help file */
	        strcpy(prev_link_name, "Help Screen");
		*gopher_info='\0'; /* reset */
	    }
	    break;

	case 'I':  /* index file */
	case 'i':  /* a special non-WWW, Lynx feature */
		/* make sure we are not in the index already */
	    if(!STREQ(newfile, indexfile)) {

	        if(indexfile[0]=='\0') { /* no defined index */
		    statusline("No index is currently available");
		    sleep(1);
		    statusline_busy = TRUE;

	        } else {
	            strcpy(newfile, indexfile);
		    /* save the current file */
	            push(oldfile, cur, newline, prev_link_name, 
		         gopher_info, real_name, &fp);
	            strcpy(prev_link_name, "System Index"); /* name it */
		    *gopher_info='\0';  /* reset */
	        } /* end else */
	    }  /* end if */
	    break;

	case 'x': 
	case 'X':  /* change form */
	    if(lynx_mode == FORMS_LYNX_MODE) {
		if(links[cur].type == WWW_FORM_LINK_TYPE) {
		    cur += change_form_link(&links[cur],FORM_UP);
		    statusline_busy = TRUE;
		} else {
		    statusline("'X' can only toggle a form link");
		}
	    } else {
		statusline("'X' only toggles in forms mode");
	    }
	    break;	

	case 'z': 
	case 'Z':  /* change form */
	    if(lynx_mode==FORMS_LYNX_MODE) {
		if(links[cur].type == WWW_FORM_LINK_TYPE)
		    cur += change_form_link(&links[cur],FORM_DOWN);
		else
		    statusline("'Z' can only toggle a form link");
	    }else
		statusline("'Z' only toggles in forms mode");
	    break;	

	case 'm':	/* return to main screen */
	case 'M':
		/* if its already the startfile then don't reload it */
	    if(!STREQ(oldfile,startfile)) {
	        strcpy (newfile, startfile);
                strcpy(prev_link_name, "Entry into main menu");
	        highlight(OFF,cur); 
	        nhist = 0;
		*gopher_info = '\0';
	    }
	    break;

	case 'o':     /* options screen */
	case 'O':
	    options(); /* do the options stuff */
	    oldline = 0; /* to repaint screen */
	    break;

	case '/':
	case 's': /* search for a user string */
	case 'S':
	case 'n':  /* search for the next occurance of the user string */
 	case 'N':
	     if(IS_WWW_MODE && is_www_index) {
               /* perform a database search */

		/* do_www_search will try to go out and get the document
		 * if it returns yes a new document was returned and is
		 * named in the newfile
		 */
		if(do_www_search(newfile)) {
		   /* push the old file into history */
	      	   push(oldfile, cur, newline, prev_link_name,
		         gopher_info, real_name, &fp);
		   lynx_mode = WWW_LYNX_MODE;
		
		   /* make the oldfile the newfile so that
		    * getfile doesn't try to get the newfile.
		    * Since we have already gotton it.
		    */ 
		   strcpy(oldfile,newfile);
		   strcpy(real_name, newfile);
		   strcat(prev_link_name," (Search)");
		   oldline = 0; /* redisplay it */
		} else
		   strcpy(newfile, oldfile);  /* restore the old file */

	     } else {
                /* user search */
		if(toupper(c) != 'N')
	     	    *prev_target = '\0';  /* reset old target */
	     	switch(textsearch(fp, &newline, &cur, target, 
			   &target_present, prev_target)) {
		
		case IN_LINKS:
		case DO_NOTHING:
			/* do nothing */
			break;

		case IN_FILE:
		     /* if there is only one page then don't reposition 
		      * the page
		      */
	            if(oldline==1 && !more)
		       newline = 1;
	            oldline=0; /* to force a showpage */
		    break;

		case NOT_FOUND:
	            statusline_busy = TRUE;
		    break;
	         }
	     }
	     break;

	case 'r':
	case 'R':  /* reply by mail */
	case 'c':
	case 'C':
	   statusline("Do you wish to send a comment? [N]");
	   if(toupper(mygetch()) == 'Y') {

	      if((itmp = is_url(owner_address)) != 0 &&
		   itmp != MAILTO_URL_TYPE) { /* the address is a url */
			/* just follow the link */
			
		   strcpy(newfile, owner_address);
		    /* save the current file */
                    push(oldfile, cur, newline, prev_link_name,
                         gopher_info, real_name, &fp);
                    *gopher_info='\0'; /* reset */

	      } else if(itmp == MAILTO_URL_TYPE) {
		/* the owner_address is a mailto: url type */
			/* send a reply. The address is after the colon */
	      	   reply_by_mail(strchr(owner_address,':')+1, real_name); 

	      } else {  /* not a url */
	      	   reply_by_mail(owner_address, real_name); /* send a reply */
	      }
	      oldline = 0;  /* to force a showpage */
	   }
	   break;

	case 'e':  /* edit */
	case 'E':
	   if(*editor != '\0' && !anonymous) {
		if(!IS_WWW_MODE) {
		    rewind(fp);
		    (void) edit_current_file(startdir, newfile, orig_dir, cur,
			 	    newline+checkfordefines(fp));

		} else {
		    if(edit_current_file(startdir,newfile,orig_dir,cur,newline))
	                HTuncache_current_document();
	            *oldfile = '\0';	
		    savline = newline;

		}
		oldline=0; /* to force a showpage */
		savcur=cur;
	   } else if(*editor == '\0') {
		statusline("No editor is defined!");
		sleep(1);
	   }
	   break;

	case '=':  /* show document info */
           /* get the number of lines in the file in not known */
	   if(lines_in_file < 0)
		lines_in_file = get_file_lines(fp);

	   /* show some info */
	   showinfo(cur,real_name,prev_link_name, target, lines_in_file);
	   oldline=0;
	   savcur=cur;
	   break;

	case 'p':
	case 'P':  /* print the file */
		/* don't do if already viewing print options page */	
	   if(!strstr(oldfile,"PRINTOPTIONS")) {	

		/* get the number of lines in the file if not already known */
		if(lines_in_file < 0)
		    lines_in_file = get_file_lines(fp);

		/* save the old file */
	      	push(oldfile, cur, newline, prev_link_name,
		     gopher_info, real_name, &fp);
		*target = '\0';
                print_options(newfile, lines_in_file);
	        strcpy(prev_link_name, "Print Options");
	        strcpy(real_name,"Print Options");
	        gopher_info[0] = '\0';  /* reset */
	        oldline=0;  /* redisplay */
	        statusline_busy=TRUE;

	   }
	   break;

	case 'a':  /* a to add link to bookmark file */
	case 'A':
	   if(!strstr(newfile,"hist") && !strstr(newfile,"PRINTOPTIONS")) {

	      if(links[cur].type == WWW_FORM_LINK_TYPE) {
		statusline("Form links cannot be saved to the bookmark page");
		sleep(1);
	      } else {
		statusline("Do you wish to save this link in your current bookmark file? (y/n)");
		c = mygetch();
		if(toupper(c) == 'Y')
		    save_homepage_link(cur);
	      }
	   } else {
		statusline("History and Print option links cannot be saved in the bookmark page");
		sleep(1);
	   }
		
	   break;

#ifdef NOT_WORKING_YET
	case 'd':  /* delete home page link */
	case 'D':
	    if(strstr(newfile,home_page)) {
		rewind(fp);
		remove_homepage_link(fp, newfile, cur, 
						newline+checkfordefines(fp));
	        oldline = 0;  /* reparse and display file */
		*oldfile = '\0';  /* reopen file */
	    } else {
		statusline("D)elete only works on bookmark page links");
		sleep(1);
	    }
	    break;
#endif NOT_WORKING_YET

	case 'v':   /* v to view home page */
	case 'V':   /* this used to be 'g' for goto */
	    /* see if a home page exists
	     * if it does replace newfile with it's name 
	     */
	    if(get_homepage_name(newfile)) {
	        push(oldfile,cur,newline,prev_link_name,gopher_info,real_name,
			&fp);
	        oldline=0;
	        strcpy(prev_link_name, "Bookmark Page");
	        *gopher_info='\0';
	    } 
	    break;

	case '!':  /* shell escape */
#ifdef VMS
	case '$':  /* VMS shell escape */
#endif VMS
	    if(!anonymous) {
	        stop_curses();
		chdir(orig_dir);
                signal(SIGINT, SIG_IGN);
#ifdef VMS
		printf("Spawning DCL subprocess.  Logout to return to Lynx.");
		fflush(stdout);
		lib$spawn();
#else
		printf(
		 "Spawning your default shell.  Use 'exit' to return to Lynx.\n");
	        fflush(stdout);
	        system(getenv("SHELL"));
#endif VMS
                signal (SIGINT, cleanup_sig);
                chdir(startdir);
	        start_curses();
	        oldline = 0;  /* for a showpage */
	    }
	    break;

	default:
	    if (more)
		statusline(MOREHELP);
	    else
		statusline(HELP);
	    show_help = TRUE;

	    if(TRACE)
	        printw("%d", c);  /* show the user input */

	    break;
	}
    }
}

