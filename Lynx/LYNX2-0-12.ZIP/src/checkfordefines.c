#include "defs.h"

/*
 * checkfordefines checks the top of each file for special lynx commands
 * the current commands recognized are:
 * path : sets a path that is added to the beginning of each file link in the 
 *        file
 * owner : tells who owns the file so that they can receive comments and error
 *         messages
 * link_delimiter : specifies the opening link delimiter
 * end_link_delimiter : specifies the closing link delimiter
 * token_delimiter : specifies the link field seperater
 * target_delimiter : specifies the opening target delimiters [2]
 * end_target_delimiter : specifies the closing target delimters [2]
 *
 */
PUBLIC BOOLEAN checkfordefines ARGS1(FILE *,fp)
{
    int no_lines_used=0, x=0;
    char inputline[LINESIZE+1];

    /* set defaults */   
    *base1 = '\0';

    /* owners and address are now inherited */
    /* *owner = '\0';  /* */
    /* *owner_address = '\0';  /* */
    /* *owner_info = '\0';  /* */

    lynx_mode = NORMAL_LYNX_MODE;
    *form_server = '\0';
    delimiter.link = DEFAULT_LINK_DELIMITER;
    delimiter.end_link = DEFAULT_END_LINK_DELIMITER;
    strcpy(delimiter.target, LEFT_TARGET_DELIMITER);
    strcpy(delimiter.end_target, RIGHT_TARGET_DELIMITER);
    delimiter.token = DEFAULT_TOKEN_DELIMITER;
 
	/* read the first line to check for defines */
     while(fgets(inputline,LINESIZE, fp)) {
	/* heres where we accually get some work done */
	if(defineswitch(inputline) == FALSE)
		break;
	no_lines_used++;
    }
	
      rewind(fp);

	/* skip over any defines if there are any */
      for(; x < no_lines_used; x++)
	fgets(inputline, LINESIZE, fp);

      return(no_lines_used);
}
