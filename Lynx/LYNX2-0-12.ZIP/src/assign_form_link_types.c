#ifdef FORMS

#include "defs.h"

#define LONG_SPACE_STRING "                                                                                                                                 "
#define LONG_STAR_STRING "********************************************************************************"


BOOLEAN assign_form_link_types ARGS3(char *, link_info, int *, col, int, lineno)
{
        char type[256];
        char init[256];
        char name[256];
        char hrange[256];
        char lrange[256];
        char width[256];
        int iwidth;
        int month, day, year;
	char *junk_ptr;

 		    strcpy(type, parse_tag(link_info, "TYPE", &junk_ptr));
                    strcpy(init, parse_tag(link_info, "INIT", &junk_ptr));
                    strcpy(name, parse_tag(link_info, "NAME", &junk_ptr));
                        if(*name == '\0') {
                            return(FALSE);
                        }

		    /* the default width is 8 for all fields with width */
		    strcpy(width, parse_tag(link_info,"WIDTH",&junk_ptr));

		    iwidth = atoi(width);
		    if(iwidth < 1)
		       iwidth = 8;
			

                        /* copy in the name field */
                    StrAllocCopy(links[nlinks].lname,name);

		    start_bold();

			/* check for a valid type and do type specific 
			 * things
			 */
 		    if(mystrstr(type,"BOOLEAN")) {
			if(mystrstr(init, "ON")) {
			    links[nlinks].cur_value = 1;
			    StrAllocCopy(links[nlinks].hightext, "(*)");
			} else {
			    links[nlinks].cur_value = 0;
			    StrAllocCopy(links[nlinks].hightext, "( )");
			}

			links[nlinks].tx = BOOLEAN_TYPE;
 		    } else if(mystrstr(type,"DATE")) {
			/* date type is separated into month, day, year types
			 * each type is then handled seperately by
			 * the link processors
			 */
			
			  process_date(init, &month, &day, &year);

			  /* make month link */
			  StrAllocCopy(links[nlinks].hightext, month_strings[month]);
			  links[nlinks].tx = DATE_MONTH_TYPE;
			  links[nlinks].cur_value = month;

		          addstr(links[nlinks].hightext);
			  addstr(" ");  /* add a space */
		          *col += strlen(links[nlinks].hightext)+1;

			  links[nlinks].type = FORM_LINK_TYPE;

			  /* make day link */
			  nlinks++;

			  sprintf(links[nlinks].hightext,"%2d", day);
			  links[nlinks].tx = DATE_MDAY_TYPE;
			  links[nlinks].cur_value = day;

		          addstr(links[nlinks].hightext);
			  addstr(", ");  /* add a space and comma */

			    /* copy in the position */
		          links[nlinks].lx = *col;
		          links[nlinks].ly = lineno;
		          *col += strlen(links[nlinks].hightext)+2;

			  links[nlinks].type = FORM_LINK_TYPE;

			  /* make year link */
			  nlinks++;

			  sprintf(links[nlinks].hightext,"%4d", year);
			  links[nlinks].tx = DATE_YEAR_TYPE;
			  links[nlinks].cur_value = year;

			    /* copy in the position */
		          links[nlinks].lx = *col;
		          links[nlinks].ly = lineno;

 		    } else if(mystrstr(type,"TIME")) {
			  StrAllocCopy(links[nlinks].hightext,
							process_time(init));

			  links[nlinks].tx = TIME_TYPE;
 		    } else if(mystrstr(type,"INT")) {
			/* if no low range given 
			 * set the lrange to negative MAXINT
			 */
			strcpy(lrange, parse_tag(link_info,"LRANGE",&junk_ptr));
			links[nlinks].lrange = atoi(lrange);
			if(links[nlinks].lrange == 0 && *lrange != '0')
			   links[nlinks].lrange == (-MAXINT);

			/* set the high range */
			/* if no high range given 
			 * set the hrange to MAXINT
			 */
			strcpy(hrange, parse_tag(link_info,"HRANGE",&junk_ptr));
			links[nlinks].hrange = atoi(hrange);
			if(links[nlinks].hrange == 0 && *hrange != '0')
			   links[nlinks].hrange == MAXINT;

			/* copy in the number of spaces for the width */
			StrnAllocCopy(links[nlinks].hightext, LONG_SPACE_STRING,
								       iwidth);

			/* add the init value at the left of the width */
			StrnAllocCopy(links[nlinks].hightext, init, strlen(init));

			links[nlinks].cur_value = atoi(init);
			links[nlinks].tx = INT_TYPE;
 		    } else if(mystrstr(type,"MDAY")) {
			links[nlinks].tx = MDAY_TYPE;
 		    } else if(mystrstr(type,"MONTH")) {
			links[nlinks].tx = MONTH_TYPE;
 		    } else if(mystrstr(type,"YEAR")) {
			links[nlinks].tx = YEAR_TYPE;
 		    } else if(mystrstr(type,"HOUR")) {
			links[nlinks].tx = HOUR_TYPE;
 		    } else if(mystrstr(type,"MIN")) {
			links[nlinks].tx = MIN_TYPE;
 		    } else if(mystrstr(type,"SEC")) {
			links[nlinks].tx = MONTH_TYPE;
 		    } else if(mystrstr(type,"STRING")) {

			/* copy in the number of spaces for the width */
			StrnAllocCopy(links[nlinks].hightext, LONG_SPACE_STRING,
								       iwidth);

			/* add the init value at the left of the width */
			StrnAllocCopy(links[nlinks].hightext, init, 
								strlen(init));

			links[nlinks].tx = STRING_TYPE;
 		    } else if(mystrstr(type,"PASSWORD")) {

			/* we will hide the password info in the
			 * taddr field */
			/* copy in the number of spaces for the width */
			StrnAllocCopy(links[nlinks].taddr, LONG_SPACE_STRING,
								       iwidth);
			StrnAllocCopy(links[nlinks].hightext, LONG_SPACE_STRING,
								       iwidth);

			/* add the init value at the left of the width */
			StrnAllocCopy(links[nlinks].taddr, init, strlen(init));
			StrnAllocCopy(links[nlinks].hightext, LONG_STAR_STRING, 
								strlen(init));

			links[nlinks].tx = PASSWORD_TYPE;
		    } else {
			return(FALSE);
		    }

		   return(TRUE);
}

#endif FORMS
