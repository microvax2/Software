#include "defs.h"

/* will parse the line buffer for a tag of the form
 *   tar="value"
 * and return the value as a string
 *
 * tagptr returns a pointer to the beginning of the tag value if
 * it exists or NULL otherwise
 */
#define MAXVALUE 128

PUBLIC char *parse_tag ARGS3(char *,line_buffer, char *,tag, char **,valptr) 
{

    int i;
    char *tag_ptr;
    static char value[MAXVALUE];
    char *delimiter_ptr;

    /* initalize tagptr */
    *valptr = NULL;

    if((delimiter_ptr = strchr(line_buffer,delimiter.end_link)) == NULL)
	return("");

    if((tag_ptr = mystrstr(line_buffer,tag)) == NULL) {
           return("");     
    }

    if(tag_ptr > delimiter_ptr)
	return("");

    tag_ptr += strlen(tag);  /* go past the tag */

    while(isspace(*tag_ptr)) tag_ptr++; /* kill spaces */

    if(*tag_ptr != '=') {  /* find the equals */
        return("");
    }

    tag_ptr++;  /* go past the = */

    while(isspace(*tag_ptr)) tag_ptr++; /* kill spaces */
        
    if(*tag_ptr != '\"') {  /* find the quote */
        return("");
    }

   tag_ptr++;  /* go past the " */

   *valptr = tag_ptr;  /* set the valptr to the beginning of the value */

   for(i=0; *tag_ptr != '\"' && i < MAXVALUE; tag_ptr++, i++) {
        if(*tag_ptr == '\0' ) {
            return("");
	}
        value[i] = *tag_ptr;
   }

   value[i] = '\0';  /* terminate the string */

   return(value);

}



