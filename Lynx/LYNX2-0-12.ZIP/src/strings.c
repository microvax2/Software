#include "defs.h"
#include <ctype.h>

/*      Allocate a new copy of a string, and returns it
*/
PUBLIC char * SNACopy
  ARGS3 (char **,dest, CONST char *,src, int,n)
{
  if (*dest) free(*dest);
  if (! src)
    *dest = NULL;
  else {
    *dest = (char *) calloc (n + 1,1);
    if (*dest == NULL) outofmem(__FILE__, "SNACopy");
    strncpy (*dest, src, n);
    *(*dest + n) = '\0'; /* terminate */
  }
  return *dest;
}

/*      String Allocate and Concatenate
*/
PUBLIC char * SNACat
  ARGS3 (char **,dest, CONST char *,src, int,n)
{
  if (src && *src) {
    if (*dest) {
      int length = strlen (*dest);
      *dest = (char *) realloc (*dest, length + n + 1);
      if (*dest == NULL) outofmem(__FILE__, "SNACat");
      strncpy (*dest + length, src, n);
      *(*dest + length + n) = '\0'; /* terminate */
    } else {
      *dest = (char *) calloc (strlen(src) + 1,1);
      if (*dest == NULL) outofmem(__FILE__, "SNACat");
      strncpy (*dest, src,n);
      *dest[n] = '\0'; /* terminate */
    }
  }
  return *dest;
}


