#include "defs.h"
#include <time.h>

/*
 * display (or hide) the status line
 */

PUBLIC void statusline ARGS1(char *,text)
{
#ifdef VMS
    int savex, savey;
    int curx, cury;
#endif

    /* make sure text is not longer than COLS */
    if(text != NULL) 
	if(strlen(text) >= COLS-1)
	     text[COLS-1] = '\0';

    move(LINES-1,0);
    clrtoeol();
    if (text != NULL) {
	start_reverse();
	addstr(text);
	stop_reverse();
    }
#ifdef VMS
	mvcur(savey, savex, cury, curx);
#endif

    refresh();
}
