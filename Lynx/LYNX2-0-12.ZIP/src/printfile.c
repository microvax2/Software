#include "defs.h"

/*
 *  printfile prints out the current file minus the links and targets 
 *  to a veriaty of places
 */

/* it parses an incoming link that looks like
 *
 *  %%LOCAL_FILE lines="##"
 *  %%MAIL_FILE lines="##"
 *  %%TO_SCREEN lines="##"
 *  %%PRINTER   number="#" lines="##"
 */

#define TO_FILE   1
#define TO_SCREEN 2
#define MAIL      3
#define PRINTER   4

PUBLIC void printfile ARGS3(char *,newfile, char *,sug_filename, 
			    char *,link_info)
{
    char buffer[LINESIZE];
    int lines_in_file=0;
    int printer_number;
    int pages=0;
    char filename[256];
    char user_response[256];
    int type, c;
    FILE *outfile_fp;
    char *cp, *cp2;
    FILE *fp;
    char *address_ptr1, *address_ptr2;
    printer_type *cur_printer;

    if(!IS_WWW_MODE)
        if((fp = fopen(newfile,"r")) == NULL) {
	    statusline("ERROR - Could not open file for printing");
	    sleep(1);
	    return;
        }

    /* get the number of lines in the file */
    if((cp = strstr(link_info, "lines=")) != NULL) {
        /* number of charters in lines= plus the quote */
	cp += 7;
        /* make the second quote null */
	if((cp2 = strchr(cp,'\"')) != NULL)
	    cp2 = NULL;

	lines_in_file = atoi(cp);

	pages = lines_in_file/66;
    }
	

    /* determine the type */
    if(strstr(link_info, "LOCAL_FILE")) {
	type = TO_FILE;
    } else if(strstr(link_info, "TO_SCREEN")) {
	type = TO_SCREEN;
    } else if(strstr(link_info, "MAIL_FILE")) {
	type = MAIL;
    } else if(strstr(link_info, "PRINTER")) {
	type = PRINTER;

        if((cp = strstr(link_info, "number=")) != NULL) {
            /* number of charters in number= plus the quote */
            cp += 8;
            /* make the second quote null */
            if((cp2 = strchr(cp,'\"')) != NULL)
                cp2 = NULL;

            printer_number = atoi(cp);
        }
    }

    switch(type) {
	case TO_FILE:
		statusline("Please enter a file name: ");
		strcpy(filename, sug_filename);  /* add suggestion info */
		/* make the sug_filename conform to system specs */
		change_sug_filename(filename);
		if(Gophergetstr(filename) < 0) {
                     statusline("Print request cancelled!!!");
                     sleep(1);
                     return;
                }


#ifdef UNIX
	/* see if file will open in current directory where lynx was started */ 
                sprintf(buffer,"%s/%s",getenv("PWD"),filename);

                if((outfile_fp = fopen(buffer,"w")) == NULL) {
   	/* if it doesn't open, try to save it in the 'HOME' directory */
#endif
 
                  if(*filename != '/' && *filename != '\\') {
#ifdef UNIX
	              if(*filename == '~') {
	                  strcpy(buffer,getenv("HOME"));
	                  strcat(buffer,filename+1); /* skip over the ~ */
	                  strcpy(filename,buffer);
	              }
	              else {
	                  strcpy(buffer,getenv("HOME"));
	                  strcat(buffer,"/");
	              } /* end if-else */
#endif UNIX
            
#ifdef VMS
                    strcpy(buffer,"sys$login:");
#endif VMS
            
#ifdef MSDOS
                    strcpy(buffer, PRINT_DIR);
                    strcat(buffer,"\\");
#endif MSDOS
            
            
                    strcat(buffer,filename);
                    strcpy(filename,buffer);
                   } /* end if-else */
            
                  if((outfile_fp = fopen(filename,"w")) == NULL) {
	              statusline("unable to open output file!!!");
	              sleep(1);
	              return;
                  }
#ifdef UNIX
                } /* end of if(outfile_fp ==NULL from way up top */
#endif UNIX

		if(IS_WWW_MODE)
		    print_wwwfile_to_fd(outfile_fp);
		else
                    print_to_fd(fp, outfile_fp);

		fclose(outfile_fp);
		break;

	case MAIL: 
		statusline("Please enter a valid internet mail address: ");
		strcpy(user_response, personal_mail_address);
		if(Gophergetstr(user_response) < 0 || *user_response == '\0') {
		    statusline("Mail request cancelled!!!");
		    sleep(1);
		    return;
		}

		change_sug_filename(sug_filename);
#ifndef VMS 
		sprintf(buffer,"%s -t", (child_lynx ? "mail" : SYSTEM_MAIL));

		if ((outfile_fp = popen(buffer, "w")) == NULL) {
			statusline("ERROR - Unable to mail file");
			sleep(1);
                        return;
		}
		
		if(IS_WWW_MODE)
		    fprintf(outfile_fp,"X-within-URL:%s\n",newfile);
		fprintf(outfile_fp,"To:%s\nSubject:%s\n\n",user_response,
								sug_filename);

		if(IS_WWW_MODE)
		    print_wwwfile_to_fd(outfile_fp);
		else
		    print_to_fd(fp, outfile_fp);

		pclose(outfile_fp);
#else  /* VMS stuff */
		if (strchr(user_response,'@') && !strchr(user_response,':') &&
		   !strchr(user_response,'%') && !strchr(user_response,'"')) {
		    sprintf(filename, MAIL_ADRS, user_response);
		    strcpy(user_response, filename);
		}

		/* create a temp file */
		tempname(filename);
		if((outfile_fp = fopen(filename,"w")) == NULL) {
		    statusline("Unable to open tempfile");
		    sleep(1);
		    return;
		}

		/* write the contents to a temp file */
		if(IS_WWW_MODE)
		    print_wwwfile_to_fd(outfile_fp);
		else
		    print_to_fd(fp, outfile_fp);
		fclose(outfile_fp);

		remove_quotes(sug_filename);
		sprintf(buffer,"%s/subject=\"%s\" %s %s", 
			SYSTEM_MAIL, sug_filename, filename, user_response);

        	stop_curses();
		printf("Mailing file.  Please wait...");
		signal(SIGINT, SIG_IGN);
        	system(buffer);
		signal(SIGINT, cleanup_sig);
        	start_curses();
#endif VMS
		break;
	
	case TO_SCREEN:
		if(pages > 4) {
		    sprintf(filename,"File is %d pages long.  Are you sure you want to print? [y]",pages);
 		    statusline(filename);
		    c=mygetch();
    		    if (c == RTARROW || c == 'y' || c== 'Y'
                         || c == '\n' || c == '\r')
                        addstr("   Ok...");
		    else
			return;
		}

		statusline("Press RETURN to begin: ");
		*filename = '\0';
		if (Gophergetstr(filename) <0) {
		      statusline("Print request cancelled!!!");
	              sleep(1);
	              return;
                }

		outfile_fp = stdout;

		stop_curses();

		if(IS_WWW_MODE)
		    print_wwwfile_to_fd(outfile_fp);
	 	else	
                    print_to_fd(fp, outfile_fp);

		fprintf(outfile_fp,"\n\nPress RETURN to finish");

		fflush(stdout);  /* refresh to screen */
		mygetch();  /* grab some user input to pause */
		start_curses();
		break;
	
	case PRINTER: 
		if(pages > 4) {
		    sprintf(filename,"File is %d pages long.  Are you sure you want to print? [y]",pages);
 		    statusline(filename);
		    c=mygetch();
    		    if (c == RTARROW || c == 'y' || c== 'Y'
                         || c == '\n' || c == '\r')
                        addstr("   Ok...");
		    else
			return;
		}

		
		sprintf(filename,"%sLYNXprint%d",TEMP_SPACE,getpid());
#ifdef VMS
	        strcat(filename,".prt");
#endif VMS
                if((outfile_fp = fopen(filename,"w")) == NULL) {
	            statusline("ERROR - Unable to allocate file space!!!");
	            sleep(1);
	            return;
                }

		if(IS_WWW_MODE) {
		    print_wwwfile_to_fd(outfile_fp);
		} else {
		    print_to_fd(fp, outfile_fp);
		}

		fclose(outfile_fp);
		/* move the curser to the top of the screen so that
		 * output from system'd commands don't scroll up 
                 * the screen
		 */
		move(1,1);

		/* find the right printer number */
		{
		    int count=0;
		    for(cur_printer = printers; count < printer_number;
				    count++, cur_printer = cur_printer->next)
			; /* null body */
		}

		/* commands have the form "command %s [etc]"
		 * where %s is the filename
		 */
		if(cur_printer->command != NULL) {
		    sprintf(buffer,cur_printer->command,filename);
		} else {
		    statusline("ERROR! - printer is misconfigured");
		    sleep(2);
		    return;
		}

		stop_curses();
		signal(SIGINT, SIG_IGN);

		if(TRACE)
		    fprintf(stderr,"command: %s\n",buffer);
		system(buffer);
		fflush(stdout);
		signal(SIGINT, cleanup_sig);
		start_curses();
		/* don't remove(filename); */
	} /* end switch */
}	

int remove_quotes ARGS1(char *,string)
{
   int i;

   for(i=0;string[i]!='\0';i++)
	if(string[i]=='"')
	   string[i]=' ';
	else if(string[i]=='&')
	   string[i]=' ';
	else if(string[i]=='|')
	   string[i]=' ';
}
