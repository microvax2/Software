#include "defs.h"

/*
 * mystrstr will find the first occurence of the string pointed to by tarptr
 * in the string pointed to by chptr.  It ignores text between link delimiters.
 * It is also a case insensitive search.
 */
PUBLIC char *linkless_search ARGS2(char *,chptr, char *,tarptr)
{
    char *tmpchptr, *tmptarptr;
    BOOLEAN flag=FALSE;

    for(; *chptr != '\0'; chptr++) {
	if(*chptr == delimiter.link) {
	    for(tmpchptr = chptr+1; *tmpchptr != delimiter.link &&
	        *tmpchptr != delimiter.end_link && *tmpchptr != '\0';
		tmpchptr++)
		    ; /*null body*/
	    if(*tmpchptr == delimiter.end_link)
		chptr = tmpchptr;
	}

	if(*chptr == *tarptr) {	
	    /* see if they line up */ 
	    for(tmpchptr = chptr+1, tmptarptr = tarptr+1;
	         (*tmpchptr) == (*tmptarptr)
		 && *tmptarptr != '\0' && *tmpchptr != '\0';
	        *tmpchptr++, *tmptarptr++)
		   ; /* null body */ 
	    if(*tmptarptr == '\0') {
		flag = TRUE;
	  	break;
	    }
	}

    } /* end for */

    if(flag)
	return(chptr);
    /*else*/
	return(NULL);

}	
