#include "defs.h"

/**************
** This bit of code catches window size change signals
**/

#ifdef VMS
#define NO_SIZECHANGE
#endif
#ifdef SNAKE
#define NO_SIZECHANGE
#endif


PUBLIC void size_change ARGS1(int,sig)
{
#ifndef NO_SIZECHANGE
     static struct      winsize zewinsize;        /* 4.3 BSD window sizing */

	/* set recent_sizechange to LINES to make it true and to
	   remember the old amount of lines on a page
	*/
     recent_sizechange=TRUE; 
     if (ioctl(0, TIOCGWINSZ, (char *) &zewinsize) == 0) {
	  LINES = zewinsize.ws_row;
	  COLS = zewinsize.ws_col;
     } else {
	  /* code here to use sizes from termcap */
     }
#endif NO_SIZECHANGE
}


