#include "defs.h"

PUBLIC BOOLEAN do_remote_command ARGS3(int,type, char *,lname, char *,newfile)
{
	/* parse a line that looks like this 
	 *	!command@host [-user=USER] [-password=PASSWORD]
	 *	!TELNET@host [port] [-user=USER]
	 *	!TN3270@host [port] [-user=USER]
	 *	!RLOGIN@host [-user=USER]
	 * and make it look like a normal rsh or rexec
	 * currently does not support password option on RLOGIN
	 */

	BOOLEAN flag=FALSE;
	int count;
	char *x;
	char *tmptr;
	char *host;
	char *user;
	char *disp;
	char command[MAXCOMMAND];
	char rcommand[MAXCOMMAND];
	char *password;
	char *blank="";
	char port[8];
	char *tmpfile;
	
	/* initialize */
	password = NULL;
	user = NULL;

	/* strip all the slashes */
	tmptr=lname;
	for(x=lname; *x != '\0' ;x++)
	  if(*x != '\\') {
	   *tmptr = *x;    /* don't print slashes */
	   tmptr++;
	  }
	  else if(*(x+1) == '\\') {
	   *tmptr = *x;  /* print one slash if there are two */
	   tmptr++;
	  }
	*tmptr = '\0';

	/* get host name */
	tmptr = strchr(lname,'@');
	*tmptr = '\0';
	host = tmptr+1;


	if((user = strstr(host,"-user")) != NULL) {
	    *user = '\0';
	    /* get rid of preceding spaces */
	    tmptr = user;
	    while(isspace(*(tmptr-1)))
		tmptr--;
	    *tmptr = '\0';
 
	    user++;
	    if((tmptr = strchr(user,'=')) != NULL &&
		(!strchr(user,' ') || strchr(user,' ') > tmptr)) {
		user = tmptr+1;
		while(isspace(*user))
		    user++;
	    } else {
		user += 4;
		while(isspace(*user))
		    user++;
	    }
	}


	if((password = strstr(host,"-password")) != NULL ||
	   (user != NULL && (password = strstr(user,"-password")) != NULL)) {
	    *password = '\0';  
	    /* get rid of preceding spaces */
	    tmptr = password;
	    while(isspace(*(tmptr-1)))
		tmptr--;
	    *tmptr = '\0';

	    password++;
	    if((tmptr = strchr(password,'=')) != NULL) {
		password = tmptr+1;
		while(isspace(*password))
		    password++;
	    } else {
		password += 8;
		while(isspace(*password))
		    password++;
	    }
	}

	if((disp = strstr(lname,"DISPLAY")) != NULL) {
	    if(display != NULL) {
	    	mystrncpy(command,lname+1,disp-lname-1);
	   	strcat(command, display);
	    	strcat(command,disp+7);
	    } else {
		statusline("This link is not available without a DISPLAY setting");
		sleep(1);
		return(FALSE);
	    }
	} else
	    strcpy(command, lname+1);

	/* replace LYNX with a temp file */
	if((disp = strstr(command,"LYNX")) != NULL) {
		flag=TRUE;
		/* use rcommand as temp space */
		mystrncpy(rcommand, command, disp-command);	

		/* make a temp file name */
		tempname(newfile, NEW_FILE);
		strcat(rcommand, newfile);  /* add the filename on */ 
		strcat(rcommand, disp+4); /* along with the rest of command */
		strcpy(command, rcommand);
	}

	/* get port number if there is one */
	if((tmptr = strchr(host,' ')) != NULL) {
	    *tmptr = '\0';
	    tmptr++;
	    for(count=0;count<8 && isdigit(*tmptr);tmptr++,count++)
		port[count]= *tmptr;
	    port[count] = '\0';
	} else
	    port[0] = '\0';

	switch(type) {
	case REXEC_T:
	    if(flag) {
	       if(user==NULL)
	           sprintf(rcommand,"%s %s -l %s %s",RSH_COMMAND,host,
				user,command);
	       else
	           sprintf(rcommand,"%s %s %s",RSH_COMMAND,host,command);
	    } else	
	       sprintf(rcommand,"executing %s at %s",command,host);
	    statusline(rcommand);
	    if(flag) {
		    /* if flag then the output is coming back to Lynx */
		    /* the way to get it is let the system handle it  */
		signal(SIGINT, SIG_IGN);
	        system(rcommand);
		signal(SIGINT, cleanup_sig);
	    } else {
		    /* otherwise use emulator and the rexec call */
	        if(user==NULL)
	            user=blank;
	        if(password==NULL)
	            password=blank;
#ifdef EMULATOR
	        clear();   /* clear the screen */
		tmpfile = emulator(host,0,user,password,command,TRUE);
		if(strlen(tmpfile) > 0) {
		    strcpy(newfile,tmpfile);
		    flag = TRUE;  /* returning a file */
		}
#else
	 	statusline("This client does not support this link type!!");
		sleep(1);
#endif EMULATOR
	        /* reset SIGINT */
	        signal(SIGINT, cleanup_sig);
    	    } /* end if else */	
	    break;

	case TELNET:
#ifdef UNIX
	    sprintf(rcommand,"%s %s %s",TELNET_COMMAND, host, port);
#endif UNIX
#ifdef VMS
	    if(*port != '\0')
	        sprintf(rcommand,"%s %s /port=%s",TELNET_COMMAND, host, port);
	    else
	        sprintf(rcommand,"%s %s",TELNET_COMMAND, host);
#endif VMS
	    statusline(rcommand);
	    stop_curses();
	    signal(SIGINT, SIG_IGN);
	    system(rcommand);
	    fflush(stdout);
	    signal(SIGINT, cleanup_sig);
	    start_curses();
	    break;

	case TN3270:
#ifdef UNIX
	    sprintf(rcommand,"%s %s %s",TN3270_COMMAND, host, port);
#endif UNIX
#ifdef VMS
	    if(*port != '\0')
	        sprintf(rcommand,"%s %s /port=%s",TELNET_COMMAND, host, port);
	    else
	        sprintf(rcommand,"%s %s",TELNET_COMMAND, host);
#endif VMS
	    statusline(rcommand);
	    stop_curses();
	    signal(SIGINT, SIG_IGN);
	    system(rcommand);
	    fflush(stdout);
	    signal(SIGINT, cleanup_sig);
	    start_curses();
	    break;

	case RLOGIN:
#ifdef UNIX
	    sprintf(rcommand,"%s %s",RLOGIN_COMMAND, host);
	    if(user != NULL) {
		strcat(rcommand," -l ");
		strcat(rcommand,user);
	    }
#endif UNIX
#ifdef VMS
	    sprintf(rcommand,"%s %s",RLOGIN_COMMAND, host);
	    if(user != NULL) {
		strcat(rcommand," /user=");
		strcat(rcommand,user);
	    }
#endif VMS
	    statusline(rcommand);
	    stop_curses();
	    signal(SIGINT, SIG_IGN);
	    system(rcommand);
	    fflush(stdout);
	    signal(SIGINT, cleanup_sig);
	    start_curses();
	    break;
	} /* end switch */
	   

	return(flag);
}
