#include "defs.h"

void freelistings PARAMS((void));
/*
 *	Structure to hold listing of all remote files downloaded
 */
typedef struct _islocalnow
{
	char *rname;
	char *lname;
	char *gopher_info;
	struct _islocalnow *next;
}
localized;

/*
 * 	Global variable to always point to front of list
 */
localized *home;

/*
 *	replacebylocal will take a filename, see if we have already
 *	downloaded it, if so will copy over the filename replacing it
 *	with the local filename and return 1.  If not in history list
 *	then will return 0.
 *	This function should not be called in the following instance:
 *		registerremotename has been called and
 *		registerlocalname has not been called
 */
PUBLIC int replacebylocal ARGS2(char *,remotename, char *,gopher_info)
{
	static char firsttime = 1;
	localized *current = home;

	/* atexit freelistings(); */ /* don't bother freeing the listings */

	/*
	 *	First time that function is called
	 *	Initialize variables
	 */
	if(firsttime)
	{
		current = home = NULL;
		firsttime = 0;
	}

	/*
	 * 	Loop through list.
	 */
	while(current)
	{
		/*
		 *	If same name, copy over name replacing with local
		 *	name.
		 */

		if(!strcmp(remotename, current->rname))
		{
			strcpy(remotename, current->lname);
			strcpy(gopher_info, current->gopher_info);
			return(1);
		}
		current = current->next;
	}
	/*
	 *	If got out of above loop, name was not in list.
	 */

	return(0);
}

/*
 *	WARNING!!!	registerremotename assumes that this function
 *	will be called before registerlocalname.  If not these routines
 *	will will not work correctly.  Registerremotename will create
 *	a new link in the list pointed to by home and add the remote file
 *	name to the new link.  The local file name will have to be provided
 *	by a call to registerlocalname.
 */
PUBLIC int registerremotename ARGS1(char *,name)
{
	localized *current = home;
	char *cp;

	  /* These Gopher types are dynamic and should not
	   * be saved statically
	   */
	if(!strncmp(name,"7-", 2) /* INDEX */ ||
	   !strncmp(name,"2-", 2) /* CSO */)
	    return(FALSE);

	  /* test to see if it is a gopher URL with INDEX or CSO type */
	if(!strncmp(name,"gopher", 6)) {
            if((cp = strchr(name+11,'/')) != NULL &&
                ( *(cp+1) == '7' || *(cp+1) == '2' ) )
                return(FALSE);
	}


	/*
	 *	If the list exists already.
	 */
	if(home)
	{
		/*
		 *	Find end of list
		 */
		while(current->next)
			current = current->next;
		/*
		 *	Create new link
		 */
		current->next = (localized *)malloc(sizeof(localized));
		current = current->next;
		current->next = NULL;
	}
	/*
	 * 	List does not exist.  Create first entry.
	 */
	else
	{
		home = (localized *)malloc(sizeof(localized));
		home->next = NULL;
		current = home;
	}

	/*
	 *	Allocate name space and copy the remote file name into
	 *	the link field.
	 */
	current->rname = (char *)malloc(strlen(name) + 1);
	strcpy(current->rname, name);

	return(TRUE);
}

/*
 *	registerlocalname will only work correctly if registerremotename is
 *	called before.  If not results will be wild since a list may not
 *	exist or the last entry will point to a new local file.
 */
PUBLIC void registerlocalname ARGS2(char *,name, char *,gopher_info)
{
	localized *current = home;

	/*
	 *	Go to end of list.  Assume list exists.
	 */
	while(current->next)
		current = current->next;

	/*
	 *	Allocate name space and copy local name into space.
	 */
	current->lname = (char *)malloc(strlen(name) + 1);
	strcpy(current->lname, name);
	current->gopher_info = (char *)malloc(strlen(gopher_info) + 1);
	strcpy(current->gopher_info, gopher_info);
}

/*
 * 	Free memory allocated to local file history list
 */
PUBLIC void freelistings ()
{
	localized *current;

	while(home)
	{
		current = home;
		home = home->next;
		free(current);
	}
}
