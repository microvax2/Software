#include "defs.h"

PUBLIC void do_link ARGS12(FILE **,fp, char *,newfile, char *,oldfile, 
		char *,prev_link_name, char *,target, char *,gopher_info, 
		char *,real_name, int,newline, int,cur, int *,oldline, 
		int *,savline, int *,savcur)
{
	char *port;
	int url_type;

	if(links[cur].lname[0] == '#' || links[cur].lname[0]=='%') {  

	    if(strstr(oldfile, "LYNXhist")) {  
		/* in the history file don't push it and
		   get savcur, savpage from history stack */
	        strcpy(newfile, pop_num(atoi(&links[cur].lname[1]), 
			        savcur, savline, prev_link_name, gopher_info,
				real_name));
		/* add a little description to the link name */
		strcat(prev_link_name, "\n                      (From the history page)");

	    } else 
#ifdef MSDOS
	            if(strstr(oldfile, "PRINT.OPT")) {  
#else
	            if(strstr(oldfile, "PRINTOPTIONS")) {  
#endif MSDOS
		/* handle the print options VERY differently */
		/* pop the old file back */
	        strcpy(newfile, pop(savcur, savline, 
		      prev_link_name, gopher_info, real_name));
	        *target = '\0';  /* erase previous target */
	        oldline = 0;

		/* set to WWW mode so that printfile knows how to
		 * print the file
		 */
		if((url_type = is_url(newfile)) != 0 && 
						url_type != GOPHER_URL_TYPE)
		    lynx_mode = WWW_LYNX_MODE;

		/* print the file using printfile */
                /* then let normal means reload the old file */
		printfile(newfile, prev_link_name, links[cur].lname);

	    } else {
		/* its an unknown link type */
		statusline("This link type is not available in Lynx Ver 1.0");
		sleep(1);
	    }
	} else if(links[cur].lname[0] == '!') {  /* its a command */

		push(oldfile, cur, newline, prev_link_name,
			     gopher_info, real_name, fp);
		if(do_command(cur, newfile, target)) {
			/* output comes back to lynx */
		   gettargetname(target,cur);
		   strcpy(prev_link_name, links[cur].hightext);
		   gopher_info[0] = '\0'; /* not a gopher file */
		}
		else { /* reload the old file */
	          strcpy(newfile, pop(savcur, savline, prev_link_name,
		                    gopher_info, real_name));
		  *oldfile = '\0';
		}
	        oldline=0;  /* to force a showpage */
		
	} else {   /* it's a link  */

	    strcpy(newfile, links[cur].lname);
	    gettargetname(target, cur);

		/* its a normal file link type */
            push(oldfile, cur, newline, prev_link_name,
                            gopher_info, real_name, fp);
            strcpy(prev_link_name, links[cur].hightext);
		
           if(STREQ(newfile, oldfile))
                    *oldfile = '\0';

	}
}
