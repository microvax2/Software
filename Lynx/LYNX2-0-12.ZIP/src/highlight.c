#include "defs.h"

/*
 * highlight (or unhighlight) a given link
 */
PUBLIC void highlight ARGS2(int,flag, int,cur)
{
    char buffer[200];

    if (nlinks > 0) {
	move(links[cur].ly, links[cur].lx);
	if (flag == ON) { 
	   /* makes some terminals work wrong because
	    * they can't handle two attributes at the 
	    * same time
	    */
	   /* start_bold();  */
	   start_reverse();
      	 } else {
	   start_bold();
	 }

      if(links[cur].type == WWW_FORM_LINK_TYPE) {
	int len;
	int avail_space = (COLS-links[cur].lx)-1;

        mystrncpy(buffer,links[cur].hightext, avail_space);
        addstr(buffer);  
  
	len = strlen(buffer);
	for(; len < links[cur].form->size && len < avail_space; len++)
	    addch('_');

      } else {
								
           /* copy into the buffer only what will fit within the
	    * width of the screen
	    */
          mystrncpy(buffer,links[cur].hightext, COLS-links[cur].lx-1);
          addstr(buffer);  
      }

      if (flag == ON) 
          stop_reverse();
      stop_bold();

      move(LINES-1,COLS-1);  /* get curser out of the way */

      refresh();
    }
}
