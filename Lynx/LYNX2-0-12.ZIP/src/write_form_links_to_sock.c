#include "defs.h"

PUBLIC void write_form_links_to_sock ARGS2(int,sockfd, FILE *,form_file)
{
    char *place_ptr, *link_start_ptr, *link_end_ptr;
    char line_buffer[LINESIZE];
    char *junk_ptr;

    rewind(form_file);

    /* go past the defines at the top - there is at least one */
    fgets(line_buffer, LINESIZE, form_file);  /* get the first line */
    while(defineswitch(line_buffer) && fgets(line_buffer, LINESIZE, form_file))
	; /* null body */

    while(fgets(line_buffer, LINESIZE, form_file)) {

	for(place_ptr=line_buffer; *place_ptr != '\0'; place_ptr++) {

	    if(*place_ptr == delimiter.link && *(place_ptr+1) == '#') {

		 link_end_ptr = link_start_ptr = place_ptr+2;

		 for(; *link_end_ptr != delimiter.link &&
                        *link_end_ptr != delimiter.end_link &&
                          *link_end_ptr != '\0'; link_end_ptr++) 
                    ;  /* null body */
 
		 if(*link_end_ptr == delimiter.end_link &&
                        link_end_ptr - link_start_ptr <= MAXFNAME+MAXTARGET) {
                   /* it is definately a link */
 
		     writestring(sockfd, 
				parse_tag(link_start_ptr, "NAME", &junk_ptr));
		     writestring(sockfd, "\t");
	 	     writestring(sockfd,
		     		parse_tag(link_start_ptr, "INIT", &junk_ptr));
		     writestring(sockfd, "\r\n");

		     place_ptr += link_end_ptr-link_start_ptr;
		  }  /* end if */

	     }  /* end if */
	}  /* end for */
    }  /* end while */

}  /* end procedure */

		



