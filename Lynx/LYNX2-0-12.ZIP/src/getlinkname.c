#include "defs.h"

/*
 * extract the linkname portion of a link <filename:#:target>linkname
 */

PUBLIC void getlinkname ARGS2(char *,buf, int,cur)
{
    char *cp;

    if (nlinks > 0) {
	for (cp=links[cur].lname;
	     *cp != delimiter.token && *cp != '>' && *cp != '\0' ; cp++) {

	    if(*cp != '\\')  /* don't print slashes */
	    	*buf = *cp, 
	        buf++;
	    else if(*cp == '\\'&&  *(cp+1) == '\\') /*print one slash if there*/
	    	*buf = *cp,                        /* are two in a row */
	        buf++;
	}
	*buf = '\0';
    }
}

