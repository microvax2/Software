#include "defs.h"
#include "HTAnchor.h"       /* Anchor class */

/* the user wants to select a link by number
 * if follow_link_number returns DO_LINK_STUFF do_link will be
 * run immeditely following its execution.
 * if follow_link_number returns PRINT_ERROR an error message will
 * be given to the user, if follow_link_number returns DO_FORMS_STUFF
 * some forms stuff will be done, and if follow_link_number returns
 * DO_NOTHING nothing special will run after it.
 */

PUBLIC int follow_link_number ARGS2(int,c, int *,cur)
{
    char temp[120];
    int link_number;

    temp[0] = c;
    temp[1] = '\0';
    statusline("follow link number: ");
    /* get the number from the user */
    if (Gophergetstr(temp) <0 || strlen(temp) == 0) {
        statusline("Cancelled!!!");
        sleep(1);
        return(DO_NOTHING);
    }

    link_number = atoi(temp);

    if (link_number > 0 && 
		(link_number < nlinks+1 || IS_WWW_MODE) )  {

	if(lynx_mode==FORMS_LYNX_MODE &&
                             links[link_number].type == WWW_FORM_LINK_TYPE) {
       	     *cur = link_number-1;
	     return(DO_FORMS_STUFF);

	} else if(IS_WWW_MODE) {
                      /* get the lname, and hightext,
                       * direct from
                       * www structures and add it to the cur link
                       * so that we can pass it transparently on to
                       * do_link()
                       * this is done so that you may select a link
                       * anywhere in the document, whether it is displayed
                       * on the screen or not!
                       */
		       if(HTGetLinkInfo(link_number, &links[*cur].hightext, 
					 &links[*cur].lname)) {
                           links[*cur].type = WWW_LINK_TYPE;
                           links[*cur].target = empty_string;

			   return(DO_LINK_STUFF);
              		} else {
			   return(PRINT_ERROR);
			}
	} else {
             	    /* follow a normal link */
		    *cur = link_number-1;
	    	    return(DO_LINK_STUFF);
       	}
    } else {
            return(PRINT_ERROR);
    }

}


