#include "defs.h"
#ifdef MSDOS
#include "process.h"   /* for getpid() */
#endif

/*
 * called by Interrupt handler or at quit time.  
 * Erases the temporary files that lynx created
 * temporary files are:
 * TEMP_SPACE LYNX PID() #
 * TEMP_SPACE LYNX PID() hist
 * TEMP_SPACE GoLYNX PID() #
 */
PUBLIC void cleanup_files NOARGS
{
    char filename[80];

	tempname(filename, REMOVE_FILES);
	
	sprintf(filename,"%sLYNX%dPRINTOPTIONS",TEMP_SPACE,getpid());
	remove(filename);
	sprintf(filename,"%sLYNXhist%d",TEMP_SPACE,getpid());
	remove(filename);
	sprintf(filename,"rm -f %sLYNXImage%d",TEMP_SPACE,getpid());
	remove(filename);
	sprintf(filename,"rm -f %sLYNXprint%d",TEMP_SPACE,getpid());
	remove(filename);

}


