#include "defs.h"

/*
 * extract the linkname portion of a link <filename:#:target>linkname
 */

PUBLIC void remove_backslashes ARGS1(char *,buf)
{
    char *cp;

    for (cp=buf; *cp != '\0' ; cp++) {

	if(*cp != '\\')  /* don't print slashes */
	   *buf = *cp, 
	   buf++;
	else if(*cp == '\\' &&  *(cp+1) == '\\') /*print one slash if there*/
	   *buf = *cp,                        /* are two in a row */
	   buf++;
    }
    *buf = '\0';
}

