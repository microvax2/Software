#include "defs.h"

/*
 *  command types:
 *    !TELNET@host -user=xxxxxxxx -passwd=xxxxxxxx      : telnet
 *    !RLOGIN@host -user=xxxxxxxx -passwd=xxxxxxxx      : rlogin
 *    ![command]@host -user=xxxxxxxx -passwd=xxxxxxxx   : rexec
 *    ![port]@host -user=xxxxxxxx -passwd=xxxxxxxx      : emulator
 *    !command						: local command
 */

PUBLIC BOOLEAN do_command ARGS3(int,cur, char *,newfile, char *,target)
{
    BOOLEAN flag=FALSE;
    char Itemp[11];    
    char *tmptr;
    char *tmpfile;

	/* first check if it contains RLOGIN or TELNET or TN3270 */
	if((tmptr = strstr(links[cur].lname, "RLOGIN")) != NULL) {
	    /* add an '@' to make is conform to parsing routine */
	    *(tmptr+6) = '@';
	    do_remote_command(RLOGIN, links[cur].lname, newfile);
	    return(FALSE);  /* no new file */
	} else if((tmptr = strstr(links[cur].lname, "TELNET")) != NULL) {
	    /* add an '@' to make is conform to parsing routine */
	    *(tmptr+6) = '@';
	    do_remote_command(TELNET, links[cur].lname, newfile);
	    return(FALSE);  /* no new file */
	} else if((tmptr = strstr(links[cur].lname, "TN3270")) != NULL) {
	    /* add an '@' to make is conform to parsing routine */
	    *(tmptr+6) = '@';
	    do_remote_command(TN3270, links[cur].lname, newfile);
	    return(FALSE);  /* no new file */
	}

    if(((tmptr = strchr(links[cur].lname,'@')) != NULL) && 
	(*(tmptr-1) != '\\')) {
	/* if there is a number in front of the @ */
	/* its an emulated connection to a port */
	/* use the vt100 emulator to connect   */
	/* otherwise its an rexec link */
	if(tmptr-links[cur].lname < 11) /* don't overflow the array */
	   mystrncpy(Itemp,links[cur].lname+1,tmptr-links[cur].lname-1);
	else
	   strcpy(Itemp,"0");

	if(atoi(Itemp)>0) {  /* if there is a valid number */
#ifdef EMULATOR
	   do_port_emulator(links[cur].lname, newfile);
#else
	   statusline("This link type is unavailable");
	   sleep(1);
#endif
	} else {  /* theres no valid number, so assume its a command */
		/* its an rexec command type */
	   flag = do_remote_command(REXEC_T, links[cur].lname, newfile);
	}  /* end of if(atoi) */
    } else { /* its just a command exec it */
	/* if local_exec is FALSE, then do not allow local command
         * execution.  This is a safeguard against trojan horse
         * lynx commands like <!rm -rf *> or something similar
	 * if local_exec_on_local_files is true then local execution
	 * works for files found locally but not externally
	 */
	if(local_exec || 
	   (local_exec_on_local_files && strstr(newfile,"GoLYNX")==NULL))
	  flag = exec_a_command(cur, newfile, target);
	else {
	  statusline("Local execution links have been disabled!");
	  sleep(1);
	}

    } /* end of if strchr(links[cur].lname,'@') */

    /* pause for a second to let the user read any messages */
	sleep(1);

    return(flag);
}
