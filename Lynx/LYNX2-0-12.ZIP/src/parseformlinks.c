#ifdef FORMS

#include "defs.h"
/**
*** This procedure attempts to parse the structure between two link delmiters
*** delimiters are user definable and are contained in the delimiter. data
*** structure.
**/

PUBLIC char *parse_form_links ARGS5(char *,cp, int *,col, int,lineno, 
				    char *,cur_file, BOOLEAN *,show_next_char)
{
	char *cp2, *cp3, *cp4, *cp5;
	char link_info[MAXFNAME];

		cp2 = cp;
		/* parse till the end of the command or filename */
		for(;((*cp2 != delimiter.end_link) && (*cp2 != delimiter.token) 
		      && (*cp2 != '\0') && (cp2-cp+1 < MAXCOMMAND))
		     || (*(cp2-1)=='\\'); cp2++);
		    ; /* NULL BODY */


		for(cp5=cp2+1; isspace(*cp5); cp5++)
			; /* find the next text segment */


		/* if the link type is <* then it is a comment link
		 * see if there is a '*' as the first character, and
		 * if there is, skip the link and don't display it
		 */
		 if(*(cp+1)=='*') {
			*show_next_char = FALSE;
			return(cp5);  /* return next text pointer */
		 }

		/* if it began with a link delim. and ends with a link
		 * delim. it must be a link
		 */
		if (*cp2 == delimiter.end_link && nlinks < MAXLINKS) {
			 /* it's definately a link */
			/* copy the info out of the link */
		    strncpy(link_info, cp+1, cp2 - cp);

		        /* copy in the position */
                    links[nlinks].lx = *col;
                    links[nlinks].ly = lineno;

			/* check for a valid type and do type specific 
			 * things
			 */
		    if(!assign_form_link_types(link_info, col, lineno))
			return(cp);

		    addstr(links[nlinks].hightext);
		    *col += strlen(links[nlinks].hightext);
	            cp = cp5-1;
		    if(*cp5 == '\0')
			*show_next_char = FALSE;

		    links[nlinks].type = FORM_LINK_TYPE;

		    nlinks++;

		    stop_bold();

		} /* end of definately a link */

	return(cp); /* return new location of cp on the line */
} /* big end */

#endif FORMS
