#include "defs.h"

/*
 * exec a command basically just issues a system command to execute
 * what was defined in the link but it does one other inportant thing
 * if there is a string "LYNX" in the link then it replaces that string
 * with a temporary file name and returns true.  This is usefull if
 * you want to execute a command and return the output to lynx for viewing
 */
PUBLIC BOOLEAN exec_a_command ARGS3(int,cur, char *,newfile, char *,target)
{
	char *ptr, *tptr, *x;
	char c;
	char command[MAXCOMMAND+10];
	char message[MAXCOMMAND+20];
	char filename[20];
	char lname[MAXFNAME];
	BOOLEAN flag=FALSE; 
        int ret;

	tptr = lname;  /* get lname from links structure */

	for(x=links[cur].lname+1; *x != '\0' ;x++)
	  if(*x != '\\') {
	   *tptr = *x;    /* don't print slashes */
	   tptr++;
	  }
	  else if(*x == '\\' && *(x+1) == '\\') {
	   *tptr = *x;  /* print one slash if there are two */
	   tptr++;
	  }

	*tptr = '\0'; /* null terminate */
 
	if((ptr = strstr(lname, "LYNX")) != NULL) {
		flag = TRUE;
		mystrncpy(command, lname, ptr-lname);	
			/* make a temp file name */
		sprintf(filename,"%sLYNX%d%d",TEMP_SPACE,getpid(),nhist+1);
		/* /tmp/LYNX123459 */
		strcat(command, filename);  /* add the filename on */ 
		strcat(command, ptr+4); /* along with the rest of command */
		
		strcpy(newfile, filename);
		gettargetname(target, cur);
	} else if((ptr = strstr(lname, "DISPLAY")) != NULL) {
		if(display != NULL) {
		  mystrncpy(command, lname, ptr-lname);	
		  strcat(command, display);  /* add the display variable on */ 
		  strcat(command, ptr+7); /* along with the rest of command */
		
		  strcpy(newfile, filename);
		  gettargetname(target, cur);
		} else {
		  statusline("This link type is not available without an X terminal");
		  sleep(1);
		  return(FALSE);
		}
	} else {
		flag = FALSE;
		strcpy(command, lname);
	}

	/* tell the user what your doing */
	strcpy(message,"Executing command: ");
	strcat(message,command);
	strcat(message,".  Please wait"); 
	statusline(message);

	stop_curses();
	fprintf(stdout,"\n");
	signal(SIGINT, SIG_IGN);
	ret = system(command);
	fflush(stdout);
	signal (SIGINT, cleanup_sig);
	start_curses();

	/* I don't know why, but unix returns 25344 if you exit(99) */
	if(ret == 25344) { /*if a process returns a 99 then quit the program */
	    statusline("Do you wish to exit Lynx as well? (y/n)");
	    c = mygetch();
	    if((toupper(c)) == 'Y') {
		cleanup();
		exit(0);
	    }
	}
	


	return(flag);
}
