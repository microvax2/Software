#include "defs.h"

PUBLIC void save_homepage_link ARGS1(int,cur)
{
	FILE *fp;
	BOOLEAN first_time=FALSE;
	char name_buffer[256];
	char *c;

	*name_buffer = '\0';

	if(*home_page == '\0') {
	    statusline("ERROR - No bookmark page defined");
	    sleep(1);
	    return;
	}

#ifdef UNIX
	if(*home_page == '/') {
#endif UNIX
	    if((fp = fopen(home_page,"r")) == NULL) {
		/* first time home page */
	        first_time= TRUE;
	    } else
	        fclose(fp);
#ifdef UNIX
	} else {
	    sprintf(name_buffer,"%s/%s",getenv("HOME"),home_page);
	    if((fp = fopen(name_buffer,"r")) == NULL) {
		/* first time home page */
	        first_time= TRUE;
	    } else
	        fclose(fp);
	}
#endif UNIX

	if(*name_buffer == '\0') {
	    if((fp = fopen(home_page,"a+")) == NULL) {
	       statusline("ERROR - unable to open bookmark page");
	       return;
	    }
	} else {
	    if((fp = fopen(name_buffer,"a+")) == NULL) {
	       statusline("ERROR - unable to open bookmark page");
	       return;
	    }
	}

	if(first_time) {
	    fprintf(fp,"link_delimiter=<\n\n		Bookmark Page\n");
	    fprintf(fp,"     This file may be edited with a standard text editor.\n");
	    fprintf(fp,"     Outdated or invalid links may be removed by simply deleting\n     the line the link appears on in this file.\n");
	    fprintf(fp,"     Please refer to the Lynx documentation for link syntax.\n");
	}

	fprintf(fp,"\n     <");

	/* print the filename */
	for(c=links[cur].lname; *c != '\0'; c++) {
		if((*c != ':' && *c != '>' && 
		   *c != '<') || *(c-1) == '\\')
		    fprintf(fp,"%c",*c);
		else
		    fprintf(fp,"\\%c",*c);
	}
		/* print the rest */
	fprintf(fp,"::%s>%s",links[cur].target, links[cur].hightext);

	fclose(fp);

	statusline("Done!");
}
	
