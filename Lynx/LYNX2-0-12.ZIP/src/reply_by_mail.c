#include "defs.h"

/*
 * this procedure only works on unix & VMS 
 * reply by mail invokes sendmail or mail on VMS to send a comment 
 * from the users to the owner or ALERTMAIL
 */

/* global variable for async i/o */
BOOLEAN term_letter;
void terminate_letter  PARAMS((int sig));
void remove_tildes PARAMS((char *string));

PUBLIC void reply_by_mail ARGS2(char *,mail_address, char *,filename)
{
	char command[100];
	char subject[256];
	char user_input[1000];
	FILE *fd;
	char c;  /* user input */
	char cmd[256], *tmptr, *address_ptr1, *address_ptr2;
	char tmpfile[100];
	BOOLEAN first=TRUE;

	term_letter=FALSE;

	clear();
	move(2,0);

	tempname(tmpfile,NEW_FILE);
	if((fd = fopen(tmpfile,"w")) == NULL)
	    return;

	if(*mail_address != '\0') {
	    addstr("You are now sending a comment to:");
	    addstr("\n	");
	    addstr(mail_address);
	    addch('\n');
	}

#ifdef UNIX /* Use ^G to cancel mailing of comment */
	/* don't let sigints exit lynx */
        signal(SIGINT, terminate_letter); /* */   /* NEW */

	/* put the to: line in the temp file */
	fprintf(fd,"to:%s\n",(*mail_address=='\0' ? ALERTMAIL : mail_address));
	fprintf(fd,"x-within-url:%s\n",filename);
	fprintf(fd,"x-mailer:Lynx, Version %s\n",LYNX_VERSION);
#endif UNIX


	addstr(" Please enter your name, or leave it blank if you wish to remain anonymous\n");
	strcpy(user_input,"Name: ");
	if (Gophergetstr(user_input) < 0 || term_letter) {
	    statusline("Comment request cancelled!!!");
	    fclose(fd);  /* close the temp file */
	    sleep(1);
	    goto cleanup;
	}

	remove_tildes(user_input);

	term_letter=FALSE;
	fprintf(fd,"%s\n",user_input);

	addstr("\n\n Please enter a mail address or some other\n");
	addstr(" means to contact you, if you desire a response.\n");
	strcpy(user_input,"From: ");
	/* add the mail address if there is one */
	if(*personal_mail_address != '\0')
	    strcat(user_input,personal_mail_address);

	if (Gophergetstr(user_input) < 0 || term_letter) {
	    statusline("Comment request cancelled!!!");
	    sleep(1);
	    fclose(fd);  /* close the temp file */
	    goto cleanup;
	}
	remove_tildes(user_input);

	fprintf(fd,"%s\n",user_input);

	addstr("\n\n Please enter a subject line\n");
	strcpy(user_input,"Subject: ");
	if (Gophergetstr(user_input) < 0 || term_letter) {
	    statusline("Comment request cancelled!!!");
	    sleep(1);
	    fclose(fd);  /* close the temp file */
	    goto cleanup;
	}
	if(*filename == '\0')
	    strncpy(subject, user_input,255);

	remove_tildes(user_input);

	fprintf(fd,"%s\n",user_input);

	if(!anonymous && *editor != '\0') {
	    fclose(fd);

	    /* spawn the users editor on the mail file */
	    sprintf(user_input,"%s %s",editor,tmpfile);
	    statusline("Spawning your selected editor to edit mail message");
	    stop_curses();
	    if(system(user_input)) {
		statusline("Error spawning editor, check your editor definition in the options menu");
	  	sleep(1);
	    }
	    start_curses();

	} else {
	
	    addstr("\n\n Please enter your message below.");
	    addstr("\n When you are done, press enter and put a single period (.)");
	    addstr("\n on a line and press enter again.");
	    addstr("\n\n");
	    scrollok(stdscr,TRUE);
	    refresh();
    	    *user_input = '\0';
	    if (Gophergetstr(user_input) < 0 || term_letter) {
	        statusline("Comment request cancelled!!!");
	        sleep(1);
	        fclose(fd);  /* close the temp file */
	        goto cleanup;
	    }


	    while(!STREQ(user_input,".") && !term_letter) { 
	       addch('\n');
	       remove_tildes(user_input);
	       fprintf(fd,"%s\n",user_input);
	       *user_input = '\0';
	       if (Gophergetstr(user_input) < 0) {
	          statusline("Comment request cancelled!!!");
	          sleep(1);
	          fclose(fd);  /* close the temp file */
	          goto cleanup;
	       }
	    }

	    fprintf(fd,".\n");
	    fprintf(fd,"\n");

	    fclose(fd);  /* close the temp file */
	    scrollok(stdscr,FALSE);  /* stop scrolling */
	}

	statusline("Send this comment? (y/n) ");
	while((c = toupper(mygetch())) != 'Y' && c != 'N')
	    ; /* null body */

	clear();  /* clear the screen */

	if(c == 'N') {
	   goto cleanup;
	}

#ifdef VMS
	sprintf( cmd, "%s /subject=\"Commenting from file %s\" %s ",
		  SYSTEM_MAIL, filename, tmpfile);

       /* if there is no valid owner address send to alert mail */
        /* a valid addres must be at least 4 chars long  */
        if(strlen(mail_address) < 3)
            sprintf( &cmd[strlen(cmd)], MAIL_ADRS, ALERTMAIL);

	/* now add all the people in the mail_address field */
	address_ptr1 = mail_address;
	do {
	    if((tmptr = strchr(address_ptr1,",")) != NULL) {
	        address_ptr2= (tmptr+1);
	        *tmptr = '\0';
	    } else
		address_ptr2=NULL;
	    
	    /* 4 letters is arbitrarily the smallest posible mail address,
	     * at least for lynx.  That way extra spaces won't
	     * confuse the mailer and give a blank address
	     */
	    if(strlen(address_ptr1) > 3) {	
	        if(!first)
		    strcat(cmd, ", ");  /* add a comma and a space */
	        sprintf( &cmd[strlen(cmd)], MAIL_ADRS, address_ptr1);
		first=FALSE;
	    }

	    address_ptr1=address_ptr2;
	} while(address_ptr1!=NULL);

        stop_curses();
	printf("Sending your comment.  Please wait...");
	signal(SIGINT, SIG_IGN);
	system(cmd);
	signal(SIGINT, cleanup_sig);
	start_curses();
#else
	/* send the tmpfile into sendmail.  
	 */
	sprintf(cmd,"%s -t < %s", SYSTEM_MAIL, tmpfile);

	signal(SIGINT, SIG_IGN);
	system(cmd);

	if(TRACE)
	    printf("%s\n",cmd);

#endif VMS

	/* come here to cleanup and exit */
cleanup:
#ifdef UNIX
	signal(SIGINT, cleanup_sig);
#endif UNIX

	scrollok(stdscr,FALSE);  /* stop scrolling */
	remove(tmpfile);
}

PRIVATE void terminate_letter ARGS1(int,sig)
{
	term_letter=TRUE;
#ifdef NOTDEFINED /* Can't get vsignal to work during Gophergetstr() calls  */
		  /* Problem appears to be due to the recurring timed reads */
#ifdef VMS
	signal(SIGINT, terminate_letter);
#endif
#endif NOTDEFINED
}

PRIVATE void remove_tildes ARGS1(char *,string)
{
       /* change the first character to a space if
	* it is a '~'
	*/
    if(*string == '~')
	*string == ' ';
}
