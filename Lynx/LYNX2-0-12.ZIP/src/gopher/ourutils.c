#include "gopher.h"

/*
 * display the current value of the string and allow the user
 * to edit it.
 */

#ifdef getyx
#define GetYX(y,x)   getyx(stdscr,y,x)
#else
#define GetYX(y,x)   y = stdscr->_cury, x = stdscr->_curx
#endif

int Gophergetstr(inputline)
  char *inputline;
{
     int pointer = 0;
     int tmp_pointer;
     int ch;
     int startcol, startline;
     int cur_col;
     BOOLEAN line_extended=FALSE;  /* TRUE if the line was moved to accomadate
				    * more text entry
				    */

     /* get the initial position of the curser */
     GetYX(startline, startcol);

     /*** Check to see if there's something in the inputline already ***/

     if(strlen(inputline)+startcol+5 > COLS-1) {
	pointer = (strlen(inputline) - ((COLS-1) - startcol)) + 10;
	line_extended = TRUE;
     }
     
     cur_col = startcol;
     while (inputline[pointer] != '\0') {
	  addch(inputline[pointer]);
	  pointer ++;
	  cur_col++;
     }
     refresh();
	  

     for (;;) {
	  ch = mygetch();

	  switch (ch) {

#ifdef AIX
          case '\227':
#endif
	  case '\n':
	  case '\r':
	  case '\t':
	  case DNARROW:
	  case UPARROW:
	       inputline[pointer] = '\0';
	       return(ch);
	       break;

          /* Control-G aborts */
          case 7:
	       inputline[0] = '\0';
               return(-1);

	 	/* break */  /* implicit break */


	  /* erase all the junk on the line and start fresh */
	  case 21 :
		move(startline, startcol);
		clrtoeol();
		pointer = 0;  /* clear inputline */
		cur_col = startcol;
		line_extended = FALSE;
		refresh();
		break;

	  /**  Backspace and delete **/

	  case '\010':
	  case '\177':
	  case LTARROW:
	       if (pointer > 0) {
		    addch('\010');
		    addch(' ');
		    addch('\010');
	       
		    pointer--;
		    cur_col--;

		    if(line_extended && cur_col+15 < COLS-1) {
     			if(pointer + startcol+5 > COLS-1) {
			    tmp_pointer = (pointer - ((COLS-1) - startcol)) + 5;
			} else {
			    tmp_pointer = 0;
			    line_extended = FALSE;
			}

			move(startline, startcol);
			clrtoeol();
		
			cur_col = startcol;
     
     			while (tmp_pointer != pointer) {
	  			addch(inputline[tmp_pointer]);
	  			tmp_pointer ++;
	  			cur_col++;
     			}
			
		    }
		    refresh();

	       } else if(ch == LTARROW) {
		   inputline[0] = '\0';
		   return(ch);
	       }
	       break;
		    
	       
	  default:
	       if (printable(ch)) {
		    inputline[pointer++]= ch;
		    cur_col++;
		    addch(ch);

		    if(cur_col+2 > COLS-1) {
			tmp_pointer = (pointer - ((COLS-1) - startcol)) + 10;
			line_extended = TRUE;

			move(startline, startcol);
			clrtoeol();
     
			cur_col = startcol;

     			while (tmp_pointer != pointer) {
	  			addch(inputline[tmp_pointer]);
	  			tmp_pointer ++;
	  			cur_col++;
     			}
			
		    }
		    refresh();
	       }
	       /* else
	          return(ch); */
		/* just ignore unprintable charactors */
	  }
     }

}

/*
 ** This strips off  CR's and LF's leaving us with a nice pure string.
 */

void
ZapCRLF(inputline)
char *inputline;
{
     char *cp;
     
     cp = strchr(inputline, '\r');    /* Zap CR-LF */
     if (cp != NULL)
          *cp = '\0';
     else {
          cp = strchr(inputline, '\n');
          if (cp != NULL)
               *cp = '\0';
     }
}


int
OpenGopherConn(GopherStruct)
  struct gopher_struct GopherStruct;
{
     int sockfd;
     static char inputline[LINESIZE];
     int length;

     inputline[0] = '\0';

     if ((sockfd = connect_to_gopher(GopherStruct.host, GopherStruct.port)) <0) {
	  check_sock(sockfd, GopherStruct.host);
	  return(-1);
     }


     /*** Get rid of that darn Banner line ***
     length = readline(sockfd, inputline, LINESIZE); */

     return(sockfd);
     /*** TODO check to see if the server version is cool. ***/

}

/*
** This routine will allow the user to change a whole bunch of fields.
** 
** The maximum number of options is hard set at 9 right now.  It may be
** different in the future.
**
** The space for storing stuff is provided by the caller.  This routine
** will present it to the user in this fashion:
**
**           Option1 : responses1
**           Option2 : responses2
**           .....
**
** It would be wise to keep the length of the options and responses
** below 38 characters.
**
*/


Get_Options(Title, Err, numOptions, Options, Responses)
  char *Title;
  char Err[MAXSTR];
  int    numOptions;
  char **Options;
  char Responses[MAXRESP][MAXSTR];
{
     int         availlines;
     static char printstring[WHOLELINE];
     static char inputline[WHOLELINE];
     int         optionlen;
     int         maxoptionlen;
     int         i = 0,j;          /** Acme Buggy whips and integers **/
     BOOLEAN     Done = FALSE;
     int        ch;


	  clear();
	  Centerline( Title, 3);
	  Centerline( Err, 4);
	  
	  availlines = LINES - 6;
	  
	  /** Find the longest width of the options strings **/
	  
	  maxoptionlen = 0;
	  
	  for (i=0; i<numOptions; i++) {
	       j= strlen(Options[i]);
	       maxoptionlen = (maxoptionlen > j) ? maxoptionlen:j;
	  }
	  
	  
	  /*** Print out the options in a nice looking fashion ***/
	  
	  for (i=0; i<numOptions; i++) {
	       optionlen = strlen(Options[i]);
	       move(i+5, 5);
	       addstr(Options[i]);
	       mvaddstr(i+5, maxoptionlen + 6, ": ");
	       addstr(Responses[i]);
	  }

	  sprintf(printstring, "<Tab> to move to the next field, <Return> to submit");

	  Centerline(printstring, LINES-3);

	  refresh();

     i=0; /* set i to zero */
     do {
	  /*** Now get some user input ***/

	  /* move to position */
	  move( i +5, maxoptionlen +8);
	  ch = Gophergetstr(Responses[i]);
	  clrtoeol();

	  if(ch == LTARROW || ch == -1) {
		return(FALSE);

	  } else if (ch == '\n' || ch == '\r') {
	       Done = TRUE;

	  } else if (ch == UPARROW) {
	       if(i > 0)
	           i--;
	       else
		   i=numOptions-1;

	  } else if (ch == DNARROW || ch == '\t') {
	       if(i < numOptions-1)
		   i++;
	       else
		   i=0;
	  }

     } while (Done == FALSE); 
     
    return(TRUE);
}
