#include"defs.h"

#define BUFFERSIZE 2048
#define buffempty() (position >= (sockbuff + sockend))

/*
 *	Global buffer for socket i/o
 */
char sockbuff[BUFFERSIZE];
int sockend;

PUBLIC void initialize_sockbuff()
{
    sockend = 0;
}

PUBLIC int sockbuffreadch ARGS2(int,sockfd, char *,output)
{
	static char *position = sockbuff + BUFFERSIZE + 1;

	/*
	 *	If the socket buffer is empty, fill up the buffer
	 *	as much as possible.
	 */
	if(buffempty())
	{
		/*
		 * 	Get data from socket.  If eof, return 0, else
		 *	reposition pointer to buffer.
		 */
		sockbuff[0] = '\0';
		if(0 == (sockend = Socket_Read(sockfd, 
				     (unsigned char *)sockbuff, BUFFERSIZE)))
			return(0);
		position = sockbuff;
	}

	/* set the output charactor and advace the buffer pointer */
	*output = *position;
	position++;

	return(1);
}
