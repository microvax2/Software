#include "gopher.h"

void check_sock(sockfd, host)
  int sockfd;
  char *host;
{
     char DispString[80];
     char Response[HALFLINE];

     Response[0] = '\0';

     if (sockfd <0) {
	  sprintf(DispString, "Cannot connect to host %s: ", host);
	  statusline(DispString);
     }
}
