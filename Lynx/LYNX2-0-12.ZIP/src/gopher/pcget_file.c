#include "gopher.h"

/**
*** Show file takes an open socket connection, writes it to a file
*** and passes it to your favorite pager.
**/

void get_file(GopherStruct *ZeGopher, char *newfile, char *gopher_info)
{
#ifndef MSDOS
     int i=0, iLength, sockfd, itmp, lineno=0;
     FILE *tmpfile;
     char inputline[512];
     char outputline[512];
     char sTmp[5], *ctmp="\0";
     char MType[5];
     int screen_count=0, no_more_defines=FALSE;

     sTmp[0] = '\0';
     nlinks = 0; /* set nlinks to zero because of a new page */
     more = FALSE;

    /* set defaults */   
    *base1 = '\0';
    *owner = '\0';
    delimiter.link = DEFAULT_LINK_DELIMITER;
    delimiter.end_link = DEFAULT_END_LINK_DELIMITER;
    strcpy(delimiter.target, LEFT_TARGET_DELIMITER);
    strcpy(delimiter.end_target, RIGHT_TARGET_DELIMITER);
    delimiter.token = DEFAULT_TOKEN_DELIMITER;

     if ((sockfd = connect_to_gopher(GSgetHost(ZeGopher), GSgetPort(ZeGopher))) <0) {
	  check_sock(sockfd, GSgetHost(ZeGopher));
	  return;
     }

     /** Send out the request **/

     writestring(sockfd, GSgetPath(ZeGopher));
     writestring(sockfd, "\r\n");
     /** Check the result of the command.  See if we screwed up... **/

     /** Open a temporary file **/

     if ((tmpfile = fopen(newfile, "w")) == NULL)
	  perror("Couldn't make a tmp file!\n"), exit(-1);

     for(;;) {
	  iLength = readline(sockfd, inputline, 512);
	  outputline[0] = '\0';
	  if (iLength == 0)
	       break;


	  ZapCRLF(inputline);
	  
	  
	  /*** Ugly hack ahead..... ***/

          if (GSgetType(ZeGopher) == A_CSO) {
	       if (inputline[0] == '2')
		    break;

	       if ((inputline[0] >= '3') && (inputline[0] <= '9'))  {
		    fprintf(tmpfile, "%s\n", GSgetPath(ZeGopher));
		    fprintf(tmpfile, "%s\n", inputline+4);
		    break;
	       }
	       if (inputline[0] == '-') {
		    if (inputline[5] + (inputline[6] == ':' ? 0 : inputline[6]) != i)
			 fprintf(tmpfile, "-------------------------------------------------------\n");
		    i = inputline[5] + (inputline[6] == ':' ? 0 : inputline[6]);
		    fprintf(tmpfile, "%s\n", inputline+7);
	       }
	  }

	  if (GSgetType(ZeGopher) == A_MIME) /* If it's a MIME document then  */
             MType[1]='M';              /* set the type for display_file()*/ 
          else				     /* if not,                     */
             MType[1]='0';		     /* then set it true empty.     */

          if (GSgetType(ZeGopher) == A_FILE || 
	      GSgetType(ZeGopher) == A_EVENT || GSgetType(ZeGopher)==A_MIME) {
	       if ((inputline[0] == '.'))
		    break;
	       else {
	      	    sprintf(outputline,"%s\n", inputline);
		    fprintf(tmpfile, "%s", outputline);

/*  the following code will add the first screen of text to the screen
    as the file is being downloaded */

	if(lineno < LINES-1) {
	  if(no_more_defines == FALSE) {
	     if(defineswitch(inputline,base1,owner) == FALSE) {
		no_more_defines = TRUE;
	        display_a_line(outputline, &itmp, &lineno, ctmp, FALSE,
			       gopher_info, newfile, base1);
		lineno++;
	     }
	  } else {
	     display_a_line(outputline, &itmp, &lineno, ctmp, FALSE,
			    gopher_info, newfile, base1);
	     lineno++;
	     refresh();
	  }
	 }
	else if(lineno== LINES-1) {
	    statusline("Please wait while gopher gets the rest of the file");
	    lineno++;
	    more = TRUE;
	}

	       }
	  }
     }

/*     fprintf(tmpfile, "\012 \n\n"); /* Work around a bug in xterm n' curses*/
     (void)fclose(tmpfile);

#endif MSDOS

}
