#include "gopher.h"

PUBLIC char *do_gopher ARGS4(char *,newfile, char *,hightext, 
			     char *,search_string, FILE *,current_fp)
{
     struct gopher_struct GopherStruct;

     char gopher_info[83];
     char tmpfile[120];
     char *colon, *slash, *ques_mark;
     char gtype = '1';
     char *cp=newfile, *cp2;
     char *host=NULL, *port=NULL, *path=NULL, *search=NULL;

/* take a filename in this syntax:
 *  gopheraddress
 *  gopher:// host:port [/ GtypePATH] ] [ ? search ]
 *
 *  parse it and get the file
 */

    /* kill beginning spaces */
    while(isspace(*cp)) cp++;

    cp += 9; /* go past the gopher:// part */ 

    host = cp; /* set the host */

    /* find the host and the optional port */
    /* colon is optional */
    if((colon = strchr(cp,':')) != NULL) {
	*colon = '\0';
	port = colon+1;
        cp = colon+1;
    }

	/* if there is more info besides host:port */
    if((slash = strchr(cp,'/')) != NULL) {
 	*slash = '\0';

	if(*(slash+1) != '\0') {
            gtype = *(slash+1);

	    if(*(slash+2) != '\0') {
		path = slash+2;

	        if((ques_mark = strchr(path,'?')) != NULL) {
	            *ques_mark = '\0';
		    search=ques_mark+1;
		}

                /* convert %20's to spaces in path string */
                for(cp=path, cp2=path; *cp != '\0'; cp++, cp2++) {
	            if(!strncmp(cp,"%20",3)) {
	                cp += 2;	
	                *cp2 = ' ';
	            } else {
	                *cp2 = *cp;
	            }
                }
                *cp2 = '\0';

	    } /* end if */
	} /* end if */
    }

     if(port)
         GopherStruct.port = atoi(port);
     else
	GopherStruct.port = 0;

     if(GopherStruct.port==0)
        GopherStruct.port = gopher_port;
	
     if(path != NULL) {
         simplify_address(path);  /* remove /../ and /./ from path */
         GopherStruct.path = path;
     } else {
	 GopherStruct.path = empty_string;
     }
     GopherStruct.host = host;
     GopherStruct.search = search;
     GopherStruct.title = hightext;

	/* asign types */
	switch(gtype) {   /* switch on first letter */
	case '0':  /* file */
	case 'l':  /* lynx file */
     	  	GopherStruct.type =A_FILE;
		break;
	case '1':  /* dir */		
     		GopherStruct.type =A_DIRECTORY;   
		break;
	case '2':  /* CSO */
		GopherStruct.type =A_CSO;
		break;
	case '4':  /* Mac BinHex */
     		GopherStruct.type =A_MACHEX;   
		break;
	case '5':  /* PC Binary */
     		GopherStruct.type =A_PCBIN;   
		break;
	case '7':  /* index */
     		GopherStruct.type =A_INDEX;   
		if(GopherStruct.search == NULL) {
		    statusline("Enter a search string: ");
		    Gophergetstr(search_string);
		    if(strlen(search_string) == 0)
		        return("NULL");  /* only if TRAVERSAL */
	 	    else
			GopherStruct.search = search_string;
		}
		break;
	case '8':  /* telnet */
     		GopherStruct.type =A_TELNET;   
		/* pass the port string that may be NULL */
		gopher_telnet(&GopherStruct, port);
		return("NULL");
		
	case 'T':  /* tn3270 */
     		GopherStruct.type =A_TN3270;   
		/* pass the port string that may be NULL */
		gopher_telnet(&GopherStruct, port);
		return("NULL");
		
        case '9':  /* UNIX Binary */
     		GopherStruct.type =A_UNIXBIN;   
		break;
        case 'I':  /* Image type */
#ifndef NON_INTERACTIVE
     		GopherStruct.type =A_IMAGE; 
		if(display == NULL) {
		    statusline("Can't Display! Would you like to save the image to a file? (y/n)");
		    if(toupper(mygetch()) == 'Y')
     			GopherStruct.type =A_UNIXBIN;   
		    else
		    	return("NULL");
		} 
#endif NON_INTERACTIVE
		break;
        case 'g':  /* Gif Image type */
     		GopherStruct.type =A_IMAGE;   
		if(display == NULL) {
		    statusline("Can't Display! Would you like to save the image to a file? (y/n)");
		    if(toupper(mygetch()) == 'Y')
     			GopherStruct.type =A_UNIXBIN;
		    else
		    	return("NULL");
		} 
		break;
	default:  /* default is a unknown link type */
		statusline("Gopher type is unknown!!!");
		strcpy(newfile,"#NOT FOUND#");
		return("NULL"); 
		break;
	} /* end switch */

     sprintf(gopher_info,"@%s %d",host,GopherStruct.port);

     if(GopherStruct.type == A_CSO) {
	if(!do_cso(&GopherStruct))
	    return("NULL");
	statusline("Searching CSO database -- Please Wait");
     }

     if(GopherStruct.type == A_MACHEX ||
        GopherStruct.type == A_PCBIN ||
        GopherStruct.type == A_IMAGE ||
        GopherStruct.type == A_UNIXBIN) {
           get_bin_file(&GopherStruct, hightext);
	   return("NULL");
     }

     /* make the name the file will become */
     tempname(tmpfile, NEW_FILE);

	if(GopherStruct.type == A_INDEX) 
	    statusline("One moment Please -- Searching Data");
	else {
	    char tempstring[100];
	    sprintf(tempstring,"One moment Please -- Retrieving remote data from %s.",host);
	    statusline(tempstring);
	}

     if(TRACE)
	fprintf(stderr,"\ndo_gopher: path=%s	host=%s\n",GopherStruct.path,
							GopherStruct.host);

     if(GopherStruct.search == NULL)
	GopherStruct.search = empty_string;
     if(GopherStruct.title == NULL)
	GopherStruct.title = empty_string;

     if(get_file(&GopherStruct, tmpfile, gopher_info)==-1) {
	    strcpy(newfile,"#NOT FOUND#");
     } else {
	strcpy(newfile,tmpfile);
     }

     refresh();  /* paint the screen */

     return(gopher_info);

} /* big end */	 
