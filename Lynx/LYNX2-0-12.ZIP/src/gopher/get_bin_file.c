#include "gopher.h"

/*
 * get_bin_file asks the user for a file name and transfers a file
 * in binary to that file name.
 */

PUBLIC int get_bin_file ARGS2(struct gopher_struct *,GopherStruct, char *,sug_file)
{
     int i, iLength, sockfd, itmp, lineno=0;
     FILE *outfile_fp;
     int cc;
     char buf[1400];
     char temp[256];
     char filename[256];

    /* reset the socket buffer to make sure there is no junk in the
     * buffer when we start
     */ 
     initialize_sockbuff();

     if(GopherStruct->type != A_IMAGE) {

		statusline("Please enter a file name to save to: ");
		strcpy(filename, sug_file);
  		/* make the name conform to system specs */		
		change_sug_filename(filename);
		if (Gophergetstr(filename) <0 || strlen(filename) == 0) {
		      statusline("Save file request cancelled!!!");
	              sleep(1);
	              return(FALSE);
                }
#ifdef UNIX
	/* see if file will open in current directory where lynx was started */ 
                sprintf(temp,"%s/%s",getenv("PWD"),filename);

                if((outfile_fp = fopen(temp,"w")) == NULL) {
   	/* if it doesn't open, try to save it in the 'HOME' directory */
#endif
 
                  if(*filename != '/' && *filename != '\\') {
#ifdef UNIX
	              if(*filename == '~') {
	                  strcpy(temp,getenv("HOME"));
	                  strcat(temp,filename+1); /* skip over the ~ */
	                  strcpy(filename,temp);
	              }
	              else {
	                  strcpy(temp,getenv("HOME"));
	                  strcat(temp,"/");
	              } /* end if-else */
#endif UNIX
            
#ifdef VMS
                    strcpy(temp,"sys$login:");
#endif VMS
            
#ifdef MSDOS
                    strcpy(temp, PRINT_DIR);
                    strcat(temp,"\\");
#endif MSDOS
            
            
                    strcat(temp,filename);
                    strcpy(filename,temp);
                   } /* end if-else */
            
                  if((outfile_fp = fopen(filename,"w")) == NULL) {
	              statusline("unable to open output file!!!");
	              sleep(1);
	              return(FALSE);
                  }
#ifdef UNIX
                } /* end of if(outfile_fp ==NULL from way up top */
#endif UNIX
      	} else  {   /* its an image type */
	   	sprintf(filename,"%sLYNXImage%d",TEMP_SPACE,getpid());
                  if((outfile_fp = fopen(filename,"w")) == NULL) {
	              statusline("unable to allocate space for image!!!");
	              sleep(1);
	              return(FALSE);
		   }
	}


/* set up an async way of aborting the gopher transfer */
#ifdef HAVE_SIGIO
     fcntl (0, F_SETOWN, getpid() );
     fcntl ( 0, F_SETFL, FASYNC );
#endif HAVE_SIGIO

     statusline(GOPHER_WAIT_MESSAGE);
#ifdef HAVE_SIGIO
     signal(SIGIO, async_interupt); /* */
#else
     signal(SIGINT, async_interupt); /* */
#endif HAVE_SIGIO

     if ((sockfd = connect_to_gopher(GopherStruct->host, GopherStruct->port)) <0) {
#ifdef HAVE_SIGIO
          signal(SIGIO, SIG_IGN); /* */
#else
          signal(SIGINT, cleanup_sig); /* */
#endif HAVE_SIGIO
	  check_sock(sockfd, GopherStruct->host);
	  return(-1);
     }

     /** Send out the request **/
   	writestring(sockfd, GopherStruct->path);
     	writestring(sockfd, "\r\n");

     itmp=0;
     /* read and read until we get EOF */
     while ( (cc = Socket_Read( sockfd, buf, 1400 )) > 0 ) {
	  /* hope we don't have error while writing - I'm so lazy */

	  if(InteruptTransfer==TRUE) {
#ifdef HAVE_SIGIO
     		signal(SIGIO, SIG_IGN);
#else
     		signal(SIGINT, cleanup_sig);
#endif HAVE_SIGIO
	        statusline("The rest of the file was aborted during transfer.");
		InteruptTransfer=FALSE;
		fclose(outfile_fp);
		Socket_Close(sockfd);
		remove(filename);
		sleep(1);
		return;
	  }

	  if (fwrite(buf, cc, 1, outfile_fp) <=0)
	       statusline("Problems Writing");
	  move(LINES-1, COLS-2);

	  switch(itmp) {
	     case 0: addch('\\');
		     break;
	     case 1: addch('-');
		     break;
	     case 2: addch('/');
		     break;
	     case 3: addch('|');
		     itmp= -1;
	  }
	  itmp++;
	  refresh();
     }
     fclose(outfile_fp); /* should error check */
     Socket_Close( sockfd );

     if ( cc < 0 )
        statusline( "Warning! File may be corrupt!");
     else {
        statusline( "File received successfully" );
     }

#ifdef HAVE_SIGIO
     signal(SIGIO, SIG_IGN); /* */
#else
     signal(SIGINT, cleanup_sig); /* */
#endif HAVE_SIGIO

     if(GopherStruct->type == A_IMAGE)   
	  if(vfork() == 0) {
		execlp(XLOADIMAGE_COMMAND, XLOADIMAGE_COMMAND, filename, 0);
		exit(0);
	  }
}
