#include "STRstring.h"
#include "gopher.h"

#ifndef NULL
#define NULL ((void *) 0)
#endif

/*
 * Make a new string, should reuse destroyed strings....
 */

String *
STRnew()
{
     String *temp;

     temp = (String *) malloc(sizeof(String));
     STRinit(temp);

     return(temp);
}

/*
 * Destroy a string
 */

void
STRdestroy(st)
  String *st;
{
     if (st->data != NULL)
	  free(st->data);

     free(st);
}


/*
 * Clear out all the crud...
 */

void 
STRinit(st) 
  String *st;
{
     st->len  = 0;
     st->data = NULL;
}

/*
 * Set a string value
 */

void
STRset(st, str)
  String *st;
  char   *str;
{
     register int len;

     if (str == NULL)
	  return;

     if (*str == '\0')
	  len = 1;
     else
	  len = strlen(str) + 1;

     /* Uninitialized data... */

     if (st->data == NULL) {
	  st->data = (char *) malloc(len);
	  strcpy(st->data, str);
	  st->len = len+1;
     }

     /** Something's already there... **/

     else {
	  if (st->len > len)
	       strcpy(st->data, str);
	  else {
	       char *temp;

	       temp = (char *) realloc(st->data, len);
	       if (temp != st->data) {
		    free(st->data);
		    st->data = temp;
	       }
	       strcpy(st->data, str);
	  }
     }
     
}

