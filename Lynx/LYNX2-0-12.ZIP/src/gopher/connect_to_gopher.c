#include "gopher.h"
#ifdef UNIX
#include <sys/socket.h>
#endif UNIX

#ifdef NO_BCOPY
#define bcopy(src,dest,len) memmove(dest,src,len)
#define bzero(dest,len) memset(dest,(char) 0,len)
#endif NO_BCOPY

int connect_to_gopher(Hostname, ThePort)
  char *Hostname;
  int  ThePort;
{
     static struct sockaddr_in Server;
     static char sBuf[16];
     struct hostent *HostPtr;
     int iSock = 0;
     
     if (Hostname == '\0') {
	  gethostname(sBuf, 16);
	  Hostname = sBuf;
     }

     if ((Server.sin_addr.s_addr = inet_addr(Hostname)) == -1) {
	  if (HostPtr = gethostbyname(Hostname)) {
	       bzero((char *) &Server, sizeof(Server));
	       bcopy(HostPtr->h_addr, (char *) &Server.sin_addr, HostPtr->h_length);
	       Server.sin_family = HostPtr->h_addrtype;
	  } else
	       return (-2);
     } else
	  Server.sin_family = AF_INET;

     Server.sin_port = (unsigned short) htons(ThePort);

     if ((iSock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	  return (-3);

#ifndef UCX
     setsockopt(iSock, SOL_SOCKET, ~SO_LINGER, 0, 0);
#endif UCX
     setsockopt(iSock, SOL_SOCKET, SO_REUSEADDR, 0, 0);
     setsockopt(iSock, SOL_SOCKET, SO_KEEPALIVE, 0, 0);

     if (connect(iSock, (struct sockaddr *) &Server, sizeof(Server)) < 0) {
	  close(iSock);
	  return (-4);
     }
     return(iSock);
}
