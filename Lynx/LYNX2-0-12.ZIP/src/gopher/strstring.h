/*
 * This is a funky dynamic string written in c....  
 */

#ifndef STRstring_H
#define STRstring_H

struct string_struct {
     int  len;
     char *data;
};

typedef struct string_struct String;

String *STRnew();
void    STRinit(/* String*  */);
void    STRset(/* String*, char* */);
void    STRdestroy(/* String* */);
#define STRget(s) ((s)->data)

#endif
