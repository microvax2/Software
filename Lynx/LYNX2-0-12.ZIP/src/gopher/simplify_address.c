#include "gopher.h"

PUBLIC void simplify_address ARGS1(char *,filename)
{
    char * p;
    char * q;

    if(strlen(filename) < 2)
	return;

    for(p=filename+2; *p; p++) {
        if (*p=='/') {
            if ((p[1]=='.') && (p[2]=='.') && (p[3]=='/' || !p[3] )) {
                for (q=p-1; (q>filename) && (*q!='/'); q--); /* prev slash */
                if (*q=='/') {
                    strcpy(q, p+3);     /* Remove  /xxx/..      */
                    if (!*filename) strcpy(filename, "/");
                    p = q-1;            /* Start again with prev slash  */
                } else {                        /*   xxx/..     error?  */
                    strcpy(filename, p[3] ? p+4 : p+3); /* rm  xxx/../  */
                    p = filename;               /* Start again */
                }
            } else if ((p[1]=='.') && (p[2]=='/' || !p[2])) {
                strcpy(p, p+2);                 /* Remove a slash and a dot */
            }
        }
    }
}

