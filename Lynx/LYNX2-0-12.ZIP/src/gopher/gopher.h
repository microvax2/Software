/* gopher.h
 *
 * Part of the Internet Gopher program, copyright (C) 1991
 * University of Minnesota Microcomputer Workstation and Networks Center
 *
 */

#include "defs.h"

#define HALFLINE 40

#define MAXSTR 200           /* Arbitrary maximum string length */
#define WHOLELINE MAXSTR
#define MAXRESP 80

#ifndef MSDOS
#ifndef VMS
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/file.h>
#if SVR4
#include <sys/fcntl.h>
#endif
#else
#include <socket.h>
#include <types.h>
#include <descrip.h>
#include <netdb.h>
#include <in.h>
#include <unixlib.h>
#include <perror.h>
#include <netdb.h>
#include <ctype.h>
#include <errno.h>
#include <time.h>
#endif
#endif MSDOS

#include "gopher_types.h"

struct gopher_struct {
    char *title;
    char *host;
    char *path;
    char *search;
    int type;
    int port;
};

extern void check_sock PARAMS((int sockfd, char *host));
extern int connect_to_gopher PARAMS((char *Hostname, int ThePort));
extern char *do_gopher PARAMS((char *newfile, char *hightext, 
				char *search_string, FILE *current_fp));
extern int get_file PARAMS((struct gopher_struct *GopherStruct, char *newfile, 
				char *gopher_info));
extern void ZapCRLF PARAMS((char *inputline));
extern char *make_dir_links PARAMS((char *lineptr, char type, 
					char *search_string));

