#include "gopher.h"

PUBLIC void gopher_telnet ARGS2(struct gopher_struct *,GopherStruct, 
								char *,port)
{
	char *username, *password;
	char *pass_ptr;
	char command[256], query[120];
	char response;
/* 
 */
	if(GopherStruct->path!= NULL) {

	    if(GopherStruct->path != NULL) {
	    	username = GopherStruct->path;
		
		if((pass_ptr = strstr(GopherStruct->path,"password")) != NULL) {
	  	    /* if username and password exists */
		    password = pass_ptr+8;
		    *pass_ptr = '\0';
		}
	    }
	} 


#ifdef VMS
	if(GopherStruct->type == A_TN3270)
	    sprintf(command,"%s %s %s%s",TN3270_COMMAND, GopherStruct->host, 
				(port ? "/port=" : ""), (port ? port : ""));
	else
	    sprintf(command,"%s %s %s%s",TELNET_COMMAND, GopherStruct->host,
				(port ? "/port=" : ""), (port ? port : ""));
#else
	if(GopherStruct->type == A_TN3270)
	    sprintf(command,"%s %s %s",TN3270_COMMAND, GopherStruct->host, port ? port:"");
	else
	    sprintf(command,"%s %s %s",TELNET_COMMAND, GopherStruct->host, port ? port:"");
#endif VMS

	/* clear the screen and give the user some info and choices */
	clear();
	addch('\n');
	addch('\n');
	addch('\n');
	addstr("	WARNING:  You are about to leave Lynx and telnet to another site!");
	addch('\n');
	addch('\n');
	addch('\n');
	addstr("	Now connecting to ");
	addstr(GopherStruct->host);
	addch('\n');
	addch('\n');
	if(*username != NULL) {
	    addstr("	Use the username ");
	    addstr(username);
	
	   if(password != NULL) {
	       addstr(" and the password ");
	       addstr(password);
	   }

	   addstr(" to logon");
	}	
	sprintf(query,"telnet to %s? (y/n)",GopherStruct->host);
	statusline(query);

	response = mygetch();
	
	if(response == RTARROW || response == 'y' || response == 'Y') {
	   statusline(command);
	   stop_curses();
	   system(command);
	   start_curses();
	}
}	
	
	

			
