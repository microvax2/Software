#include "gopher.h"

/**
 * Gets a gopher file
**/

#define BIG_LINE "-------------------------------------------------------\n"

PUBLIC int get_file ARGS3(struct gopher_struct *,GopherStruct, char *,newfile, 
				char *,gopher_info)
{
     int i, sockfd, iLength, total_bytes=0, itmp, lineno=0;
     FILE *tempfile;
     char inputline[513];
     char tmpline[256];
     int screen_count=0, no_more_defines=TRUE;
     char *second_colon;
     char *single_line, *end_of_line;
     struct chunck_struct * data_ptr;

     nlinks = 0; /* set nlinks to zero because of a new page */
     more = FALSE;

    /* *owner = '\0'; */
    /* *owner_info = '\0'; */
    /* *owner_address = '\0'; */

    /* set defaults */   
    *base1 = '\0';
    delimiter.end_link = '>';
    strcpy(delimiter.target, LEFT_TARGET_DELIMITER);
    strcpy(delimiter.end_target, RIGHT_TARGET_DELIMITER);
    delimiter.token = ':';
    if(GopherStruct->type==A_INDEX || GopherStruct->type==A_DIRECTORY)
    	delimiter.link = '<';
    else
	delimiter.link = DEFAULT_LINK_DELIMITER;

    if(GopherStruct->type == A_FILE) 
	no_more_defines=FALSE;

    /* reset the socket buffer to make sure there is no junk in the
     * buffer when we start
     */
     initialize_sockbuff();

/* set up an async way of aborting the gopher transfer */
#ifdef HAVE_SIGIO
     fcntl (0, F_SETOWN, getpid() );
     fcntl ( 0, F_SETFL, FASYNC );
#endif HAVE_SIGIO

#ifdef HAVE_SIGIO
     signal(SIGIO, async_interupt); /* */
#else
     signal(SIGINT, async_interupt); /* */
#endif HAVE_SIGIO

     if ((sockfd = connect_to_gopher(GopherStruct->host, GopherStruct->port))<0){
#ifdef HAVE_SIGIO
	  signal(SIGIO, SIG_IGN); /* */
#else
	  signal(SIGINT, cleanup_sig); /* */
#endif HAVE_SIGIO
	  check_sock(sockfd, GopherStruct->host);
	  statusline("Unable to connect to host!");
	  sleep(1);
	  return(-1);
     }

     /** Send out the request **/
     if(GopherStruct->type == A_INDEX) {
     	writestring(sockfd, GopherStruct->path);
     	writestring(sockfd, "\t");
    	writestring(sockfd, GopherStruct->search);
     	writestring(sockfd, "\r\n");
     } else {
   	writestring(sockfd, GopherStruct->path);
     	writestring(sockfd, "\r\n");
     }

     statusline("Waiting for response from server");

     /** Open a temporary file **/

     if ((tempfile = fopen(newfile, "w")) == NULL)
	  perror("Couldn't make a tmp file!\n"), exit(-1);

	       	    
     if(GopherStruct->type == A_DIRECTORY || GopherStruct->type == A_INDEX) {
		/* put the delimiter defines in */
	fprintf(tempfile," end_link_delimiter=> \n link_delimiter=< \n");
	fprintf(tempfile," token_delimiter=: \n");
	if(GopherStruct->type == A_DIRECTORY)
	   sprintf(tmpline,"\t\tDirectory of %s\n",GopherStruct->title);
	else
	   sprintf(tmpline,"\t%s:  %s\n",GopherStruct->title,
							GopherStruct->search);
    	fprintf(tempfile, "\n%s\n", tmpline);
	/* put on the screen the same thing in the file */
	clear();
	lineno=2;
	addch('\n');
        display_a_line(tmpline, &itmp, &lineno, GopherStruct->search, FALSE,
			       gopher_info, newfile, base1);
	addch('\n');
	lineno++;
	/* set up delimiter defines */
	delimiter.link = '<';
	delimiter.end_link = '>';
	delimiter.token = ':';
     }

     for(;;) {

	  if(InteruptTransfer==TRUE) {
#ifdef HAVE_SIGIO
		signal(SIGIO, SIG_IGN);
#else
     		signal(SIGINT, cleanup_sig);
#endif HAVE_SIGIO
	        fprintf(tempfile,"\nThe rest of the file was aborted during transfer.\n");
		statusline("Transfer aborted!");
		InteruptTransfer==FALSE;
		sleep(1);
		break;
	  }

          iLength = readline(sockfd, inputline, 512);
          if (iLength == 0) {
	       refresh();
               break;
          }

	  total_bytes += iLength;

          ZapCRLF(inputline);

	  if(lineno == 0) 
		if(strstr(inputline,"Server error:")) {
     			fclose(tempfile);
			Socket_Close(sockfd);
			remove(newfile); /* get rid of the empty file */
#ifdef HAVE_SIGIO
			signal(SIGIO, SIG_IGN);
#else
     		        signal(SIGINT, cleanup_sig);
#endif HAVE_SIGIO
			return(-1);
		}
	  
	  /*** Ugly hack ahead..... ***/
          if (GopherStruct->type == A_CSO) {

	       if (inputline[0] == '2') {
		    refresh();
		    break;
		}

	       if(lineno==0) {
		    clear();
	 	    sprintf(tmpline,"    	%s\n",GopherStruct->title);
		    addstr(tmpline);
		    fprintf(tempfile,"%s",tmpline);
		    lineno++;
		}

	       if ((inputline[0] >= '3') && (inputline[0] <= '9'))  {
		    fprintf(tempfile, " \n\n	%s\n", inputline+4);
		    addstr("\n\n	");
		    addstr(inputline+4);
		    addch('\n');
		    refresh();
		    break;
	       }

		/* add the lines to seperate the CSO entries */
	       if (inputline[0] == '-') {
		    /*  lines look like  -200:#: 
		     *  where # can be multiple digits
		     *  find the second colon and check the digit to the
		     *  left of it to see if they are diferent
		     *  if they are draw a line
		     */

		    second_colon = strchr( strchr(inputline,':')+1, ':');

		    if(second_colon != NULL) {

		        if (*(second_colon-1) != i) { 
			     fputs(BIG_LINE, tempfile);
			     if(lineno < LINES-1) {
			        addstr(BIG_LINE);
	     	                lineno++;
			     }
		         }

		        i = *(second_colon-1);
    	
		        sprintf(tmpline, "%s\n", second_colon+1);
	                fprintf(tempfile,"%s",tmpline);

		        if(lineno < LINES-1) {
		            addstr(tmpline); /* write to screen */
			    lineno++;
		        } else if(lineno == LINES-1) {
	    		    statusline(GOPHER_WAIT_MESSAGE);
			    more=TRUE;
		        }
		    }  /* end if second_colon */
	       }
          } else { 
	       if ((inputline[0] == '.') && inputline[1] == '\0') {
		    refresh();
		    break;
		} else {
	       	    if(GopherStruct->type == A_DIRECTORY  || 
			GopherStruct->type == A_INDEX) 
			  /* make dirs look like links */
			strcpy(inputline, make_dir_links(inputline, 
				GopherStruct->type, GopherStruct->search));

		    fprintf(tempfile, "%s\n", inputline);
		
	   
		    /*  the following code will add the first screen 
			of text to the screen as the file is being 
			downloaded, it takes the input line and puts
    			it on the screen 
		     */

		    if(lineno < LINES-1 && (no_more_defines == TRUE || 
					    defineswitch(inputline)==FALSE)) {
			no_more_defines = TRUE;

			if(TRACE)
			    fprintf(stderr,"get_file: displaying line\n");

			/* display a line cannot handle lines with 
			   '\n' in them
	 		   therefore we will break up the line into 
			   multiple segments of a line without '\n's
	 		 */
			single_line = inputline;
			do {

	    		    if((end_of_line = strchr(single_line, '\n')) 									!= NULL)
	       			*end_of_line = '\0';

            			display_a_line(single_line, 
				  &itmp, &lineno, GopherStruct->search, 
				  (*GopherStruct->search== '\0' ? FALSE : TRUE),
		       		  gopher_info, newfile, base1);

	    			lineno++;
		
	    			if(lineno == LINES-1) {
				    break;
	    			}
		
	    			single_line = end_of_line + 1;

			} while(end_of_line);

		    } else if(lineno == LINES-1) {
	    		more = TRUE;
	  		sprintf(tmpline,GOPHER_WAIT_MESSAGE, total_bytes);
	  		statusline(tmpline);
		    }
	      } /* end of else */
          } /* end of if(cso) */
     } /* end of big endless for */

	/* set this just in case.  It really shouldn't be neccessary */
     if(lineno >= LINES-1) {
	more = TRUE;
     }

     fclose(tempfile);
     Socket_Close(sockfd);

#ifdef HAVE_SIGIO
     signal(SIGIO, SIG_IGN);
#else
     signal(SIGINT, cleanup_sig);
#endif HAVE_SIGIO
     return(0);
}
