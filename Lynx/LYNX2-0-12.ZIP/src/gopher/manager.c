#include "gopher.h"

/*
** Centerline, uses curses routines to center a line.
*/

void Centerline(theline, yval)
  char *theline;
  int yval;
{
     if(theline!=NULL)
         mvaddstr(yval, (COLS - strlen(theline))/2, theline);
}
