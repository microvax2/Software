#include "gopher.h"

PUBLIC char *make_dir_links ARGS3(char *,lineptr, char,type, char *,search_string)
{
	/* format from gopher server looks like
	 *  #filename <tab> path <tab> host <tab> port
	 * where # is the file type
	 */
	
	char *tmptr, *tmptr2;
	char *filename, *path, *host, *port;
	char filetype;
	char *token, *space, *tab;
	static char new_string[MAXFNAME];
        register int i, end;
	int col=0;

	if(TRACE)
	    fprintf(stderr,"make_dir_links:  input->\n%s\n",lineptr);

	filetype = *lineptr;  /* file type is the first character */

	filename = lineptr+1; /* set the filename */
	if((tab = strchr(filename, 9)) == NULL) /* find the first tab */
	   return(lineptr);   /* failed to find tab */
	/* make the filename a string by putting a '\0' where the
	 * tab was at the end
	 */
	*tab = '\0';

	path = tab+1;
	if((tab = strchr(path, 9)) == NULL) /* find the second tab */
	   return(lineptr);   /* failed to find tab */
	*tab = '\0';
	 
	host = tab+1;
	if((tab = strchr(host, 9)) == NULL) /* find the third tab */
	   return(lineptr);   /* failed to find tab */
	*tab = '\0';

	port = tab+1;
	ZapCRLF(port);  /* kill the newline char */

	/* kill any gopher plus stuff */
	if((tab = strchr(port, 9)) != NULL) /* find the forth tab */
	    *tab = '\0';

        /* print out the file type, 
	 * but only if verbose gopher is defined and its not a response
	 * to an INDEX request
	 */
	if(verbose_gopher)  {
	    switch(filetype) {
		case '0':
		    strcpy(new_string,"  (FILE) ");
		    break;
		case '1':
		    strcpy(new_string,"  (DIR)  ");
		    break;
		case '2':
		    strcpy(new_string,"  (CSO)  ");
		    break;
	        case '4':
		    strcpy(new_string,"  (HQX)  ");
		    break;
	        case '5':
		    strcpy(new_string,"  (BIN)  ");
		    break;
		case '6':
		    strcpy(new_string,"  (UUE)  ");
		    break;
		case '7':
		    strcpy(new_string,"  (?)    ");
		    break;
		case '8':
		    strcpy(new_string,"  (TEL)  ");
		    break;
	        case '9':
		    strcpy(new_string,"  (BIN)  ");
		    break;
	        case 'I':
		    strcpy(new_string,"  (IMG)  ");
		    break;
 		case 's':
		    strcpy(new_string,"  (SND)  ");
		    break;
	        case 'g':
		    strcpy(new_string,"  (IMG)  ");
		    break;
		case 'h':
		    strcpy(new_string,"  (HTML) ");
		    break;
		case 'T':
		    strcpy(new_string,"  (3270) ");
		    break;
		case 'M':
		    strcpy(new_string,"  (MIME) ");
		    break;
		case 'i':
		    strcpy(new_string,"         ");
		    break;
		default:
		    strcpy(new_string,"  (UNKN) ");
		    break;
	    } 
	} else {
	    strcpy(new_string,"         ");
	}

	/* rewrite the output line to look like we want it 
	 *	<type-path@host port>filename 
	 */

	/* rewrite gopher into URL */
	if(filetype != 'i')  { /* don't write 'i' types */
   	    sprintf(&new_string[strlen(new_string)],"<gopher\\://%s\\:%s/%c",
						host, port, filetype);

	    end = strlen(new_string);
	    /* add the path and end delimiter (>) */
            for(i=0; path[i] != '\0'; i++) {
               if(path[i] == '@' || path[i] == delimiter.token ||
                      path[i] == delimiter.end_link) {
                    new_string[end++] = '\\';
                }
                new_string[end++] = path[i];
             }  /* */
	     new_string[end++] = '>';
	     new_string[end] = '\0';
	}

	/* line wrap the filename */
	token = filename;
	for(;;) {

	    if((space = strchr(token, ' ')) != NULL)
	        *space = '\0';

	    if(strlen(token) > COLS-9) {
		/* token is to big to fit on a line */
		strncat(new_string, token, (COLS-9) - col);
		sprintf(&new_string[strlen(new_string)],"\n         %s", 
						      token[(COLS-9) - col]);
		col = strlen(token) - ((COLS-9) - col) + 9;

	    } else if( strlen(token) + col > COLS-9) {
		/* token would cause line to be too long */
		sprintf(&new_string[strlen(new_string)],"\n         %s", token);
		col = strlen(token) + 9;

	    } else {
		/* token fits on the line */
		sprintf(&new_string[strlen(new_string)],"%s", token);
		col += strlen(token)+1;
	    }

	    if(space == NULL)
		break;   /* that was the last token */
	    else {
		token = space + 1;
		strcat(new_string," "); /* add a space for the next token */
	    }

	}
		
	return(new_string);
} /* big end */
