/* 
 * written by Garrett Arch Blythe
 */

#ifndef __PCCURSES_H
#define __PCCURSES_H 1

#include<conio.h>

extern int LINES;
extern int COLS;

#define gets 	cgets
#define printf 	cprintf
#define puts	cputs
#define scanf	cscanf
#ifdef  getchar
#undef  getchar
#endif
#define getchar getche
#define getstr gets
#ifdef  putchar
#undef  putchar
#endif
#define putchar putch

#ifdef OK
#undef OK
#endif
#define OK 	1
#ifdef ERR
#undef ERR
#endif
#define ERR 	0

#define A_NORMAL 	0
#define A_STANDOUT 	1
#define A_REVERSE 	2
#define A_BOLD		4
#define A_DIM		8
#define A_BLINK		16
#define A_UNDERLINE	32
#define A_MAX		63


typedef int chtype;
typedef void WINDOW;	/*
			 * Not implemented
			 */
int addch(chtype ch);
int addstr(char *str);
int attroff(int attrs);
int attron(int attrs);
int clear(void);
int clrtoeol(void);
int endwin(void);
WINDOW *initscr(void);
void move(int y, int x);
int refresh(void);
int standout(void);
int standend(void);
void echo(void);
void noecho(void);

#endif /*  __PCCURSES_H  */
