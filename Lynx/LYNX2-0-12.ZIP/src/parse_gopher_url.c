#include "defs.h"

/* take a filename in this syntax:
 *  gopheraddress
 *  gopher:// host:port [/ GtypeSelector] ] [ ? search ]
 *
 *  and turn it into
 *
 *  gtype - selector @ host port
 *
 */

PUBLIC void parse_gopher_url ARGS1(char *,filename)
{
    char *cp=filename, *cp2;
    char *colon, *slash, *ques_mark;
    char gtype = '1';
    char *host=NULL, *port=NULL, *selector=NULL, *search=NULL;
    char tmp_file[MAXFNAME];
    
    /* kill beginning spaces */
    while(isspace(*cp)) cp++;

    cp += 9; /* go past the gopher:// part */ 

    host = cp; /* set the host */

    /* find the host and the optional port */
    /* colon is optional */
    if((colon = strchr(cp,':')) != NULL) {
	*colon = '\0';
	port = colon+1;
        cp = colon+1;
    }

	/* if there is more info besides host:port */
    if((slash = strchr(cp,'/')) != NULL) {
 	*slash = '\0';

	if(*(slash+1) != '\0') {
            gtype = *(slash+1);

	    if(*(slash+2) != '\0') {
		selector = slash+2;

	        if((ques_mark = strchr(selector,'?')) != NULL)
	            *ques_mark = '\0';


                /* convert %20's to spaces in selector string */
                for(cp=selector, cp2=selector; *cp != '\0'; cp++, cp2++) {
	            if(!strncmp(cp,"%20",3)) {
	                cp += 2;	
	                *cp2 = ' ';
	            } else {
	                *cp2 = *cp;
	            }
                }
                *cp2 = '\0';

	    } /* end if */
	} /* end if */
    }

    sprintf(tmp_file,"%c-%s@%s %s",gtype, 
			selector ? selector : "", host,
			    port ?   port   : "");



    strcpy(filename, tmp_file);

} /* big end */

