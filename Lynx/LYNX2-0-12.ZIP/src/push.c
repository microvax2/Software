#include "defs.h"
 
/*
 * push the current filename, link and line number onto the history list
 */

PUBLIC void push ARGS7(char *,fname, int,cur, int,line, char *,hlight, 
			char *,gopher_info, char *,real_name, FILE **,fp)
{
    if( *fname == '\0')  /* dont push null file names */
	return;

    if(nhist>1 && STREQ(history[nhist-1].hfname, fname) &&
        history[nhist-1].hlinkno == cur &&
        history[nhist-1].hpageno == line &&
        STREQ(history[nhist-1].hightext, hlight) ) 
        return;  /* file is identical to one before it don't push it */

    if(nhist>2 && STREQ(history[nhist-2].hfname, fname) &&
        history[nhist-2].hlinkno == cur &&
        history[nhist-2].hpageno == line &&
        STREQ(history[nhist-2].hightext, hlight) ) { 
	  nhist--; /* pop one off the stack */
          return;  /* file is identical to one two before it don't push it */
    }

    if (nhist<MAXHIST)  {
	StrAllocCopy(history[nhist].hfname, fname);
	history[nhist].hlinkno = cur;
	history[nhist].hpageno = line;
	StrAllocCopy(history[nhist].hightext, hlight);
	StrAllocCopy(history[nhist].gopher_info, gopher_info);
	StrAllocCopy(history[nhist].real_name, real_name);
	nhist++;
    }
}


/*
 * pop the previous filename, link and line number from the history list
 */
PUBLIC char *pop ARGS5(int *,cur, int *,line, char *,prev_link_name, 
		       char *,gopher_info, char *,real_name)
{
 
    if (nhist>0) {
	nhist--;
	*cur = history[nhist].hlinkno;
	*line = history[nhist].hpageno;
	strcpy(prev_link_name, history[nhist].hightext);
	strcpy(gopher_info, history[nhist].gopher_info);
	strcpy(real_name, history[nhist].real_name);

	if(TRACE)
	   printf(stderr,"pop: gopher_info:%s\nhightext:%s\nrealname:%s\n",
				gopher_info,prev_link_name,real_name);
	return(history[nhist].hfname);
    } else {
	return(" ");
    }
}

/*
 * pop the specified hist entry, link and line number from the history list
 * but don't actually remove the entry, just return it.
 * this procedure is badly named :)
 */
PUBLIC char *pop_num ARGS6(int,number, int *,cur, int *,line, 
			   char *,prev_link_name, char *,gopher_info, 
			   char *,real_name)
{
    if (nhist>= number) {
	*cur = history[number].hlinkno;
	*line = history[number].hpageno;
	strcpy(prev_link_name, history[number].hightext);
	strcpy(gopher_info, history[number].gopher_info);
	strcpy(real_name, history[number].real_name);
	return(history[number].hfname);
    } else {
	return(" ");
    }
}
