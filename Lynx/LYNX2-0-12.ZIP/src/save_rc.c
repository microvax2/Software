#include "defs.h"

PUBLIC void save_rc ()
{
    char line_buffer[256];
    char rcfile[256];
    char *home;
    FILE *fp;

    /* make a name */
#ifdef UNIX
    home = getenv("HOME");
    sprintf(rcfile,"%s/.lynxrc",home);  /* UNIX */
#else
#ifdef VMS
    sprintf(rcfile,"sys$login:.lynxrc");  /* VMS */
#else
    sprintf(rcfile,".lynxrc");   /* anything else */
#endif VMS
#endif UNIX
    
    if((fp = fopen(rcfile,"w")) == NULL) {
	return;
    }

    /* header */
    fprintf(fp,"# Lynx user defaults file\n\n");

    /* editor */
    fprintf(fp,"\
# file editor specifies the editor to be invoked when editing Lynx files.\n\
# if no editor is specified then file editing is disabled unless it\n\
# is activated from the command line\n");
    fprintf(fp,"file_editor=%s\n\n",editor);

    /* home file */
    fprintf(fp,"\
# home_file specifies the name and location of a custom file which the\n\
# user can paste links to for easy access at a later date\n");
    fprintf(fp,"home_file=%s\n\n",home_page);

    /* personal_mail_address */
    fprintf(fp,"\
# personal_mail_address specifies your personal mail address.  The\n\
# address will be sent during HTTP file tranfers for authorization and\n\
# logging purposes, and for mailed comments.\n\
# If you do not want this information given out, leave this field blank\n");
    fprintf(fp,"personal_mail_address=%s\n\n",personal_mail_address);

    /* verbose gopher */
    fprintf(fp,"\
# if verbose gopher mode is on then extra information about the type of\n\
# a Gopher file will be displayed when viewing Gopher directories\n\
# the default is usually off\n");
    fprintf(fp,"gopher_verbose_mode=%s\n\n",(verbose_gopher ? "on" : "off"));

    /* case sensitive */
    fprintf(fp,"\
# if case sensitive searching is on then when the user invokes a search\n\
# using the 's' or '/' keys, the search performed will be case sensitive\n\
# instead of case INsensitive.\n# the default is usually off\n");
    fprintf(fp,"case_sensitive_searching=%s\n\n",(case_sensitive ? "on" : "off"));

    /* local_exec */
    fprintf(fp,"\
# if run all execution links is on then all local exection links will\n\
# be executed when they are selected.\n\
#\n\
# WARNING - this is potentially VERY dangerous.  Since you may view\n\
#           information that is written by unknown and untrusted sources\n\
#           there exists the possibility that trojon horse links could be\n\
#           written.  Trojon horse links could be written to erase files\n\
#           or compromise security.  This should only be set to on if you\n\
#           are viewing trusted source information\n");

    fprintf(fp,"run_all_execution_links=%s\n\n",(local_exec ? "on" : "off"));

    /* local_exec_on_local_files */
    fprintf(fp,"\
# if run all execution links is on then all local exection links that\n\
# are found in LOCAL files will be executed when they are selected.\n\
# This is different from \"run all execution links\" in that only files\n\
# that reside on the local system will have exection link permisions\n\
#\n\
# WARNING - this is potentially dangerous.  Since you may view\n\
#           information that is written by unknown and untrusted sources\n\
#           there exists the possibility that trojon horse links could be\n\
#           written.  Trojon horse links could be written to erase files\n\
#           or compromise security.  This should only be set to on if you\n\
#           are viewing trusted source information\n");

   fprintf(fp,"run_execution_links_on_local_files=%s\n\n",
			(local_exec_on_local_files ? "on" : "off"));

    /* vi keys */
    fprintf(fp,"\
# if VI keys are turned on then the normal VI movement keys:\n\
# j - down    k - up\n\
# h - left    l - right\n\
# will be enabled.\n\
# These keys are only lower case.\n\
# Capital 'H' will still activate help\n");
    fprintf(fp,"vi_keys=%s\n\n",(vi_keys ? "on" : "off"));

    /* emacs keys */
    fprintf(fp,"\
# if EMACS keys are turned on then the normal EMACS movement keys:\n\
# ^N - down    ^p - up\n\
# ^B - left    ^F - right\n\
# will be enabled.\n");
    fprintf(fp,"emacs_keys=%s\n\n",(emacs_keys ? "on" : "off"));

    fprintf(fp,"\
# if keypad_mode is set to NUMBERS_AS_ARROWS then the numbers\n\
# on your keypad when the numlock is on will act as arrow keys.\n\
# i.e. 4 - Left Arrow, 6 - Right Arrow, 2 - Down Arrow, 8 - Up Arrow, etc.\n\
# if keypad_mode is set to LINKS_ARE_NUMBERED then numbers will appear\n\
# next to each link and numbers are used to select links.\n\
# note: some fixed format documents may look disfigured when\n\
# LINKS_ARE_NUMBERED is enabled\n");
    fprintf(fp,"keypad_mode=%s",(keypad_mode==NUMBERS_AS_ARROWS ? 
				"NUMBERS_AS_ARROWS" : "LINKS_ARE_NUMBERED"));
 
    fclose(fp);

    /* get rid of any copies of the .lynxrc file that VMS creates */
#ifdef VMS
        while (delete("sys$login:.lynxrc;-1") == 0) ;
#endif /* VMS */


}
