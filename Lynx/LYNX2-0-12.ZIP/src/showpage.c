#include "defs.h"

/*
 * display one screen of text
 *
 * Read & display one screenfull of text.
 * Looks for (and remembers) links, and converts IBM PC line drawing
 * characters to standard ascii
 *
 * Pre-reads one line from the next page, to ensure that the "- more -"
 * message is only displayed when there really is more.
 *
 * Reads defines from the top of files and handles them appropriatly
 * link_delimiter = x  set x as the link_delimiter
 * path = xxx sets xxx as the new path base.
 * adds path(base1) to the filename, etc. etc
 */

PUBLIC int showpage ARGS11(FILE **,fp, int *,cur_line, int,oldline, 
			int,savline, BOOLEAN,target_present, char *,target, 
			char *,cur_file, char *,base1, int *,cur, 
			char *,gopher_info, char *,owner)
{
    int lineno, itmp;
    char tmp[12];
    BOOLEAN dont_reset_cur=FALSE;


	/* initalize some defaults */
retry:

    if (*cur_line < 1)
	*cur_line = 1;


    if (*cur_line == oldline) {		/* nothing to do */
	return(0);
    } else if (*cur_line != oldline+LINES-1 || oldline == 0) {	
	/* have to back up */
	more = FALSE;
	rewind(*fp);
	checkfordefines(*fp); 
	oldline = 0;
    }

	/* advance the file to the correct position */
    if (oldline==0) {
	more = FALSE;
	lineno = oldline;

	while (lineno<((*cur_line-1)) && fgets(line, LINESIZE, *fp)
		 != NULL){
	    lineno++;
	}
	
	if(lineno < (*cur_line-1)) {  /*if cur_line is larger than the file*/
	    *cur_line=lineno-(LINES-2);
	    oldline=0;
	    goto retry;
	}
    }

	/* display exactly one page of data */
    lineno = 0;
    while (lineno<(LINES-1) && (more || fgets(line, LINESIZE, *fp) != NULL)) {
	more = FALSE;

     if(dont_reset_cur == FALSE)
        dont_reset_cur= display_a_line(line, cur, &lineno, target, 
			      target_present, gopher_info, cur_file, base1);
    else  /* send itmp instead of cur, so cur doesnt get reset */
        display_a_line(line, &itmp, &lineno, target, target_present,
    		       gopher_info, cur_file, base1);

    lineno++;
    }

    if(lineno == 0 && *cur_line == 1) { /* if it was an empty file */
	clear();
	move(5,5);
	addstr("File is empty");
	nlinks=0;
    }

	/* check for more data */
    if (lineno>(LINES-2) && fgets(line, LINESIZE, *fp) != NULL)
	more = TRUE;
    refresh();
    return(lineno);
}
	
