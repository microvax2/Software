#include "defs.h"

/*
 * display_a_line takes a line of text as input (line) parses the line
 * for links and targets and then displays it charactor by charactor to
 * the screen.
 * BTW This procedure is pretty ugly right now so remind myself to clean
 * it up some time.
 */

PUBLIC BOOLEAN display_a_line ARGS8(char *,line, int *,cur, int *,lineno,
		    char *,target, BOOLEAN,target_present,
		    char *,gopher_info, char *,cur_file, char *,base1)
{
	register char *acp, *cp;
	int col;
	int last_nlinks;
	BOOLEAN show_next_char=TRUE;
	BOOLEAN dont_reset_cur=FALSE;
	BOOLEAN hidden_target_on_this_line=FALSE;
	char link_number_string[10];
	struct attribtype attrib;  /* structure to hold special curses info */
	char output_buf[2]; /* one char, plus terminator */
 
	/* terminate the empty string 
	 * this will be used to put one char at a time on the screen
	 * using a addstr instead of a addch.  addch seems to be
	 * broken and will not display the ISO_LATIN1 char set
	 */
	output_buf[1] = '\0';
	cp = line;

	/* clear attributes */
        stop_bold();
	stop_underline();
	stop_reverse();

	 /* set attrib. to 9999 ( or any really large number)  */
	attrib.underline_start_col = 9999; 
	attrib.underline_end_col = 9999;
	attrib.bold_start_col = 9999;
	attrib.bold_end_col = 9999;
	
	if(target_present) { /* check to see if a target is on this line */
		/* mystrstr doesnt search the links only the text */
	  if((cp = mystrstr(line,target)) != NULL) {
		attrib.underline_start_col = cp-line;
		attrib.underline_end_col = cp-line+strlen(target);
	    /* if mystrstr didn't find it see if its in the links */
	  } else if((cp = altstrstr(line,target)) != NULL) { 
	      /* altstrstr only searches hidden targets */
	      /*if it is a hidden target*/
		attrib.underline_start_col = 0;   /* highlight the whole line */
		attrib.underline_end_col = 9999;
		hidden_target_on_this_line = TRUE;
	  }
        } /* end of if(target_present) */

	if((cp = strchr(line,'\n')) != NULL)
	    *cp = '\0';		/* remove trailing <return> */

	if (*lineno == 0) { /* if its the Top of the page, clear it */
	    clear();
	    nlinks = 0;
	}
	col = 0;
	for (cp=line; *cp != '\0' && ((cp-line) < LINESIZE); cp++) {
		/* start big line loop */

		   /* keep stuff from going off the screen */
		  if((*cp == ' ' && col >= COLS-LINEWRAP && 
		     linewrap(cp, col)) || (col >= COLS-1)) {
		        addch('\n');  /* */
			cp++;  /* go past space */
		        col = 0;
		        *lineno = *lineno+1;
		        attrib.underline_start_col = 9999;
		        attrib.underline_end_col -= COLS;
		    }

		if(*cp == '_' && *(cp+1) == 8) {  /* if its _^H */
		   cp += 2;                      /* underline it */
		   attrib.underline_start_col = col; /* to handle man pages */
		   attrib.underline_end_col = col+1;
		}

		if(*cp == 8) {  /* if its just an ^H */
		   cp += 1;   /* skip the next letter and the ^H */
		   show_next_char = FALSE;
	 	}


/* handle bolding of targets and links */
	    if(col == attrib.bold_start_col) {
		start_bold();
	    }

	    if(col == attrib.bold_end_col) {
		attrib.bold_end_col=9999;
		stop_bold();

		/* turning the bold off often seems to undo the underlining
		 * so lets check to see weather it should be on and turn it
		 * on if it should be
		 */
	        if(col >= attrib.underline_start_col)
		    start_underline();
	    }

/* handle underlining of targets and links */
	    if(col == attrib.underline_start_col) {
		start_underline();
	    }

	    if(col >= attrib.underline_end_col
	       && attrib.underline_end_col < 9000) {
		attrib.underline_end_col=9999;
		attrib.underline_start_col=9999;
		
		stop_underline();
	    }

	/* convert IBM line drawings to unix-like lines */
	/* maybe this big else if should be a switch, may-be not
	 * any input???
	 */
	    if (!printable(*cp)) {
		if      (*cp == HLINE)	*cp = '-';
		else if (*cp == VLINE)	*cp = '|';
		else if (*cp == VLINE2)	*cp = '|';
		else if (*cp == UL)	*cp = '+';
		else if (*cp == UR)	*cp = '+';
		else if (*cp == LL)	*cp = '+';
		else if (*cp == LR)	*cp = '+';
		else if (*cp == UL2)	*cp = '+';
		else if (*cp == UR2)	*cp = '+';
		else if (*cp == LL2)	*cp = '+';
		else if (*cp == LR2)	*cp = '+';
		else if (*cp == BULLET)	*cp = '*';
		else if (*cp == BLOT1)	*cp = '*';
		else if (*cp == BLOT2)	*cp = '*';
		else if (*cp == BLOT3)	*cp = '*';
		else {
#ifdef DEBUG
		    /* shouldn't happen - see what we've missed */
		    if (*cp != 13) {
			printw("%d", *cp);
			refresh();
		    }
#endif
		    *cp = ' ';
		}
		/* don't print returns */
		/* check for double delimiters and skip them */
	    } else if (*cp == delimiter.link && *(cp+1) == delimiter.link) {
		attrib.underline_end_col--;
		attrib.bold_end_col--;
		cp++;  /* skip double dilimiters */

		/* this is probably a link lets parse it */
	    } else if (*cp == delimiter.link && *(cp-1) != delimiter.link) {
			   /* start of link? */

	        last_nlinks = nlinks;

		/* if link_numbering is on make the string to put
		 * in front of links, but don't add it yet because
		 * were not yet sure that this is a valid link!
		 * but increase the col numbers so that if there is
		 * a link it will get put in the right place!
		 */
		if(keypad_mode == LINKS_ARE_NUMBERED) {
		   sprintf(link_number_string,"[%d]",nlinks+1);
                   col += strlen(link_number_string);
		}

#ifdef FORMS
		if(lynx_mode == FORMS_LYNX_MODE && *(cp+1)=='#') {
		    cp=parse_form_links(cp+1, &col, *lineno, cur_file,
							&show_next_char);

		} else {
#else
		if (1) {  /* if not a form */
#endif FORMS

		    cp=parselinks(cp, base1, col, *lineno, cur_file, 
			          &show_next_char, &attrib, gopher_info);


		    if(target_present && dont_reset_cur==FALSE)
		       if(hidden_target_on_this_line) {
		          *cur = nlinks-1; /* set link ## to target */
		          dont_reset_cur = TRUE;
		       } else if(mystrstr(links[nlinks-1].hightext,target)) {
		          *cur = nlinks-1; /* set link ## to target */
		          dont_reset_cur = TRUE;
		       }
		}

		if(nlinks != last_nlinks && keypad_mode == LINKS_ARE_NUMBERED) {
		    /* there was a link, lets add numbering */
		    addstr(link_number_string);
		} else if(keypad_mode == LINKS_ARE_NUMBERED) {
		    /* we added some to col but there turned out not
		     * to be a link after all, so subtract from col
		     * what we added
		     */
		     col -= strlen(link_number_string);
		}
		
	    } else if (*cp == '\t') {	/* expand tabs */
		    int itmp;
		    itmp = 8 - (col % 8);
                    col += itmp;

		    /* expand tabs manually */
		    if(col < COLS-8) 
		        for(;itmp > 0;itmp--)
			    addch(' ');

		    show_next_char = FALSE;

		    attrib.underline_start_col += itmp;
		    attrib.underline_end_col += itmp;

		/* this next stuff is from the old hytelnet code that
		 * checks for the word telnet or tn3270 and then checks
		 * for a valid internet address near it.
 		 */
	    } else if (toupper(*cp) == 'T') {	/* telnet command? */
		int type = TELNET;  /* telnet or tn3270 */
		char taddr[256];
		char newlink[256];
		if (telnet_ok && col == 0 && isspace(*(cp-1)) &&
		         (!strncasecmp(cp,"telnet ",7) ||
		          !strncasecmp(cp,"tn3270 ",7)) ) { 

		    acp=interaddr(cp+7, taddr);
		    while (acp != NULL && nlinks < MAXLINKS) {
			StrnAllocCopy(links[nlinks].hightext,cp, 6);

			if (*(cp+5) == '0')
			    type = TN3270;

			if(type==TELNET)
			    sprintf(newlink, "telnet\\://%s", taddr);
			else
			    sprintf(newlink, "tn3270\\://%s", taddr);

			StrAllocCopy(links[nlinks].lname, newlink);
			links[nlinks].lx = col;
			links[nlinks].ly = *lineno;

			nlinks++;
		    }
		}
		/* this is probably a target lets parse it */
	    } else if(*cp == delimiter.target[0]) {
		if(*(cp+1)== delimiter.target[1] || delimiter.target[1]=='\0'){ 
		  if((acp = strchr(cp,delimiter.end_target[1])) != NULL && 
		     *(acp-1) == delimiter.end_target[0]) {
	        	attrib.underline_start_col -= acp-cp+1;	
	        	attrib.underline_end_col -= acp-cp+1;	
			cp = acp;
			show_next_char = FALSE;	
		  }
		}
	    } /* end of the really big else-if */
	
		/* finally print the charactor */
		if(show_next_char == TRUE) {
		  /* addch seems to be broken for ISOLATIN1 char set 
		   * addch(*cp);
		   * assume output_buf[1] == '\0'
		   */
		  output_buf[0] = *cp;
		  addstr(output_buf);
	    	  col++;
		}
		else
		 show_next_char = TRUE; /* reset */
	/* now go back to the top and do it all again for each letter 
	   in the line */	
	}

	/* refresh the screen on every line if lynx is invoked as a child */
	if(child_lynx==TRUE)
		refresh();

     addch('\n');  /* go down to next line */
#ifdef MSDOS
     addch('\r');  /* add cariage return to pc's */
/* why are pc's so brain dead??? */
#endif MSDOS

     return(dont_reset_cur);   
	/* if dont_reset_cur is TRUE then we found the search string in
	 * one of the links highlighted text, don't look again for it
	 */

} /* big end */
