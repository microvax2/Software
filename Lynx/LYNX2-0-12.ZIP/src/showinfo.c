#include "defs.h"
#ifndef VMS
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <limits.h>
#else
#include <types.h>
#include <stat.h>
#endif

/* 
 * showinfo prints a page of info about the current file and the link
 * that the cursor is on
 */
	     
PUBLIC int showinfo ARGS5(int,cur, char *,newfile, char *,prevlinkname, 
	                  char *,target, int,size_of_file)
{
	int x=0, curr=0,tmp=0;
	char temp[100];

	clear();

	
	addstr("\n                  YOU HAVE REACHED THE INFORMATION PAGE\n\n");
	
	addstr("File that you are currently viewing\n\n");
	addstr("        Linkname:  ");
	addstr(prevlinkname);
	addch('\n');

	addstr("        Filename:  ");
	addstr(newfile);
	addch('\n');


	addstr("        Owner(s):  ");
	if(owner[0] == '\0')
		addstr("None");
	else
		addstr(owner);
	addch('\n');

	addstr(" Owner's address:  ");
	if(owner_address[0] == '\0')
	   	addstr("None\n");
	else {
		addstr(owner_address);
	        addch('\n');
	}

	addstr("      Owner info:  ");
	if(owner_info[0] == '\0')
	   	addstr("None\n");
	else {
		addstr(owner_info);
	        addch('\n');
	}

	if(child_lynx)
	    refresh();

	addstr("            Type:  ");
	if(strchr(newfile,'@'))
		addstr("Remote ");
	else
		addstr("Local ");
	if(newfile[0]=='!')
		addstr("command\n");
	else
		addstr("text\n");

	addstr("          Target:  ");
	if(*target=='\0')
		addstr("None");
	else
		addstr(target);
	addch('\n');

	sprintf(temp,"            size:  %d lines\n",size_of_file);
	addstr(temp);

	addstr("       lynx mode:  ");
	addstr(lynx_mode == WWW_LYNX_MODE ? "WWW" :
		   lynx_mode == FORMS_LYNX_MODE ? "forms mode" :
			 			    "normal");
	addch('\n');


     if(nlinks > 0) {
	addstr("\nLink that you currently have selected\n\n");
	addstr("        Linkname:  ");
	addstr(links[cur].hightext);
	addch('\n');
	addstr("        Filename:  ");
	addstr(links[cur].lname);
	addch('\n');

	if(child_lynx)
	    refresh();

	addstr("            Type:  ");
	if(strchr(links[cur].lname,'@'))
		addstr("Remote ");
	else
		addstr("Local ");
	if(links[cur].lname[0]=='!')
		addstr("command");
	else if(links[cur].lname[0]=='1')
		addstr("directory");
	else
		addstr("text");
	addch('\n');

	addstr("          Target:  ");
	if(links[cur].target==NULL || links[cur].target[0]=='\0')
		addstr("None");
	else {
		gettargetname(temp,cur);
		addstr(temp);
	}
	addch('\n');
     }
     else
	addstr("\n\nNo Links on the current page\n");

	refresh();

	mygetch();
}
