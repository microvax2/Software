#include "defs.h"

int change_form_link ARGS2(struct link *, form_link, int, mode)
{

    FormInfo *form = form_link->form;
    int inum;
    char *tmptr;
    char c=0;

    /* move to the link position */
    move(form_link->ly, form_link->lx);

    switch(form->type) {
	case F_CHECKBOX_TYPE:
	case F_RADIO_TYPE:
	    if(form->num_value) {
		form_link->hightext = unchecked_box;
		form->num_value = 0;
	    } else {
		form_link->hightext = checked_box;
		form->num_value = 1;
	    }
    		/* add the new info */
    	    addstr(form_link->hightext);

	    
	    break;

	case F_TEXT_TYPE:
	case F_PASSWORD_TYPE:
	    c = form_getstr(form);
	    form_link->hightext = form->value;
	    break;

	case F_RESET_TYPE:
	    break;
	
	case F_SUBMIT_TYPE:
	    break;

#ifdef EXTENDED_FORM_TYPES
	case INT_TYPE:
		/* make a width string so that we can maintain the width */
	    sprintf(print_arg,"%%-%dd",strlen(form_link->hightext));
	    sprintf(newstring, print_arg, form_link->cur_value);
	    form_getstr(newstring, INT_TYPE);

	    /* kill spaces at the beginning */
	    tmptr = newstring;
	    while(*tmptr==' ') tmptr++;

	    inum = atoi(tmptr);
	    if(inum < form_link->lrange || inum > form_link->hrange) {
		sprintf(newstring,"Integer value must be between %d and %d",
			form_link->lrange, form_link->hrange);
		statusline(newstring);
	    } else {
	        sprintf(form_link->hightext, print_arg, inum);
		form_link->cur_value = inum;
	    }
	    break;

	case MONTH_TYPE:
	case DATE_MONTH_TYPE:
	    if(mode==FORM_UP) {
		if(form_link->cur_value < 11)
		    form_link->cur_value++;
		else
		    form_link->cur_value = 0;
	    } else {
		if(form_link->cur_value > 0)
		    form_link->cur_value--;
		else
		    form_link->cur_value = 11;
	    }

	    strcpy(form_link->hightext,month_strings[form_link->cur_value]);
	    addstr(form_link->hightext);
	    break;
	case DATE_MDAY_TYPE:
	case MDAY_TYPE:
	    if(mode==FORM_UP) {
		if(form_link->cur_value < 31)
		    form_link->cur_value++;
		else
		    form_link->cur_value = 1;
	    } else {
		if(form_link->cur_value > 1)
		    form_link->cur_value--;
		else
		    form_link->cur_value = 31;
	    }

	    sprintf(form_link->hightext,"%2d",form_link->cur_value);
	    addstr(form_link->hightext);
	    break;
	case DATE_YEAR_TYPE:
	case YEAR_TYPE:
	    if(mode==FORM_UP) {
		if(form_link->cur_value < 2000)
		    form_link->cur_value++;
		else
		    form_link->cur_value = 1970;
	    } else {
		if(form_link->cur_value > 1970)
		    form_link->cur_value--;
		else
		    form_link->cur_value = 2000;
	    }

	    sprintf(form_link->hightext,"%4d",form_link->cur_value);
	    addstr(form_link->hightext);
	    break;
#endif
    }

    switch(c) {
	case UPARROW:
	    return(-1);

	case DNARROW:
	case       9: /* tab */
	    return(1);

	default:
	    return(0);
    }

} 
