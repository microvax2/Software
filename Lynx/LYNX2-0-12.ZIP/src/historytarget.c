#include "defs.h"

/* 
 * this is a kludge to make the history page seem like any other type of file
 * since more info is needed than can be provided by the normal link structure
 * I saved out the info in a formated field in show history so now I can
 * parse it specifically for the info I need ie:
 * 	lineno, cur, gopher_info
 */


PUBLIC void historytarget ARGS5(char *,lname, char *,gopher_info, 
				char *,target,int *,cur, int *,page)
{
	char tmp[8], *str, *str2;

	if((str = strchr(lname,'&')) !=NULL) {
	   strcpy(gopher_info,"@");  /* put a @ at the beginning */
 	   strcat(gopher_info,str+1);
	   *str = '\0';	
	}
	else
	   gopher_info[0] = '\0';

	if((str = strchr(target,'|')) == NULL) {
		cleanup();
		cleanup_files();
		perror("error parsing history file");
		exit(1);
	}

	str2 = str+1;
	while(isspace(*str2)) str2++;   /* get rid of spaces */
	mystrncpy(tmp, str2, 4);
	*cur = atoi(tmp);

	str2 = str+6;
	while(isspace(*str2)) str2++;   /* get rid of spaces */
	mystrncpy(tmp, str2, 4);
	*page = atoi(tmp);

	*target = '\0';  /* erase target */

	
}
