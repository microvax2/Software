#include "defs.h"

int is_true PARAMS((char *string));

PRIVATE int is_true ARGS1(char *,string)
{
   if(!strncasecomp(string,"TRUE",4))
	return(TRUE);
   else
	return(FALSE);
}

PUBLIC void read_cfg ARGS1(char *,cfg_filename)
{
    FILE *fp;
    char buffer[501];
    char *line_feed;

    if((fp = fopen(cfg_filename,"r")) == NULL) {
	if(TRACE)
	    fprintf(stderr,"lynx.cfg file not found as %s\n",LYNX_CFG_FILE);
	return;
    }

    while(fgets(buffer, 500, fp) != NULL) {

	/* strip of \n at the end */
	if((line_feed = strchr(buffer,'\n')) != NULL)
	    *line_feed = '\0';
	
	if(buffer[0] == '#') {
	    /* nothing */

	} else if(!strncasecomp(buffer,"ALERTMAIL:",10)) {
	    strcpy(owner_address, buffer+10);

	} else if(!strncasecomp(buffer,"STARTFILE:",10)) {
	    int length = strlen(buffer)-9;

	    startfile = (char *) calloc(length, sizeof(char));
	    if(startfile==NULL)
		perror("Out of memory in read_cfg");
	    else
	        strcpy(startfile, buffer+10);

	} else if(!strncasecomp(buffer,"HELPFILE:",9)) {
	    int length = strlen(buffer)-8;

	    helpfile = (char *) calloc(length, sizeof(char));
	    if(helpfile==NULL)
		perror("Out of memory in read_cfg");
	    else
	        strcpy(helpfile, buffer+9);

	} else if(!strncasecomp(buffer,"DEFAULT_INDEX_FILE:",19)) {
	    strcpy(indexfile, buffer+19);

	} else if(!strncasecomp(buffer,
				    "LOCAL_EXECUTION_LINKS_ALWAYS_ON:",32)) {
	    local_exec = is_true(buffer+32);

	} else if(!strncasecomp(buffer,
			    "LOCAL_EXECUTION_LINKS_ON_BUT_NOT_REMOTE:",40)) {
	    local_exec_on_local_files = is_true(buffer+40);

	} else if(!strncasecomp(buffer,"VERBOSE_GOPHER:",15)) {
	    verbose_gopher = is_true(buffer+15);
	
	} else if(!strncasecomp(buffer,"MAIL_SYSTEM_ERROR_LOGGING:",26)) {
	    error_logging = is_true(buffer+26);

	} else if(!strncasecomp(buffer,"VI_KEYS_ALWAYS_ON:",18)) {
	    vi_keys = is_true(buffer+18);

	} else if(!strncasecomp(buffer,"EMACS_KEYS_ALWAYS_ON:",21)) {
	    emacs_keys = is_true(buffer+21);

	} else if(!strncasecomp(buffer,
			"DEFAULT_KEYPAD_MODE_IS_NUMBERS_AS_ARROWS:",41)) {
	    if(is_true(buffer+41))
		keypad_mode = NUMBERS_AS_ARROWS;
	    else
		keypad_mode = LINKS_ARE_NUMBERED;

	} else if(!strncasecomp(buffer,"CASE_SENSITIVE_ALWAYS_ON:",25)) {
	     case_sensitive = is_true(buffer+25);

	} else if(!strncasecomp(buffer,"PRINTER:",8)) {
	        char *colon, *next_colon;
	        printer_type *cur_printer, *prev_printer;

	        /* make linked list of printers */
	        if(printers == NULL) {  /* first printer */
		
	            cur_printer = malloc(sizeof(printer_type));
		
	            if(cur_printer == NULL)
		        perror("Out of memory in read_cfg");

		    printers = cur_printer;
		
	        } else {

		   /* find the last printer */
		   for(prev_printer=printers; prev_printer->next != NULL;
				  	     prev_printer = prev_printer->next)
			   ;  /* null body */

	            cur_printer = malloc(sizeof(printer_type));
		
	            if(cur_printer == NULL)
		        perror("Out of memory in read_cfg");
		    else
		        prev_printer->next = cur_printer;
	        }
		
		cur_printer->next = NULL;
		cur_printer->name = NULL;
		cur_printer->command = NULL;
		cur_printer->always_enabled = FALSE;

		/* find first colon */
		colon = strchr(buffer+8,':');
		/* make sure it isn't escaped by a backslash */
		while(colon!=NULL && *(colon-1)=='\\')
			/* if it was escaped, try again */
		    colon = strchr(colon+1,':');
	
		if(colon!=NULL) {
		
		    cur_printer->name = calloc((colon-(buffer+7)),sizeof(char));
		    if(cur_printer->name == NULL)
		        perror("Out of memory in read_cfg");

		    mystrncpy(cur_printer->name, buffer+8, colon-(buffer+8));	

		    remove_backslashes(cur_printer->name);

		    next_colon = strchr(colon+1,':');
		    /* make sure it isn't escaped by a backslash */
		    while(next_colon!=NULL && *(next_colon-1)=='\\')
			/* if it was escaped, try again */
		        next_colon = strchr(next_colon+1,':');

		    if(next_colon!=NULL) {
			
			cur_printer->command = calloc(next_colon-colon, 
								sizeof(char));

			if(cur_printer->command == NULL)
                            perror("Out of memory in read_cfg");

			mystrncpy(cur_printer->command, colon+1, 
							next_colon-(colon+1));

		        remove_backslashes(cur_printer->command);
			
		        printers->always_enabled = is_true(next_colon+1);
		    }
		}
        }  /* end of Huge if */
    } /* end if while */
}
