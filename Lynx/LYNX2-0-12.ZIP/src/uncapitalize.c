#include "defs.h"

/* uncapitalize an entire string
 */

PUBLIC char *uncapitalize ARGS1(char *,buf)
{
	char *cp, *tmpbuf;	
	
	cp=buf;
	tmpbuf=buf;	
	for(; *cp != '\0'; tmpbuf++, cp++)
		*tmpbuf = tolower(*cp);
	*tmpbuf = '\0';

	return(buf);
}
