#include "defs.h"

PUBLIC void read_rc()
{
    char line_buffer[256];
    char *home;
    char rcfile[256];
    FILE *fp;
    char *cp, *cp2;
    int number_sign;

    home = getenv("HOME");

    /* make a name */
#ifdef UNIX
    home = getenv("HOME");
    sprintf(rcfile,"%s/.lynxrc",home);  /* UNIX */
#else
#ifdef VMS
    sprintf(rcfile,"sys$login:.lynxrc");  /* VMS */
#else
    sprintf(rcfile,".lynxrc");   /* anything else */
#endif VMS
#endif UNIX

    if((fp = fopen(rcfile,"r")) == NULL) {
	return;
    }

    while(fgets(line_buffer, 256, fp) != NULL) {

	/* remove the end /n */
	if(line_buffer[strlen(line_buffer)-1] == '\n')
	     line_buffer[strlen(line_buffer)-1] = '\0';

        /* find the line position of the number sign if there is one */
        if((cp = strchr(line_buffer,'#')) == NULL)
	    number_sign = 999;
	else
	    number_sign = cp - line_buffer;

        /* file editor */
	if((cp=mystrstr(line_buffer,"file_editor"))!=NULL &&
		cp-line_buffer < number_sign) {

	       if((cp2 = strrchr(cp,'=')) != NULL)
		    cp = cp2+1;

	       while(isspace(*cp)) cp++;  /* get rid of spaces */
	
 	       strcpy(editor, cp);

	/* home file */
	} else if((cp=mystrstr(line_buffer,"home_file"))!=NULL &&
		cp-line_buffer < number_sign) {

	   if((cp2 = strrchr(cp,'=')) != NULL)
		cp = cp2+1;

	   while(isspace(*cp)) cp++;  /* get rid of spaces */

	   strcpy(home_page, cp);

	/* personal_mail_address */
	} else if((cp=mystrstr(line_buffer,"personal_mail_address"))!=NULL &&
		cp-line_buffer < number_sign) {

	   if((cp2 = strrchr(cp,'=')) != NULL)
		cp = cp2+1;

	   while(isspace(*cp)) cp++;  /* get rid of spaces */

	   strcpy(personal_mail_address, cp);

	} else if((cp = mystrstr(line_buffer,"gopher_verbose_mode")) != NULL &&
		cp-line_buffer < number_sign) {

	   if((cp2 = strrchr(cp,'=')) != NULL)
		cp = cp2+1;

	   while(isspace(*cp)) cp++;  /* get rid of spaces */

	   if(!strncmp(cp,"on",2) || !strncmp(cp,"ON",2))
	      verbose_gopher=TRUE;
	   else
	      verbose_gopher=FALSE;

	} else if((cp = mystrstr(line_buffer,"case_sensitive_searching"))
								   != NULL &&
		cp-line_buffer < number_sign) {

	   if((cp2 = strrchr(cp,'=')) != NULL)
		cp = cp2+1;

	   while(isspace(*cp)) cp++;  /* get rid of spaces */

	   if(!strncmp(cp,"on",2) || !strncmp(cp,"ON",2))
	      case_sensitive=TRUE;
	   else
	      case_sensitive=FALSE;

	} else if((cp = mystrstr(line_buffer,"run_all_execution_links")) 
								 != NULL &&
		cp-line_buffer < number_sign) {

	   if((cp2 = strrchr(cp,'=')) != NULL)
		cp = cp2+1;

	   while(isspace(*cp)) cp++;  /* get rid of spaces */

	   if(!strncmp(cp,"on",2) || !strncmp(cp,"ON",2))
	      local_exec=TRUE;
	   else
	      local_exec=FALSE;

	} else if((cp = mystrstr(line_buffer,
			"run_execution_links_on_local_files")) != NULL &&
		cp-line_buffer < number_sign) {

	   if((cp2 = strrchr(cp,'=')) != NULL)
		cp = cp2+1;

	   while(isspace(*cp)) cp++;  /* get rid of spaces */

	   if(!strncmp(cp,"on",2) || !strncmp(cp,"ON",2))
	      local_exec_on_local_files=TRUE;
	   else
	      local_exec_on_local_files=FALSE;

	} else if((cp=mystrstr(line_buffer,"vi_keys"))!=NULL &&
		cp-line_buffer < number_sign) {

	   if((cp2 = strrchr(cp,'=')) != NULL)
		cp = cp2+1;

	   while(isspace(*cp)) cp++;  /* get rid of spaces */
	
	   if(!strncmp(cp,"on",2) || !strncmp(cp,"ON",2))
	      vi_keys=TRUE;
	   else
	      vi_keys=FALSE;

        } else if((cp=mystrstr(line_buffer,"emacs_keys"))!=NULL &&
                cp-line_buffer < number_sign) {

           if((cp2 = strrchr(cp,'=')) != NULL)
                cp = cp2+1;

           while(isspace(*cp)) cp++;  /* get rid of spaces */

           if(!strncmp(cp,"on",2) || !strncmp(cp,"ON",2))
              emacs_keys=TRUE;
           else
              emacs_keys=FALSE;


	} else if((cp=mystrstr(line_buffer,"keypad_mode"))!=NULL &&
		cp-line_buffer < number_sign) {

	   if((cp2 = strrchr(cp,'=')) != NULL)
		cp = cp2+1;

	   while(isspace(*cp)) cp++;  /* get rid of spaces */
	
	   if(mystrstr(cp,"LINKS_ARE_NUMBERED"))
	      keypad_mode = LINKS_ARE_NUMBERED;
	   else
	      keypad_mode = NUMBERS_AS_ARROWS;

	} /* end of if */

    } /* end of while */
 
    fclose(fp);
} /* big end */
	
