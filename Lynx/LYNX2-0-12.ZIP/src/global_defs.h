/* global variable definitions */

#define GLOBAL_DEFS 1

#ifndef BOOLEAN
#define BOOLEAN char
#endif

#define DIRNAMESIZE 256
extern int HTCacheSize;  /* the number of documents cached in memory */
extern int InteruptTransfer;
extern char *checked_box;  /* form boxes */
extern char *unchecked_box;  /* form boxes */
extern char *empty_string;
extern char orig_dir[DIRNAMESIZE];
extern char *month_strings[];
extern char *wday_strings[];
extern char form_server[120];
extern int port_syntax;
extern int gopher_port;
extern char *startdir;
extern char *startfile;
extern char *helpfile;
extern char indexfile[256];
extern char line[LINESIZE+1];
extern char owner[120];
extern char owner_address[120];
extern char owner_info[120];
extern char personal_mail_address[120];
extern char base1[MAXBASE];
extern char *display;
extern BOOLEAN anonymous;
extern BOOLEAN is_www_index;
extern int www_search_result;
extern BOOLEAN lynx_mode;
extern BOOLEAN recent_sizechange;
extern BOOLEAN telnet_ok;		/* TRUE to exec telnet commands */
extern BOOLEAN telnet_by_name;	/* TRUE to use Internet name for telnet */
extern BOOLEAN telnet_by_number;/* TRUE to use Internet number for telnet */
extern BOOLEAN no_print;    /* TRUE to disable printing */
extern BOOLEAN local_exec;  /* TRUE to enable local program execution */
        /* TRUE to enable local program execution in local files only */
extern BOOLEAN local_exec_on_local_files; 
extern BOOLEAN child_lynx;	  /* TRUE to exit with an arrow */
extern BOOLEAN verbose_gopher;    /* TRUE to print verbose gopher messages */
extern BOOLEAN error_logging;     /* TRUE to mail error messages */
extern BOOLEAN vi_keys;           /* TRUE to turn on vi-like key movement */
extern BOOLEAN emacs_keys;        /* TRUE to turn on emacs-like key movement */
extern BOOLEAN keypad_mode;       /* is set to either NUMBERS_AS_ARROWS or
				   * LINKS_ARE_NUMBERED 
				   */
extern BOOLEAN case_sensitive;    /* TRUE to turn on case sensitive search */
extern char editor[128];          /* if non empty it enables edit mode with
				   * the editor that is named */
extern char home_page[256];

/* global variables used by emulator */
extern int norm_sock;
extern BOOLEAN end_emulator;
