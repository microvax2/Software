#include "defs.h"
/*
 * These are routines to start and stop curses and to cleanup
 * the screen at the end
 *
 */

PRIVATE dumbterm PARAMS((char *terminal));

PUBLIC void start_curses ()
{
#ifndef VMS
    static BOOLEAN first_time = TRUE;

	/* if were not VMS then only do initsrc() one time
	 * and one time only!
	 * if we are VMS then do initsrc() everytime start_curses()
	 * is called!
	 */
    if(first_time) {
        initscr();	/* start curses */
        first_time = FALSE;
    }

#else
    initscr();	/* start curses */
#endif VMS

    /* nonl();   *//* seems to slow things down */

#ifdef VMS
    crmode();
    raw();
#endif VMS

#ifdef UNIX
    cbreak();
#endif UNIX


    noecho();

    fflush(stdin);
    fflush(stdout);
}


PUBLIC void stop_curses()
{
    echo();

    endwin();	/* stop curses */

    fflush(stdout);

}


#ifdef VMS
/*
 * check terminal type, start curses & setup terminal
 */
PUBLIC BOOLEAN setup ARGS1(char *,terminal)
{
    int c;
    char *dummy, *cp, term[81];

    /*
     * get terminal type, and convert to lower case
     */
    longname(dummy, term);
    for (cp=term; *cp!='\0'; cp++)
	if (isupper(*cp))
	    *cp = tolower(*cp);

    printf("Terminal = %s\n", term);
    sleep(1);
    if (strncmp(term, "vt1", 3) != 0 &&
	strncmp(term, "vt2", 3) != 0 &&
	strncmp(term, "vt3", 3) != 0 &&
	strncmp(term, "vt52", 4) != 0 ) {
	printf(
	    "You must use a vt100, 200, etc. terminal with this program.\n");
	printf("Proceed (n/y)? ");
	c = getchar();
	if (c != 'y' && c != 'Y') {
	    printf("\n");
	    return(FALSE);
	}
    }

    ttopen();
    start_curses();

    return(TRUE);
}

#else	/* not VMS */
/*
 * check terminal type, start curses & setup terminal
 */
PUBLIC BOOLEAN setup ARGS1(char *,terminal)
{
#ifndef MSDOS
    static char term_putenv[120];
    char term[120];
    char buffer[120];

 /* if the display was not set by a command line option then see 
  * if it is available from the environment 
  */
    display = getenv("DISPLAY");

    if(terminal != NULL) {
	sprintf(term_putenv,"TERM=%s",terminal);
	(void) putenv(term_putenv);
    }

	/* query the terminal type */
    if(dumbterm(getenv("TERM"))) {
	printf("\n\n  Your Terminal type is unknown!\n\n");
	printf("  Enter a terminal type: [vt100] ");
	gets(buffer);

	if(strlen(buffer) == 0)
	    strcpy(buffer,"vt100"); 
	
	sprintf(term_putenv,"TERM=%s", buffer);
	putenv(term_putenv);  /* */
	printf("\nTERMINAL TYPE IS SET TO %s\n",getenv("TERM"));
    }


    start_curses();

    /* get terminal type (strip 'dec-' from vms style types) */
    if (strncmp(ttytype, "dec-vt", 6) == 0) {
	strcpy(term, ttytype+4);
	(void) setterm(term);
    }
#else
    start_curses();
#endif MSDOS

    return(1);
}

PRIVATE dumbterm ARGS1(char *,terminal)
{
    int dumb = FALSE;

    if (!strcasecomp(terminal, "network") ||
	!strcasecomp(terminal, "unknown") ||
	!strcasecomp(terminal, "dialup")  ||
	!strcasecomp(terminal, "dumb")    ||
	!strcasecomp(terminal, "switch")  ||
	!strcasecomp(terminal, "ethernet")  )
	dumb = TRUE;
    return(dumb);
}
#endif

PUBLIC void cleanup ()
{
    int lastx=1, lasty=1;

    move(LINES-1, 0);
    clrtoeol();

    stop_bold();
    stop_underline();
    stop_reverse();
    refresh();

    stop_curses();

    cleanup_files();
#ifdef VMS
    ttclose();
#endif
}

