#include "defs.h"
#include <ctype.h>
	
/*
 * refinehightext strips control codes off the end of some of the 
 * lines of text that are input from pc database files.  Most notably
 * the hytelnet files contain some stange codes at the end of each line
 * that cause lynx to behave funny.  It also strips off extra spaces at
 * the end of the line which makes lynx look prettier.
 *
 */

PUBLIC void refinehightext ARGS1(char *,text)
{
    char *x;

    /* this basicly finds the first non printable character or space
       and terminates it by putting a \0 there */
    for(x=text+strlen(text); !isgraph(*x); x--)
	; /* null body */

    *(x+1) = '\0';
}
