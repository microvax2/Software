#include "defs.h"

PUBLIC void submit_form ARGS1(char *,newfile)
{
    /* file type 0 is ascii and the special type is FORM */
    sprintf(newfile,"0-FORM@%s", form_server);


}
