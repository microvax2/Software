typedef struct _FormInfo {
	char *			name;  /* the name of the link */
	int			number; /*which form is the link within*/
	int			type;	 /* string, int, etc. */
	char *			value;   /* user entered string data */
	int			size;    /* width on the screen */
	int			maxlength; /* max width of data */
	int			group;	   /* a group associated with the link
					    *  this is used for select's
					    */
	int			num_value;  /*value of the numerical fields*/
	int 			hrange;  /* high numerical range */
	int			lrange;   /* low numerical range */
} FormInfo;
