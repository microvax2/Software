/*	Displaying messages and getting input for Lynx Browser
**	==========================================================
**
**	REPLACE THIS MODULE with a GUI version in a GUI environment!
**
** History:
**	   Jun 92 Created May 1992 By C.T. Barker
**	   Feb 93 Simplified, portablised TBL
**
*/


#include "HTAlert.h"

#include <ctype.h> 		/* for toupper - should be in tcp.h */

PUBLIC void HTAlert ARGS1(CONST char *, Msg)
{
    user_message("WWW Alert:  %s\n", Msg);
}


PUBLIC void HTProgress ARGS1(CONST char *, Msg)
{
    if(!TRACE)
        statusline(Msg);
}


PUBLIC BOOL HTConfirm ARGS1(CONST char *, Msg)
{
  char Reply;
  
  user_message("WWW: %s (y/n) ", Msg);

  Reply = mygetch();

  if(Reply=='Y')
    return(YES);
  else
    return(NO);
}

/*	Prompt for answer and get text back
*/
PUBLIC char * HTPrompt ARGS2(CONST char *, Msg, CONST char *, deflt)
{
    char Tmp[200];
    char * rep = 0;
    user_message("WWW: %s", Msg);
    if (deflt) 
        strcpy(Tmp, deflt);

    StrAllocCopy(rep, Tmp);
    return rep;
}
