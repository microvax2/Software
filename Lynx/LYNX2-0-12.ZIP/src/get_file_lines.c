#include "defs.h"

PUBLIC int get_file_lines ARGS1(FILE *,fp)
{
    char line[LINESIZE];
    register int count=0;

    rewind(fp);

    while(fgets(line, LINESIZE, fp) != NULL) 
            if(defineswitch(line)== FALSE)
		break;

    while(fgets(line, LINESIZE, fp) != NULL) {
	   count++;
    }

   return(count);
}
