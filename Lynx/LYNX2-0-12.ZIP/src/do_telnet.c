#include "defs.h"

PUBLIC void do_telnet ARGS4(int,type, char *,name, char *,address, char *,port)
{
    int c;
    char *cp;
    char buf[200];
    char tncommand[200];

    if (port && port_syntax == 2) {
                        *port = '\0';
                        sprintf(buf, "%s %s /port=%s %s",
                            name, address,
                            port+1,
                            "Proceed (y/n)?");
                    } else {
                        sprintf(buf, "%s %s %s",
                            name, address,
                            "Proceed (y/n)?");
                    }
                    statusline(buf);
                    c=mygetch();
                    if (c == RTARROW || toupper(c) == 'Y' || c == '6'
                         || c == '\n' || c == '\r') {
                        addstr(" Ok...");
                        refresh();
                        if (type == TELNET)
                            sprintf(tncommand, "%s %s", 
				    TELNET_COMMAND, address);
                        else
                            sprintf(tncommand, "%s %s",
                                    TN3270_COMMAND, address);
                        if (port && port_syntax == 2) {
                            strcat(tncommand, " /port=");
                            strcat(tncommand, port+1);
                        }
                        /*
                         * sanity check on command
                         */
                        for (cp=tncommand; *cp; cp++) {
                            if (isalnum(*cp) || *cp == '"' || *cp == '-' ||
                                *cp == '.' || *cp == '/' || *cp == ' ')
                                *cp = *cp;
                            else
                                *cp = ' ';
                        }
                        stop_curses();
			signal(SIGINT, SIG_IGN);
                        (void) system(tncommand);
			fflush(stdout);
			signal(SIGINT, cleanup_sig);
                        start_curses();

                    }
} /* big end */

