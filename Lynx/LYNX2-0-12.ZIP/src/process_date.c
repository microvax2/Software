#include "defs.h"
#include <time.h>

#define DATE_ADD     1
#define DATE_SUB     2
#define DATE_REPLACE 3

PUBLIC char *process_date ARGS4(char *,value, int *,month, int *,day, 
				int *,year)
{

    struct tm *local;
    time_t t;
    BOOLEAN action;
    long long_value;

    while(isspace(*value)) value++;

    if(isdigit(*value)) {
	action = DATE_REPLACE;
    } else if(*value == '-') {
	action = DATE_SUB;
	value++;
    } else if(*value == '+') {
	action = DATE_ADD;
	value++;
    } else {
	action = DATE_ADD;
    }

    long_value = atol(value);

    t = time(NULL);
    
    switch(action) {
	case DATE_ADD:
	    t += long_value;
	    break;
	case DATE_SUB:
	    t -= long_value;
	    break;
	case DATE_REPLACE:
	    t = long_value;
	    break;
    }

    local = localtime(&t);

    *month = local->tm_mon;
    *day   = local->tm_mday;
    *year  = local->tm_year+1900;

}

PUBLIC char *process_time ARGS1(char *,value)
{

    return("11:05");

}
