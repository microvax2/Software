#include "defs.h"

extern char * HTLoadedDocumentURL();

#ifndef VMS
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/file.h>
#if SVR4
#include <sys/fcntl.h>
#endif
#else
#include <socket.h>
#include <types.h>
#include <descrip.h>
#include <netdb.h>
#include <in.h>
#include <unixlib.h>
#include <perror.h>
#include <netdb.h>
#include <ctype.h>
#include <errno.h>
#include <time.h>
#endif


PUBLIC BOOLEAN getfile ARGS5(char *,newfile, FILE **,fp, 
		char *,gopher_info, int,cur, char *,target)
{
	register int itmp;
	char *tmptr, *tmptr2;
	char altfile[MAXFNAME];
	char myhostname[12];
        int url_type;

	/* BIG HACK (BUG)  reading a Lynx internal format
	 * file uses StrAllocCopy and frees all fname and hightext pointers	
	 * since we dont want WWW library pointers to get free'd
	 * we will set all of the pointers to NULL if
	 * the currently loaded document is a WWW document
	 * so that StrAllocCopy can't free them.
	 */
	if(IS_WWW_MODE)
	    for(itmp=0; itmp < MAXLINKS; itmp++) {
		links[itmp].lname=NULL;
		links[itmp].hightext=NULL;
		links[itmp].target=NULL;
	    }

	/* set lynx mode back to normal */
	lynx_mode = NORMAL_LYNX_MODE;

	/* make sure the interupt is not set before we attempt
	 * the transfer
	 */
	InteruptTransfer = FALSE;
	
	/* check to see if this is a universal document ID
	 * that lib WWW wants to handle
         * we'll do gopher types ourselves because lib www
         * doesnt have complete gopher compatibility
	 */
	  if((url_type = is_url(newfile)) != 0) {
www:
#ifdef TRAVERSAL
		/* only done for traversals IGNORE! */
		if(url_type == HTTP_URL_TYPE) {
		    remove_backslashes(newfile);
		    if(!HTLoadAbsolute(newfile, 0))
		        return(NOT_FOUND);
		} else {
		    return(NULLFILE);
		}
#else
		if(url_type == GOPHER_URL_TYPE) {
		    /* will change url into Lynx recognizeable format */
	            remove_backslashes(newfile);
		    goto gopher;  /* dont ask!!! Grrr */

		  /* disable www telnet access if not telnet_ok */
		} else if((url_type == TELNET_URL_TYPE || 
				url_type == TN3270_URL_TYPE) ) {

		    if(!telnet_ok) {
		    	statusline("Telnet access is disabled!");
		    	sleep(1);
		    } else {
			stop_curses();
                        chdir(orig_dir);
                        HTLoadAbsolute(newfile, 0);
                        chdir(startdir);
			start_curses();
                        fflush(stdout);

		    }

		    return(NULLFILE);

		} else if(url_type == RLOGIN_URL_TYPE) {

		    stop_curses();
                    chdir(orig_dir);
                    HTLoadAbsolute(newfile, 0);
                    chdir(startdir);
                    fflush(stdout);
		    start_curses();
		    return(NULLFILE);

		} else if(url_type == MAILTO_URL_TYPE) {
		    tmptr = strchr(newfile,':')+1;
		    reply_by_mail(tmptr,"");
		    return(NULLFILE);
		
		} else {
		   /* use altfile as a string buffer */
		    sprintf(altfile,"%s%s",WWW_WAIT_MESSAGE,newfile);
		    statusline(altfile);

		   /* set up a way of asyncronously aborting the
		    * the transfer in mid-stream.
		    */
#ifdef HAVE_SIGIO
     		    fcntl (0, F_SETOWN, getpid() );
     		    fcntl ( 0, F_SETFL, FASYNC );
     		    signal(SIGIO, async_interupt); /* */
#else
     		    signal(SIGINT, async_interupt); /* */
#endif HAVE_SIGIO
	 	    remove_backslashes(newfile);
		    if(!HTLoadAbsolute(newfile, 0))
		        return(NOT_FOUND);

		    lynx_mode = WWW_LYNX_MODE;

		    /* return the interupts to the way they were */
#ifdef HAVE_SIGIO
                    signal(SIGIO, SIG_IGN);
#else
                    signal(SIGINT, cleanup_sig);
#endif HAVE_SIGIO

		    /* some URL's don't actually return a document
		     * compare newfile with the document that is 
		     * acctually loaded and return NULL if not
		     * loaded.  If www_search_result is not -1
		     * then this is a reference to a named anchor
		     * within the same document.  Do NOT return
		     * NULL
		     */
                    {
                        char *pound;
                        /* check for #selector */
                        pound = strchr(newfile, '#');

                        if(pound == NULL &&
                                strcmp(newfile, HTLoadedDocumentURL()) ) {
                            return(NULLFILE);

                        } else {
                        /* may set www_search_result */
                            if(pound != NULL)
                                HTFindPoundSelector(pound+1);
                            return(LOCAL);
                        }
                    }
		}
#endif TRAVERSAL
	  }

	  tmptr2 = newfile;
          while((tmptr = strchr(tmptr2, '@'))!=NULL) {
		tmptr2 = tmptr+1;
		if(*(tmptr-1)!='\\') {

                        /* this is a gopher link */

	       /* check to see whether we have already gotten this file
	        * if we have newfile will be replaced by the local name
	        * and we will open it locally
	        */
	       if(replacebylocal(newfile, gopher_info)) {
	           goto OpenLocal;
		}
		

		/*
		 * Check to see if this is an html gopher link
		 * if it is convert it to be a url and pass it
		 * to WWW
		 */
		 if(!strncmp(newfile,"h-",2)) {
		     convert_gopher_link(newfile);
		     goto www;
		 }

		/* Check to see if the remote hostname is acctually
		 * this local host.  If it is we can save alot of
		 * resources by getting it from the local disk instead
		 * of using gopher to get it
		 */
		    gethostname(myhostname, 8);
		    myhostname[8]='\0';
		 /* if the file is file type FILE and the hostname
		  * is the same as the local host
		  */
		    if(newfile[0]=='0' && mystrstr(newfile,myhostname)!=NULL) {
			char *tmptr3;
			FILE *tmpfp;
			/* remove file type and dash and zero and slash */
			strcpy(altfile,newfile+4);
			tmptr3 = strchr(altfile,'@');
			*tmptr3='\0';  /* get rid of the hostname */
			/* see if we can find and open the file */
			if((tmpfp = fopen(altfile,"r")) != NULL) {
			    fclose(tmpfp);
			    strcpy(newfile,altfile);
			/* open as local disk access */
			    goto OpenLocal;	
			}
		    }

		    /* its not a local file so go get it using gopher */
		
		    /* do_gopher now reads URL's so convert the
		     * lynx representation to a URL before
		     * calling do_gopher
		     */
	            convert_gopher_link(newfile);
gopher:
                    strcpy(gopher_info, do_gopher(newfile, 
					     links[cur].hightext, target, *fp));
		    
		    if(STREQ(gopher_info,"NULL")) 
			return(NULLFILE);

		    if(STREQ(newfile,"#NOT FOUND#")) 
			return(NOT_FOUND);

		    if ((*fp=fopen(newfile, "r")) == NULL) 
			return(NOT_FOUND);
		    else {
                        char strtemp[LINESIZE];
		
                        /* advance file through first page */
                        checkfordefines(*fp);
                        /* checkfordefines will skip over defines at top */
                        for(itmp=1; itmp<=LINES-1 &&
                                fgets(strtemp,LINESIZE,*fp); itmp++)
                                ; /* null body */
                        if(more)
                           fgets(line,LINESIZE,*fp);
                /*'line' is global variable, holding next line in file */
                   	return(GOPHER);
		     } /* end else */
	        } /* end if */
	  } /* end while */


	  /* if its not a gopher file then remove any backslashes that might be
	   * in the name
	   */
	     remove_backslashes(newfile);

	/* local disk access on file */
OpenLocal:
            /*
             * Try to open the new file.
             * If the file is not found in the current directory,
             * try and uncapitalize it, if it is still not found use
             * the first three letters of the filename as a directory name,
             * and try again.  This is for compatibility with HYPERRES,
             * not because I like it.
             */
            
            if ((*fp=fopen(newfile, "r")) != NULL) {

        /* The file wasn't found the first time, so try and uncapitalize
           the filename and open again */
            } else if((*fp=fopen(uncapitalize(newfile), "r")) != NULL) {

        /* The file wasn't found the second time, so try using the first
           three letters of the filename as a directory */
            } else {
                tmptr = strrchr(newfile,'/'); /* point to the last slash */
                if(tmptr) {
                  mystrncpy(altfile, newfile, tmptr-newfile+1);
                  strncat(altfile, tmptr+1, 3);
                  strcat(altfile, tmptr);
                } else { /* there is no slash */
                  mystrncpy(altfile, newfile, 3);
                  strcat(altfile, "/");
                  strcat(altfile, newfile);
                }

                if ((*fp=fopen(altfile, "r")) != NULL) {
                    strcpy(newfile, altfile);
                } else {
		    return(NOT_FOUND);  /* file can't be opened */
		}
	    }

	return(LOCAL);
}  /* end of get file */


PUBLIC void async_interupt ARGS1(int,sig)
{
#ifdef HAVE_SIGIO
        if(toupper(mygetch())=='A')  /* */
#endif HAVE_SIGIO

            InteruptTransfer=TRUE;  /* */
#ifdef VMS
        /* reassert the AST */
        signal(SIGINT, async_interupt);
        /* refresh the screen to get rid of the "cancel" message */
        /* This causes the page to be blank!!                    */
        stop_curses();
        start_curses();
#endif VMS
}

