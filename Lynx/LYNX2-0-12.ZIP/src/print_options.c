#include "defs.h"

/*
 * print_options writes out the current printer choices to a file
 * so that the user can select printers in the same way that
 * they select all other links 
 * printer links look like
 *  <%LOCAL_FILE name="string" lines="#">  print to a local file
 *  <%TO_SCREEN lines="#">   print to the screen
 *  <%MAIL_FILE lines="#">   mail the file to yourself
 *  <%PRINTER number="#" lines="#">   print to printer number #
 */

PUBLIC int print_options ARGS2(char *,newfile, int,lines_in_file)
{
    char buffer[LINESIZE];
    int count;
    int pages;
    FILE *fp0;
    printer_type *cur_printer;
#ifdef VMS
    static int first_time_through = TRUE;
#endif VMS

    pages = lines_in_file/66 + 1;

#ifdef MSDOS
    sprintf(newfile,"%sPRINT.OPT",TEMP_SPACE);
#else
    sprintf(newfile,"%sLYNX%dPRINTOPTIONS",TEMP_SPACE,getpid());
#endif

#ifdef VMS
    /* remove any duplicates */
    if(first_time_through == FALSE)
	remove(newfile);

    first_time_through = FALSE;
#endif VMS

    if((fp0 = fopen(newfile,"wb")) == NULL) {
        perror("Trying to open history file\n");
        exit(1);
    }

    fprintf(fp0," end_link_delimiter=> \n link_delimiter=< ");
    fprintf(fp0,"\n token_delimiter=: \n");

    fprintf(fp0,"\n                  Printing Options\n\n");


    sprintf(buffer,"    There are %d lines, or approximately %d page%s, to print.\n\n",lines_in_file, pages, (pages > 1 ? "s" : ""));
    fputs(buffer,fp0);

    if(no_print || child_lynx)
	fputs("      Some print functions have been disabled!!!\n",fp0);

    fputs("        You have the following print choices\n",fp0);
    fputs("                     please select one\n\n",fp0);

    if(child_lynx==FALSE && no_print==FALSE)
         fprintf(fp0,"     <%%LOCAL_FILE lines=\"%d\">Print to a local file\n\n",lines_in_file);
    fprintf(fp0,"     <%%MAIL_FILE  lines=\"%d\">Mail the file to yourself\n\n",
								lines_in_file);
    fprintf(fp0,"     <%%TO_SCREEN  lines=\"%d\">Print to the screen\n\n",
								lines_in_file);

        for(count=0, cur_printer=printers; cur_printer != NULL; 
				    cur_printer = cur_printer->next, count++) 
    	    if(no_print==FALSE || cur_printer->always_enabled) {
	        fprintf(fp0,"     <%%PRINTER number=\"%d\" lines=\"%d\">",
				     		        count,lines_in_file);

		fprintf(fp0, (cur_printer->name ? 
				cur_printer->name : "No Name Given"));
		fprintf(fp0,"\n\n");
	    }
    fclose(fp0);
}
