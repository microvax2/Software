#include "defs.h"
#include <ctype.h>

/*
 * ismoretext checks the rest of the line to see if there is more text
 * before the next \0.  If there isnt then it returns false
 */

PUBLIC BOOLEAN ismoretext ARGS1(char *,cp5)
{
   for(;*cp5 != '\0';cp5++)
	if(isgraph(*cp5)) 
	  return(TRUE);
   
   return(FALSE);
}
