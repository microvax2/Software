#include "defs.h"

/*
 * my strncpy() terminates strings with a null byte.
 * Writes a null byte into the n+1 byte of dst.
 */
PUBLIC char * mystrncpy ARGS3(char *,dst, char *,src, int,n)
{
    char *val;

    val = strncpy(dst, src, n);
    *(dst+n) = '\0';
    return val;
}

#ifdef VMS
#define GetChar() ttgetc()
#else
#define GetChar() getchar()  /* used to be "getc(stdin)" and "getch()" */
#endif VMS


/*
 * mygetch() translates some escape sequences and may fake noecho
 */
mygetch()
{
    int a, b, c;

    c = GetChar();

    if (c == 27) {	/* handle escape sequence */
	b = GetChar();

	if (b == '[' || b == 'O') {
	    a = GetChar();
	}

	else
	    a = b;

	switch (a) {
	case 'A': c = UPARROW; break;
	case 'x': c = UPARROW; break;  /* keypad up on pc ncsa telnet */
	case 'B': c = DNARROW; break;
	case 'r': c = DNARROW; break; /* keypad down on pc ncsa telnet */
	case 'C': c = RTARROW; break;
	case 'v': c = RTARROW; break; /* keypad right on pc ncsa telnet */
	case 'D': c = LTARROW; break;
	case 't': c = LTARROW; break; /* keypad left on pc ncsa telnet */
	case 'y': c = PGUP; break;  /* keypad on pc ncsa telnet */
	case 's': c = PGDOWN; break;  /* keypad on pc ncsa telnet */
	case 'w': c = HOME; break;  /* keypad on pc ncsa telnet */
	case 'q': c = END; break;  /* keypad on pc ncsa telnet */
	case 'm': c = '-'; break;  /* keypad on pc ncsa telnet */
	case 'l': c = '+'; break;  /* keypad on pc ncsa telnet */
	case 'M': c = '\n'; break; /* kepad enter on pc ncsa telnet */
	case 'P': c = F1; break;
	case 'u': c = F1; break;  /* macintosh help button */
	case '5':			/* vt 300 prev. screen */
	    if (b == '[' && GetChar() == '~')
		c = '-';
	    break;
	case '6':			/* vt 300 next screen */
	    if (b == '[' && GetChar() == '~')
		c = '+';
	    break;
	}
    }
    return(c);
}


