#include "defs.h"

/*
 * Search through a string for the first valid internet address.
 * We define an internet address as a word consisting of alpha-
 * numeric characters and dots (and with at least one embedded dot).
 *
 * If the address is immediately followed by a space and a port number,
 * those are included as well.
 *
 * This is not a general purpose routine.
 *
 * Returns an pointer to the address if one is found, NULL otherwise.
 */
PUBLIC char *interaddr ARGS2(char *,cp, char *,buf)
{
    int isaddr, isname;
    char *cp2, *word;

    while (*cp != '\0') {

	isaddr = FALSE;
	isname = FALSE;

	while (*cp == ' ') cp++;		/* skip spaces */

	word = cp;				/* start of word? */
	while (*cp == '"' || *cp == '-' || *cp == '.' || isalnum(*cp)) {
	    if (*cp == '.' && isalnum(*(cp+1)) )
		isaddr = TRUE;
	    if (isalpha(*cp))
		isname = TRUE;
	    cp++;
	}

	if (isaddr) {			/* it's an internet address */
	    if ((telnet_by_name && isname) ||
		(telnet_by_number && !isname) ) {
		if (*cp == ' ') {	/* check for port number */
		    for (cp2=cp+1; isdigit(*cp2); cp2++)
			; /* NULL BODY */
		    if (cp2 > cp+1)
			cp = cp2;
		}
		while (!isalnum(*cp) && *cp != '"') cp--;
		strncpy(buf,word,cp-word+1);
		/* printw("interaddr: %s\n", buf); refresh(); */
		return(word);
	    }
	} else {  /* if it's the word "or", try again, otherwise give up */
	    if (strncmp(word, "or", 2) != 0)
		return(NULL);
	}
    }
    return(NULL);
}
