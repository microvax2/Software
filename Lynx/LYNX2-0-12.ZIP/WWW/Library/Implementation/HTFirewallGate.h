/*  */

/*      HyperText Tranfer Protocol                                      HTTP.h
**      ==========================
*/

#ifndef HTTPFireGate_H
#define HTTPFireGate_H

#include "HTAccess.h"


/*      Load Document using HTTP firewall gateway
**      ------------------------
*/
extern int HTLoadFirewallGateway PARAMS((
          CONST char *            arg,
          HTParentAnchor *        anAnchor,
          HTFormat              format_out,
          HTStream *            sink));


#endif /* HTTPFireGate_H */
/*

    */
