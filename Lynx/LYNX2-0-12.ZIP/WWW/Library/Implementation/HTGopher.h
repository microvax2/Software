/*  */

/*                      GOPHER ACCESS                           HTGopher.h
**                      =============
**
** History:
**       8 Jan 92       Adapted from HTTP TBL
*/

#ifndef HTGOPHER_H
#define HTGOPHER_H

#include "HTAccess.h"
#include "HTAnchor.h"

/* extern int HTLoadGopher PARAMS((const char *arg,
        HTParentAnchor * anAnchor,
        int diag));
*/
GLOBALREF HTProtocol HTGopher;

#endif /* HTGOPHER_H */
/*

    */
