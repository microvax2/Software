/*
 * Lynx.c - Hypertext navagation system
 *
 * SYNOPSIS:
 *	lynx [args] [path]
 *
 * EXPLANATION
 *      This is a curses oriented distributed hypertext browser, 
 *      with some fancy features.
 *      This program uses a superset of the hytelnet file format which
 *      is a derivative of HYPERRES, so it should be 
 *      possible to plug-and-play other databases as well.
 *      Lynx also parses and navigates WWW documents.
 *     
 *      A Lynx database consists of many more-or-less plain text files,
 *      on any file system.  Any text in angle brackets (eg <HELP>)
 *      is a link, it is also possible to change the link delimiter
 *      (eg %HELP%).  Selecting it moves you to the named file. 
 *      Files can reside on remote systems and can be accessed through
 *      internet gopher servers.  A gopher client is built into lynx. 
 *
 *      The program notices telnet commands embedded in the text files,
 *      and will execute them for the user, if desired.
 *
 * NOTES
 *	Big thanks to 
 *      Earl Fogel, Computing Services, University of Saskatchewan
 *      fogel@sask.usask.ca from who's code this whole thing started from
 *
 *      Thanks to Michael A. Crowley (mcrowley@mtholyoke.edu) for some
 *      of the interrupt handling code.
 *
 *      Thanks to Kathryn Huxtable (huxtable@kuhub.cc.ukans.edu) for the
 *      VMS termio routines, and various other VMS oddities.
 *
 *      Thanks to Foteos Macrides of Worcester Foundation for Experimental 
 *      Biology who helped a great deal with VMS debugging and code
 *      development.
 *
 *      Thanks to the Gopher folks, who's code helped a great deal.
 *
 *      And thanks to anyone else whose code examples I might have used.
 *
 * BUGS
 *    - There are no bugs just features
 *
 * AUTHORS
 *	Lou Montulli, University of Kansas, Computing Services
 *	Montulli@KUHUB.cc.ukans.edu
 *
 *	Michael Grobe, University of Kansas, Computing Services
 *	Grobe@KUHUB.cc.ukans.edu
 *
 *	Charles Rezac, University of Kansas, Computing Services
 *	Rezac@KUHUB.cc.ukans.edu
 *
 * CHANGE LOG
 *      see CHANGES
 *
 * NOTICE
 *	Permissions to copy, use and redistribute this program are hereby
 *	granted provided the Copyright notice and this comment remain
 *	intact.
 *
 *		    (c) Copyright 1992, 1993 University of Kansas
 */

/*******************************************************************
 * There are three sections to this document
 *  Section 1.  Things you MUST change or verify
 *	Section 1a)  VMS specific things
 *	Section 1b)  UNIX specific things
 *	Section 1c)  ALL Platforms
 *
 *  Section 2.  Things you should probably check!
 *
 *  Section 3.  Things you should only change after you have a good
 *              understanding of the program!
 *
 */

/*******************************************************************
 * Things you must change
 *  Section 1. 
 */

/*******************************************************************
 * Things you must change  VMS specific
 *  Section 1a). 
 */
#ifdef VMS
/**************************
 * TEMP_SPACE is where Lynx tempory cache files will be placed.
 * Tempory files are removed automatically as long as nothing
 * goes terribly wrong :)
 */
#define TEMP_SPACE "sys$scratch:"

/**************************
 * LYNX_CFG_FILE is the location and name of the lynx system
 * configuration file.
 */
#define LYNX_CFG_FILE "sys$public:lynx.cfg"

/**************************
 * the full path and name of the telnet command
 */
#define TELNET_COMMAND "telnet"

/**************************
 * the full path and name of the tn3270 command
 */
#define TN3270_COMMAND "telnet /tn3270"

/**************************
 * the full path and name of the rlogin command
 */
#define RLOGIN_COMMAND "rlogin"

/**************************
 * the full path and name of the xloadimage command
 * put 'echo' or something like it here if you don't have it
 * you may also use 'xv' or anything that will handle GIF,
 * TIFF and other popular image formats
 */
#define XLOADIMAGE_COMMAND "xv"

/**************************
 * the full path and name of the vi editor or some other default editor
 */
#define VI "ed"

/**************************
 * the full path and name of the emacs editor if it exists
 */
#define EMACS "emacs"

/**************************
 * the full path and name of the standard VMS "mail" command
 * The mail command will be spawned as a subprocess of lynx
 * and used to send replies and error messages.
 * SYSTEM_MAIL must be able to accept a subject line through
 * the use of the /subject="SUBJECT" option
 * if your mailer uses anonther syntax, some hacking of
 * the "mailmsg.c" and "reply_by_mail.c" files may be required.
 */
#define SYSTEM_MAIL "mail"

/**************************
 * the full path and name of the rsh or rexec command on your
 * system.
 */
#define RSH_COMMAND "rsh"  /* better known as rexec */

/*************************
 * below is the argument for a sprintf command that will
 * add "in%""ADDRESS""" to the internet mail address given by the user.
 * It is structured for PMDF's in%"INTERNET_ADDRESS"
 * scheme.   The %s is replaced with the address given by the user.
 */
#define MAIL_ADRS "\"in%%\"\"%s\"\"\""

/*************************
 *  Below are the routines to read and write from a socket.
 *  Multinet uses 'socket_read', and 'socket_write' while
 *  UCX uses 'read', and 'write'.  What does your system use?
 *  I'm not sure what Wollagong uses, if you know 
 *  please send me a message.
 */
#ifdef MULTINET
#define Socket_Read(A, B, C)  socket_read(A, B, C)
#define Socket_Write(A, B, C) socket_write(A, B, C)
#define Socket_Close(A)       socket_close(A)
#endif MULTINET

#ifdef UCX
#define Socket_Read(A, B, C)  read(A, B, C)
#define Socket_Write(A, B, C) write(A, B, C)
#define Socket_Close(A)       close(A)
#endif UCX

#ifdef WIN_TCP
#define Socket_Read(A, B, C)  netread(A, B, C)
#define Socket_Write(A, B, C) netwrite(A, B, C)
#define Socket_Close(A)       netclose(A)
#endif WIN_TCP

/*******************************************************************
 * Things you must change  UNIX specific
 *  Section 1b). 
 */
#else     /* UNIX */

/**************************
 * LYNX_CFG_FILE is the location and name of the lynx system
 * configuration file.
 */
#define LYNX_CFG_FILE "/usr/local/lib/lynx.cfg"

/*********************
 * LOCAL_DOMAIN is used to determin if a user is local
 * to your campus or organization
 */
#define LOCAL_DOMAIN "ukans.edu"		/* CHANGE THIS! */

/**************************
 * the full path and name of the telnet command
 */
#define TELNET_COMMAND "telnet"

/**************************
 * the full path and name of the tn3270 command
 */
#define TN3270_COMMAND "tn3270"

/**************************
 * the full path and name of the rlogin command
 */
#define RLOGIN_COMMAND "rlogin"

/**************************
 * the full path and name of the rsh or rexec command on your
 * system.   Please don't mistakenly give the Rsh that is the
 * restricted shell on some systems.
 */
#define RSH_COMMAND "rsh" 

/*************************
 * if you don't have xloadimage just set this to "echo" or
 * something else that is harmless, 'xv' also works really well if
 * not better!
 */
#define XLOADIMAGE_COMMAND "xv"

/**************************
 * the full path and name of the vi editor or some other default editor
 */
#define VI "vi"

/**************************
 * the full path and name of the emacs editor if it exists
 */
#define EMACS "emacs"

/**************************
 * For UNIX systems this should be sendmail
 * sendmail should be in /usr/lib 
 * you definately want sendmail, not mail or elm or something else.
 */
#define SYSTEM_MAIL "/usr/lib/sendmail" 

/**************************
 * a place to put temporary files, its almost always "/tmp/" on
 * UNIX systems
 */
#define TEMP_SPACE "/tmp/"

/**************************
 * this "utmp" stuff is used to determine the calling address of
 * the user.  
 * do a "find / -name utmp -print" if you don't know where to find
 * the utmp file, its usually in /etc/utmp.
 */
#include <utmp.h>
#define UTMP_FNAME "/etc/utmp"

#endif /* VMS OR UNIX */

/*************************************************************
 *  Section 1c)   Every platform must change or verify these
 *
 */

/******************************
 * ALERTMAIL is the person that will recieve error messages.
 * It needs to be a valid mail address 
 */
#define ALERTMAIL  "montulli@ukanaix.cc.ukans.edu" /* please change this */

/*****************************
 * STARTFILE is the default file if none is specified on the command line 
 * note: these files can be remote (ie 0-0/start@host.cc.ukans.edu or
 * http://info.cern.ch/default.html) or local (i.e. /u/home/cwis.screen) 
 * if a local file is chosen the directory that it resides in
 * should be fully specified in the path.  
 */
#define STARTFILE "http://www.cc.ukans.edu/about_lynx/www_start.html"  /* */
/* #define STARTFILE "http://info.cern.ch/default.html"         /* */
/* #define STARTFILE "http://kufacts.cc.ukans.edu/cwis/kufacts_start.html" /* */

/*****************************
 * helpfile should have a complete local path name if local 
 * the default HELPFILE is:
 * http://kufacts.cc.ukans.edu/lynx_help/lynx_help_main.html
 * and will be updated as needed.  There are also copies of
 * these files in the samples directory if you wish to install
 * them locally
 */
#define HELPFILE "http://www.cc.ukans.edu/lynx_help/lynx_help_main.html"

/*****************************
 * DEFAULT_INDEX_FILE is the default file retrieved when the
 * user presses the 'I' key when viewing any document.
 * An index to your CWIS can be placed here or a document containing
 * pointers to lots of interesting places on the web.
 */
#define DEFAULT_INDEX_FILE "http://info.cern.ch/default.html"

/*****************************
* Do we have capacity to display special characters? If yes define 
* LOCALE. This may produce weird results when displaying a file
* containing PC-graphics.
*
* defining ISOLATIN1 will enable ISOLATIN1 chars only.
* do not define both at once
*
* This option does not effect HTML files, only Lynx internal
* format hypertext files.
*
* ATTENTION VMS USERS!  VMS systems do not appear to have
* LOCALE capabilities.  DO NOT define LOCALE!
*/
/* #define LOCALE  /* */
/* #define ISOLATIN1 */

/********************************
* The DEFAULT_CACHE_SIZE specifies the number of WWW documents to be
* cached in memory at one time.  When the number is exceded the oldest
* document will be removed from memory.
* The cache size may be modified with the command line argument -cache=NUMBER
*
* Do not set less than 1 or Lynx will segmentation fault.
*/
#define DEFAULT_CACHE_SIZE 10

/****************************************************************
 *   Section 2.   Things that you probably want to change or review
 *
 */

/*****************************
 * Enter the name of your anonymous account if you have one
 * as ANONYMOUS_USER.  UNIX systems will use a cuserid
 * or get_login call to determine if the current user is
 * the ANONYMOUS_USER.
 *
 * VMS systems cannot use this feature, so they must specify
 * anonymous accounts using the "-anonymous" command line option.
 *
 * Other systems may use the "-anonymous" option for multiple
 * accounts or percautionary reasons as well.
 *
 * It is very important to have this correctly defined if you 
 * have an anonymous account.  If you do not you will be putting 
 * yourself at GREAT security risk!
 *
 * Later on in this file you can specify priviliges for the
 * anonymous account.
 */
#define ANONYMOUS_USER ""

/*******************************
 * set to FALSE if you don't want users of your anonymous account
 * who are calling from inside your local domain 
 * to be able to telnet back out
 */
#define CAN_ANONYMOUS_INSIDE_DOMAIN_TELNET	       TRUE  

/*******************************
 * set to FALSE if you don't want users of your anonymous
 * account who are calling from outside your
 * local domain to be able to telnet back out
 */
#define CAN_ANONYMOUS_OUTSIDE_DOMAIN_TELNET       TRUE  

/*******************************
 * set to FALSE if you don't want users of your anonymous
 * account to be able to print
 */
#define CAN_ANONYMOUS_PRINT	       FALSE

/*****************************
 * These are for lynx internal format executable links.
 * If you are running only HTML and WWW, leave these FALSE
 */
#define LOCAL_EXECUTION_LINKS_ALWAYS_ON          FALSE
#define LOCAL_EXECUTION_LINKS_ON_BUT_NOT_REMOTE  FALSE

/*****************************
 * VERBOSE_GOPHER turns on extra info about each link
 * I recommend leaving it on.
 */
#define VERBOSE_GOPHER    	       TRUE /*turn on extra info by default?*/

/*********************************
 *  MAIL_SYSTEM_ERROR_LOGGING will send a message to the owner of 
 *  the information, or ALERTMAIL if there is no owner, every time
 *  that a document cannot be accessed!
 *
 *  VMS USERS !!!
 * You will probably want to set 'MAIL_SYSTEM_ERROR_LOGGING' to FALSE.
 * It is really nice to have automatic error logging but this is done
 * by doing a system command and running mail.  This is VERY slow under
 * VMS and just takes too darn long.
 */
#define MAIL_SYSTEM_ERROR_LOGGING   FALSE  /*mail a message for every error?*/

/*********************************
 * VI_KEYS can be turned on by the user in the options
 * screen or the .lynxrc file.  This is just the default.
 */
#define VI_KEYS_ALWAYS_ON           FALSE /* familiar h,j,k, & l */

/*********************************
 * EMACS_KEYS can be turned on by the user in the options
 * screen or the .lynxrc file.  This is just the default.
 */
#define EMACS_KEYS_ALWAYS_ON           FALSE /* familiar ^N, ^P, ^F, ^B */

/*********************************
 * DEFAULT_KEYPAD_MODE specifies whether by default the user
 * has numbers that work like arrows or else numbered links
 * DEFAULT KEYPAD MODE may be set to 
 *	LINKS_ARE_NUMBERED  or
 *	NUMBERS_AS_ARROWS
 */
#define DEFAULT_KEYPAD_MODE	       NUMBERS_AS_ARROWS

/********************************
 * The default search.
 * This is a default that can be overridden by the user!
 */
#define CASE_SENSITIVE_ALWAYS_ON    FALSE /* case sensitive user search */


/****************************************************************
 *   Section 3.   Things that you should not change until you
 *  		  have a good knowledge of the program
 */

/* text strings for certain actions */
/* changing these text strings is a way to customize 
 * your environment to better suit your tastes
 */
#define HELP "Commands: Use arrow keys to move, '?' for help, 'q' to quit, '<-' to go back"
#define MOREHELP \
  "-- press space for more, use arrow keys to move, '?' for help, 'q' to quit"
#define MORE "-- press space for next page --"
#define FORM_LINK_MESSAGE "(FORM LINK)   Select link to change or use 'x' and 'z' to toggle."
#define NORMAL_LINK_MESSAGE "(NORMAL LINK) Select link to activate"
#define LINK_NOT_FOUND "This hypertext subject is not available at this time."

#ifdef HAVE_SIGIO
#define GOPHER_WAIT_MESSAGE "Read %d bytes.  Press 'A' to abort"
#else   /* NO SIGIO */
#define GOPHER_WAIT_MESSAGE "Read %d bytes.  Press CTRL-C to abort"
#endif HAVE_SIGIO

#define WWW_WAIT_MESSAGE "Getting "
#define WWW_FAIL_MESSAGE "Unable to access WWW file!!!"
#define WWW_INDEX_MESSAGE "This is a searchable index.  Use 's' or '/' to search"
#define WWW_INDEX_MORE_MESSAGE "--More--  This is a searchable index.  Use 's' or '/' to search"
#define BAD_LINK_NUM_ENTERED "You have entered an invalid link number"


#define GOPHER_PORT 70  /* the default gopher port (I wouldn't change this) */
/*******
 * these a lynx internal format hypertext defaults vvvvv
 */
/* the Left target delimiter must be 2 charactors with quotes */
#define LEFT_TARGET_DELIMITER "[*"
/* same for the right one as the left */
#define RIGHT_TARGET_DELIMITER "*]"
/* default link delimiter, '\0' means no default */
#define DEFAULT_LINK_DELIMITER '\0'   
#define DEFAULT_END_LINK_DELIMITER '>'   /* default link delimiter */
#define DEFAULT_TOKEN_DELIMITER ':'  /* token delimiter */
#define MAXBASE 100       /* max length of base directory */
#define MAXHIGHLIGHT 160 /* max length of highlighted text */
#define MAXTARGET 130    /* max length of target string */
#define LINESIZE 1024    /* max length of line to read from file*/
#define MAXFNAME 1280	/* max filename length DDD/FILENAME.EXT */
#define MAXCOMMAND MAXFNAME /* max lengh of command should be the same */
#define MAXHIST  200	/* number of links we remember in history */
#define MAXLINKS 200	/* max links on one screen */
#define LINEWRAP 20   /* maximum size of word to linewrap */
   /* traversal lookup table file, don't worry about it for now */
#define TRAVERSE_FILE "/homea/local/lynx2-0-8/traverse.file"
#define TRAVERSE_ERRORS "/homea/local/lynx2-0-8/traverse.errors"
#define TRAVERSE_FOUND_FILE "/homea/local/lynx2-0-8/traverse.found"
